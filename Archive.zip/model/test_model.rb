# coding: utf-8
# Test for model
require 'minitest/autorun'
require_relative 'model'

class TestModel < Minitest::Unit::TestCase
  def self.runnable_methods
    puts 'Overriding minitest to run tests in a defined order'
    methods = methods_matching(/^test_/)
  end
  def worksheet; @worksheet ||= init_spreadsheet; end
  def init_spreadsheet; Model.new end
  def test_control_e5; assert_in_delta(1.0, worksheet.control_e5, 0.002); end
  def test_control_e6; assert_in_delta(1.0, worksheet.control_e6, 0.002); end
  def test_control_e7; assert_in_delta(1.0, worksheet.control_e7, 0.002); end
  def test_control_e8; assert_in_delta(1.0, worksheet.control_e8, 0.002); end
  def test_control_e9; assert_in_delta(1.0, worksheet.control_e9, 0.002); end
  def test_control_e10; assert_in_delta(1.0, worksheet.control_e10, 0.002); end
  def test_control_e11; assert_in_delta(1.0, worksheet.control_e11, 0.002); end
  def test_control_e12; assert_in_delta(1.0, worksheet.control_e12, 0.002); end
  def test_control_e13; assert_in_delta(1.0, worksheet.control_e13, 0.002); end
  def test_control_e14; assert_in_delta(1.0, worksheet.control_e14, 0.002); end
  def test_control_e15; assert_in_delta(1.0, worksheet.control_e15, 0.002); end
  def test_control_e16; assert_in_delta(0.0, (worksheet.control_e16||0), 0.002); end
  def test_control_e17; assert_in_delta(1.0, worksheet.control_e17, 0.002); end
  def test_control_e18; assert_in_delta(1.0, worksheet.control_e18, 0.002); end
  def test_control_e19; assert_in_delta(1.0, worksheet.control_e19, 0.002); end
  def test_control_e20; assert_in_delta(1.0, worksheet.control_e20, 0.002); end
  def test_control_e21; assert_in_delta(1.0, worksheet.control_e21, 0.002); end
  def test_control_e22; assert_in_delta(0.0, (worksheet.control_e22||0), 0.002); end
  def test_control_e23; assert_in_delta(0.0, (worksheet.control_e23||0), 0.002); end
  def test_control_e24; assert_in_epsilon(4.0, worksheet.control_e24, 0.002); end
  def test_control_e25; assert_in_epsilon(4.0, worksheet.control_e25, 0.002); end
  def test_control_e26; assert_in_epsilon(4.0, worksheet.control_e26, 0.002); end
  def test_control_e27; assert_in_epsilon(4.0, worksheet.control_e27, 0.002); end
  def test_control_e28; assert_in_delta(0.0, (worksheet.control_e28||0), 0.002); end
  def test_control_e29; assert_in_epsilon(4.0, worksheet.control_e29, 0.002); end
  def test_control_e30; assert_in_epsilon(4.0, worksheet.control_e30, 0.002); end
  def test_control_e31; assert_in_delta(0.0, (worksheet.control_e31||0), 0.002); end
  def test_control_e32; assert_in_epsilon(4.0, worksheet.control_e32, 0.002); end
  def test_control_e33; assert_in_epsilon(4.0, worksheet.control_e33, 0.002); end
  def test_control_e34; assert_in_delta(0.0, (worksheet.control_e34||0), 0.002); end
  def test_control_e35; assert_in_epsilon(4.0, worksheet.control_e35, 0.002); end
  def test_control_e36; assert_in_epsilon(4.0, worksheet.control_e36, 0.002); end
  def test_control_e37; assert_in_delta(0.0, (worksheet.control_e37||0), 0.002); end
  def test_control_e38; assert_in_epsilon(4.0, worksheet.control_e38, 0.002); end
  def test_control_e39; assert_in_epsilon(4.0, worksheet.control_e39, 0.002); end
  def test_control_e40; assert_in_delta(0.0, (worksheet.control_e40||0), 0.002); end
  def test_control_e41; assert_in_epsilon(4.0, worksheet.control_e41, 0.002); end
  def test_control_e42; assert_in_epsilon(4.0, worksheet.control_e42, 0.002); end
  def test_control_e43; assert_in_delta(0.0, (worksheet.control_e43||0), 0.002); end
  def test_control_e44; assert_in_delta(1.0, worksheet.control_e44, 0.002); end
  def test_control_e45; assert_in_delta(1.0, worksheet.control_e45, 0.002); end
  def test_control_e46; assert_in_delta(1.0, worksheet.control_e46, 0.002); end
  def test_control_i5; assert_equal("6.5GW with 2.9GW available and produced 17,604GWh ", worksheet.control_i5); end
  def test_control_j5; assert_equal("11.3GW and remain the same up to 2050. This should produce 74,556GWh ", worksheet.control_j5); end
  def test_control_k5; assert_equal("20.17GW through independent Power Producer (IPPs) should be achieved which should produce 132,517GWh.", worksheet.control_k5); end
  def test_control_l5; assert_equal("80.56GW by 2050 which should produce 529,279GWh. This target is based on “energy requirement for vision 20:2020 and beyond” for Nigeria.", worksheet.control_l5); end
  def test_control_i6; assert_equal("0.005GW of biomass power plant will be available up to year 2050. This will produce about 0.04TWh.", worksheet.control_i6); end
  def test_control_j6; assert_equal("1GW of biomass power plant should be available by 2050 and producing 7.88TWh", worksheet.control_j6); end
  def test_control_k6; assert_equal("4GW of biomass power plant by 2050 which will produce 31.54TWh", worksheet.control_k6); end
  def test_control_l6; assert_equal("10GW  of biomass power plants by 2050. This can produce 78.84TWh.", worksheet.control_l6); end
  def test_control_i7; assert_equal("Coal power plants will not be available in the electricity generation mix up to 2050. ", worksheet.control_i7); end
  def test_control_j7; assert_equal("1.4 GW by 2020 which is maintained up to 2050. This will generate approximately 9,198GWh", worksheet.control_j7); end
  def test_control_k7; assert_equal("4.5 GW by 2030 which should remain constant up to 2050. This will generate approximately 29,565GWh. ", worksheet.control_k7); end
  def test_control_l7; assert_equal("reach 55GW by 2050 and produce 361,350GWh/y ", worksheet.control_l7); end
  def test_control_i8; assert_equal("No nuclear power station will be available in the electricity generation mix by 2050. ", worksheet.control_i8); end
  def test_control_j8; assert_equal("~5 1GW power stations starting from 2020 up to 2030 will be built, delivering ~35,040 GWh", worksheet.control_j8); end
  def test_control_k8; assert_equal("7.2 GW should become available by 2030 and remains constant up to 2050, delivering 50,457GWh of electricity", worksheet.control_k8); end
  def test_control_l8; assert_equal("~40 1 GW Capacity addition grows at the rate of 14% per annum from 2022 through to 2050 delivering 280,320GWh of electricity~40 1 GW Capacity addition grows at the rate of 14% per annum from 2022 through to 2050 delivering 280,320GWh of electricity", worksheet.control_l8); end
  def test_control_i9; assert_equal("No installation of wind power systems up to 2050.", worksheet.control_i9); end
  def test_control_j9; assert_equal("0.01GW wind power plant by 2020 and no more installation up to 2050 delivering 17.52GWh of electricity ", worksheet.control_j9); end
  def test_control_k9; assert_equal("1GW capacity of wind power plant should be available by 2030 delivering 1,752GWh of electricity", worksheet.control_k9); end
  def test_control_l9; assert_equal("14.7GW of wind power plant by 2050 delivering 25,735GWh of electricity", worksheet.control_l9); end
  def test_control_i10; assert_equal("1.94 GW total hydropower capacity is maintained to 2050 delivering 11,883GWh of electricity", worksheet.control_i10); end
  def test_control_j10; assert_equal("5.24 GW by 2030 through rehabilitating the existing hydropower to operate at full capacity and adding 3.3 GW large hydro power stations delivering 32,119GWh of electricity", worksheet.control_j10); end
  def test_control_k10; assert_equal("hydropower capacity reaches 6.99 GW by 2035 delivering 42,850GWh of electricity", worksheet.control_k10); end
  def test_control_l10; assert_equal("hydropower capacity reaches 15 GW by 2050 delivering 91,980 GWh of electricity", worksheet.control_l10); end
  def test_control_i11; assert_equal("0.064 GW of Small Hydropower capacity will be maintained up to 2050, which will generate approximately 0.28TWh of electricity ", worksheet.control_i11); end
  def test_control_j11; assert_equal("Small hydropower capacity reaches 0.53 GW by 2050 and will generate approximately 2.32TWh of electricity ", worksheet.control_j11); end
  def test_control_k11; assert_equal("small hydropower capacity reaches 1.75 GW by 2050. This capacity represents 47% of the country’s small hydropower potentials and will generate about 7.67TWh of electricity.", worksheet.control_k11); end
  def test_control_l11; assert_equal("Small hydropower capacity reaches 3.5 GW by 2050, through utilising about 95% of the country’s hydropower potentials. This capacity can generate 15.33TWh of electricity. ", worksheet.control_l11); end
  def test_control_i12; assert_equal("The grid connected solar PV’s contribution remains 0.7GW which produces 1.29TWh .", worksheet.control_i12); end
  def test_control_j12; assert_equal("The grid connected solar PV capacity reaches 2GW in 2020 producing and 9GW by 2050. This should produce 16.56TWh ", worksheet.control_j12); end
  def test_control_k12; assert_equal("The grid connected solar PV capacity reaches 25GW in 2050 thereby producing 43.97TWh. ", worksheet.control_k12); end
  def test_control_l12; assert_equal("The grid connected solar PV capacity reaches 110GW in 2050 by utilising 0.05% of Nigeria’s land mass which should produce 202.36TWh", worksheet.control_l12); end
  def test_control_i13; assert_equal("No deployment of solar CSP installations up to 2050.", worksheet.control_i13); end
  def test_control_j13; assert_equal("1GW CSP power plant by 2050 which should generate 1.84TWh of electricity", worksheet.control_j13); end
  def test_control_k13; assert_equal("10GW CSP power plant by 2050 contributing 18.4TWh of electricity", worksheet.control_k13); end
  def test_control_l13; assert_equal("40GW CSP power plant by 2050 contributing 73.58TWh of electricity", worksheet.control_l13); end
  def test_control_i14; assert_equal("Stand-alone solar PV’s contribution remains 4GW which produces 7.36TWh by 2050.", worksheet.control_i14); end
  def test_control_j14; assert_equal("Stand-alone solar PV’s capacity reaches 2GW in 2020 and 16GW by 2050. This should produce 29.4TWh", worksheet.control_j14); end
  def test_control_k14; assert_equal("Stand-alone solar PV’s capacity reaches 30GW in 2050 thereby producing 55.19TWh", worksheet.control_k14); end
  def test_control_l14; assert_equal("Stand-alone solar PV’s capacity reaches 60GW in 2050 by utilising 0.05% of Nigeria’s land mass which should produce 110.38TWh.", worksheet.control_l14); end
  def test_control_i15; assert_equal("No electricity imports", worksheet.control_i15); end
  def test_control_j15; assert_equal("1.3GW capacity shall be wheeled from Grand Inga hydro electric project by 2030 and remain the same up to 2050. With 5% transmission losses, 11TWh of electricity shall be imported.", worksheet.control_j15); end
  def test_control_k15; assert_equal("4 GW capacities shall be wheeled to Nigeria Grand Inga hydro electric project by 2030 and remain the same up to 2050. Considering 5% transmission losses, 35TWh shall be imported into the country.", worksheet.control_k15); end
  def test_control_l15; assert_equal("8 GW capacities shall be wheeled to Nigeria from grand Inga hydro electric project by 2050. Considering 5% transmission losses, 70TWh shall be imported.", worksheet.control_l15); end
  def test_control_i17; assert_equal("Energy crops and food production similar to today at 5% of land used", worksheet.control_i17); end
  def test_control_j17; assert_equal("11% of land used for energy crops", worksheet.control_j17); end
  def test_control_k17; assert_equal("19% of land used for energy crops", worksheet.control_k17); end
  def test_control_l17; assert_equal("19% of land used for energy crops", worksheet.control_l17); end
  def test_control_i18; assert_equal("Livestock numbers increase by 400%", worksheet.control_i18); end
  def test_control_j18; assert_equal("Livestock numbers increase by 900%", worksheet.control_j18); end
  def test_control_k18; assert_equal("Livestock numbers increase by 1,800%", worksheet.control_k18); end
  def test_control_l18; assert_equal("Livestock numbers increase by 3,800%", worksheet.control_l18); end
  def test_control_i19; assert_equal("Total waste generated is about 47% increase from 2010 level of 91 million tonnes of waste. ", worksheet.control_i19); end
  def test_control_j19; assert_equal("Total waste generated is about 33% increase from 2010 level of 91 million tonnes of waste. ", worksheet.control_j19); end
  def test_control_k19; assert_equal("Total waste generated is about 19% increase from 2010 level of 91 million tonnes of waste. ", worksheet.control_k19); end
  def test_control_l19; assert_equal("Total waste generated is about 21% reduction from 2010 level of 91 million tonnes of waste. ", worksheet.control_l19); end
  def test_control_i20; assert_equal("Biomass converted to a mixture of solid, liquid and gas biofuels", worksheet.control_i20); end
  def test_control_j20; assert_equal("Biomass mainly converted to solid biofuel", worksheet.control_j20); end
  def test_control_k20; assert_equal("Biomass mainly converted to liquid biofuel", worksheet.control_k20); end
  def test_control_l20; assert_equal("Biomass mainly converted to biogas fuel", worksheet.control_l20); end
  def test_control_i21; assert_equal("Imported biofuel declines from ~ 4 TWh/yr currently to zero", worksheet.control_i21); end
  def test_control_j21; assert_equal("Up to 70 TWh/yr of imported bioenergy in 2050", worksheet.control_j21); end
  def test_control_k21; assert_equal("Up to 140 TWh/yr of imported bioenergy in 2050", worksheet.control_k21); end
  def test_control_l21; assert_equal("Up to 280 TWh/yr of imported bioenergy in 2050", worksheet.control_l21); end
  def test_control_i24; assert_equal("Individuals travel will increase from 6,000km in 2010 to 12,000km by 2050.", worksheet.control_i24); end
  def test_control_j24; assert_equal("Individuals travel will increase from 6,000km in 2010 to 10,800km by 2050.", worksheet.control_j24); end
  def test_control_k24; assert_equal("Individuals travel will increase from 6,000km in 2010 to 9,600km by 2050.", worksheet.control_k24); end
  def test_control_l24; assert_equal("Individuals travel will increase from 6,000km in 2010 to 8,400km by 2050.", worksheet.control_l24); end
  def test_control_i25; assert_equal("100% liquid hydrocarbon by 2049", worksheet.control_i25); end
  def test_control_j25; assert_equal("90% liquid hydrocarbon and 10% Gaseous hydrocarbon by 2049", worksheet.control_j25); end
  def test_control_k25; assert_equal("75% liquid hydrocarbon and 25% Gaseous hydrocarbon by 2049", worksheet.control_k25); end
  def test_control_l25; assert_equal("60% liquid hydrocarbon and 40% Gaseous hydrocarbon by 2050", worksheet.control_l25); end
  def test_control_i26; assert_equal("100% Internal Combustion Engine (ICE) By 2050", worksheet.control_i26); end
  def test_control_j26; assert_equal("90% Internal Combustion Engine (ICE), 7% Hybrid Electric Vehicle (HEV) and 3% Electric Vehicle (EV) by 2050", worksheet.control_j26); end
  def test_control_k26; assert_equal("75% Internal Combustion Engine (ICE), 17% Hybrid Electric Vehicle (HEV) and 8% Electric Vehicle (EV) by 2051", worksheet.control_k26); end
  def test_control_l26; assert_equal("60% Internal Combustion Engine (ICE), 25% Hybrid Electric Vehicle (HEV) and 10% Electric Vehicle (EV) by 2051", worksheet.control_l26); end
  def test_control_i27; assert_equal("Road haulage makes up 73% of distance, using conventional engines. Rail all diesel", worksheet.control_i27); end
  def test_control_j27; assert_equal("Some shift from road to rail and water, and more efficient engines", worksheet.control_j27); end
  def test_control_k27; assert_equal("Greater modal shift to rail and water; more efficient HGVs; more efficient logistics", worksheet.control_k27); end
  def test_control_l27; assert_equal("Road modal share falls to half; greater hybridisation. Rail freight is all electric ", worksheet.control_l27); end
  def test_control_i29; assert_equal("Cooling demand increases 3.5 folds from 2010", worksheet.control_i29); end
  def test_control_j29; assert_equal("Cooling demand reduces by 20%", worksheet.control_j29); end
  def test_control_k29; assert_equal("Cooling demand reduces by 40%", worksheet.control_k29); end
  def test_control_l29; assert_equal("Cooling demand reduces by 60%", worksheet.control_l29); end
  def test_control_i30; assert_equal("Same as 2010", worksheet.control_i30); end
  def test_control_j30; assert_equal("10% more efficient", worksheet.control_j30); end
  def test_control_k30; assert_equal("20% more efficient", worksheet.control_k30); end
  def test_control_l30; assert_equal("30% more efficient", worksheet.control_l30); end
  def test_control_i32; assert_equal("Energy demand for Household lights and appliances increases by 1200%, and 150% for Cooking  (relative to 2010)", worksheet.control_i32); end
  def test_control_j32; assert_equal("Energy demand reduces by 25% for both  Household lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_j32); end
  def test_control_k32; assert_equal("Energy demand reduces by 50% for both  Household lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_k32); end
  def test_control_l32; assert_equal("Energy demand reduces by 75% for both  Household lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_l32); end
  def test_control_i33; assert_equal("Same as 2010, 80% Fuelwood, 12% Liquid hydrocarbon, 5% Gaseous hydrocarbon & 3% Electricity", worksheet.control_i33); end
  def test_control_j33; assert_equal("30% Reduction in Fuelwood:- 16% Liquid hydrocarbon,18% Gaseous hydrocarbon & 10% Electricity", worksheet.control_j33); end
  def test_control_k33; assert_equal("50% Reduction in Fuelwood:- 20% Liquid hydrocarbon, 25% Gaseous hydrocarbon & 15% Electricity", worksheet.control_k33); end
  def test_control_l33; assert_equal("80% Reduction in Fuelwood:- 24% Liquid hydrocarbon, 40% Gaseous hydrocarbon & 20% Electricity", worksheet.control_l33); end
  def test_control_i35; assert_equal("Nigeria industry energy demand will increase by 2104% by 2050", worksheet.control_i35); end
  def test_control_j35; assert_equal("Nigeria industry energy demand will fall by 75% compared to 2050 level", worksheet.control_j35); end
  def test_control_k35; assert_equal("Nigeria industry energy demand will fall by 50% compared to 2050 level", worksheet.control_k35); end
  def test_control_l35; assert_equal("Nigeria industry energy demand will fall by 30% compared to 2050 level", worksheet.control_l35); end
  def test_control_i36; assert_equal("No effort to reduce energy intensity", worksheet.control_i36); end
  def test_control_j36; assert_equal("20% reduction in energy intensity", worksheet.control_j36); end
  def test_control_k36; assert_equal("30% reduction in energy intensity", worksheet.control_k36); end
  def test_control_l36; assert_equal("50% reduction in energy intensity", worksheet.control_l36); end
  def test_control_i38; assert_equal("Cooling demand increases 3.5 folds from 2010", worksheet.control_i38); end
  def test_control_j38; assert_equal("Cooling demand reduces by 20%", worksheet.control_j38); end
  def test_control_k38; assert_equal("Cooling demand reduces by 40%", worksheet.control_k38); end
  def test_control_l38; assert_equal("Cooling demand reduces by 60%", worksheet.control_l38); end
  def test_control_i39; assert_equal("Same as 2010", worksheet.control_i39); end
  def test_control_j39; assert_equal("10% more efficient", worksheet.control_j39); end
  def test_control_k39; assert_equal("20% more efficient", worksheet.control_k39); end
  def test_control_l39; assert_equal("30% more efficient", worksheet.control_l39); end
  def test_control_i41; assert_equal("Energy demand for Service Sector lights and appliances increases by 1200%, and 150% for Cooking  (relative to 2010)", worksheet.control_i41); end
  def test_control_j41; assert_equal("Energy demand reduces by 25% for both  Service Sector lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_j41); end
  def test_control_k41; assert_equal("Energy demand reduces by 50% for both  Service Sector lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_k41); end
  def test_control_l41; assert_equal("Energy demand reduces by 75% for both  Service Sector lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_l41); end
  def test_control_i42; assert_equal("Same as 2010, 80% Fuelwood, 12% Liquid hydrocarbon, 5% Gaseous hydrocarbon & 3% Electricity", worksheet.control_i42); end
  def test_control_j42; assert_equal("30% Reduction in Fuelwood:- 16% Liquid hydrocarbon,18% Gaseous hydrocarbon & 10% Electricity", worksheet.control_j42); end
  def test_control_k42; assert_equal("50% Reduction in Fuelwood:- 20% Liquid hydrocarbon, 25% Gaseous hydrocarbon & 15% Electricity", worksheet.control_k42); end
  def test_control_l42; assert_equal("80% Reduction in Fuelwood:- 24% Liquid hydrocarbon, 40% Gaseous hydrocarbon & 20% Electricity", worksheet.control_l42); end
  def test_control_i44; assert_equal("Coal production will increase from minimal value of 0.046 million TCE to a high value of 135.12 million TCE by 2050", worksheet.control_i44); end
  def test_control_j44; assert_equal("Coal production will increase from minimal value of 0.046 million TCE to 49.13  million TCE by 2050", worksheet.control_j44); end
  def test_control_k44; assert_equal("Coal production will increase from minimal value of 0.046 million TCE to 12.28  million TCE by 2050.", worksheet.control_k44); end
  def test_control_i45; assert_equal("Crude oil production increase to 1,011.47 million boe ", worksheet.control_i45); end
  def test_control_j45; assert_equal("Crude oil production will remain same as 2010, at 919.52 million boe. ", worksheet.control_j45); end
  def test_control_k45; assert_equal("Crude oil production decreases to 873.54 million boe.", worksheet.control_k45); end
  def test_control_i46; assert_equal("Gas production will increase to 5.43Tcf while gas flaring reduces to 2%.", worksheet.control_i46); end
  def test_control_j46; assert_equal("Gas production will increase to 3.62Tcf,  and domestic consumption is expected to increases", worksheet.control_j46); end
  def test_control_k46; assert_equal("Gas production increases minimally to 3.26Tcf.", worksheet.control_k46); end
  def test_control_n4; assert_equal("Doesn't tackle climate change (All at level 1)", worksheet.control_n4); end
  def test_control_o4; assert_equal("Maximum demand, no supply", worksheet.control_o4); end
  def test_control_p4; assert_equal("Maximum supply, no demand", worksheet.control_p4); end
  def test_control_q4; assert_equal("Analogous to MAED & MESSAGE", worksheet.control_q4); end
  def test_control_r4; assert_equal("Higher renewables, more energy efficiency", worksheet.control_r4); end
  def test_control_s4; assert_equal("Introducing nuclear energy into the power mix", worksheet.control_s4); end
  def test_control_t4; assert_equal("Introducing Coal energy, more bioenergy", worksheet.control_t4); end
  def test_control_u4; assert_equal("Low cost pathway to be discussed?", worksheet.control_u4); end
  def test_control_v4; assert_equal("Friends of the Environment ", worksheet.control_v4); end
  def test_control_w4; assert_equal("Campaign to Protect Rural Nigeria", worksheet.control_w4); end
  def test_control_x4; assert_equal("Ministry of Power", worksheet.control_x4); end
  def test_control_y4; assert_equal("Transmission Company of Nigeria (TCN)-National Grid", worksheet.control_y4); end
  def test_control_z4; assert_equal("National Planning Commission", worksheet.control_z4); end
  def test_control_aa4; assert_equal("Federal Ministry of Environment", worksheet.control_aa4); end
  def test_control_n5; assert_in_delta(1.0, worksheet.control_n5, 0.002); end
  def test_control_o5; assert_in_delta(1.0, worksheet.control_o5, 0.002); end
  def test_control_p5; assert_in_delta(1.0, worksheet.control_p5, 0.002); end
  def test_control_q5; assert_in_delta(1.0, worksheet.control_q5, 0.002); end
  def test_control_r5; assert_in_delta(1.0, worksheet.control_r5, 0.002); end
  def test_control_s5; assert_in_delta(1.0, worksheet.control_s5, 0.002); end
  def test_control_t5; assert_in_delta(1.0, worksheet.control_t5, 0.002); end
  def test_control_u5; assert_in_delta(1.0, worksheet.control_u5, 0.002); end
  def test_control_v5; assert_in_delta(1.0, worksheet.control_v5, 0.002); end
  def test_control_w5; assert_in_delta(1.0, worksheet.control_w5, 0.002); end
  def test_control_x5; assert_in_delta(1.0, worksheet.control_x5, 0.002); end
  def test_control_y5; assert_in_delta(1.0, worksheet.control_y5, 0.002); end
  def test_control_z5; assert_in_delta(1.0, worksheet.control_z5, 0.002); end
  def test_control_aa5; assert_in_delta(1.0, worksheet.control_aa5, 0.002); end
  def test_control_n6; assert_in_delta(1.0, worksheet.control_n6, 0.002); end
  def test_control_o6; assert_in_delta(1.0, worksheet.control_o6, 0.002); end
  def test_control_p6; assert_in_delta(1.0, worksheet.control_p6, 0.002); end
  def test_control_q6; assert_in_delta(1.0, worksheet.control_q6, 0.002); end
  def test_control_r6; assert_in_delta(1.0, worksheet.control_r6, 0.002); end
  def test_control_s6; assert_in_delta(1.0, worksheet.control_s6, 0.002); end
  def test_control_t6; assert_in_delta(1.0, worksheet.control_t6, 0.002); end
  def test_control_u6; assert_in_delta(1.0, worksheet.control_u6, 0.002); end
  def test_control_v6; assert_in_delta(1.0, worksheet.control_v6, 0.002); end
  def test_control_w6; assert_in_delta(1.0, worksheet.control_w6, 0.002); end
  def test_control_x6; assert_in_delta(1.0, worksheet.control_x6, 0.002); end
  def test_control_y6; assert_in_delta(1.0, worksheet.control_y6, 0.002); end
  def test_control_z6; assert_in_delta(1.0, worksheet.control_z6, 0.002); end
  def test_control_aa6; assert_in_delta(1.0, worksheet.control_aa6, 0.002); end
  def test_control_n7; assert_in_delta(1.0, worksheet.control_n7, 0.002); end
  def test_control_o7; assert_in_delta(1.0, worksheet.control_o7, 0.002); end
  def test_control_p7; assert_in_delta(1.0, worksheet.control_p7, 0.002); end
  def test_control_q7; assert_in_delta(1.0, worksheet.control_q7, 0.002); end
  def test_control_r7; assert_in_delta(1.0, worksheet.control_r7, 0.002); end
  def test_control_s7; assert_in_delta(1.0, worksheet.control_s7, 0.002); end
  def test_control_t7; assert_in_delta(1.0, worksheet.control_t7, 0.002); end
  def test_control_u7; assert_in_delta(1.0, worksheet.control_u7, 0.002); end
  def test_control_v7; assert_in_delta(1.0, worksheet.control_v7, 0.002); end
  def test_control_w7; assert_in_delta(1.0, worksheet.control_w7, 0.002); end
  def test_control_x7; assert_in_delta(1.0, worksheet.control_x7, 0.002); end
  def test_control_y7; assert_in_delta(1.0, worksheet.control_y7, 0.002); end
  def test_control_z7; assert_in_delta(1.0, worksheet.control_z7, 0.002); end
  def test_control_aa7; assert_in_delta(1.0, worksheet.control_aa7, 0.002); end
  def test_control_n8; assert_in_delta(1.0, worksheet.control_n8, 0.002); end
  def test_control_o8; assert_in_delta(1.0, worksheet.control_o8, 0.002); end
  def test_control_p8; assert_in_delta(1.0, worksheet.control_p8, 0.002); end
  def test_control_q8; assert_in_delta(1.0, worksheet.control_q8, 0.002); end
  def test_control_r8; assert_in_delta(1.0, worksheet.control_r8, 0.002); end
  def test_control_s8; assert_in_delta(1.0, worksheet.control_s8, 0.002); end
  def test_control_t8; assert_in_delta(1.0, worksheet.control_t8, 0.002); end
  def test_control_u8; assert_in_delta(1.0, worksheet.control_u8, 0.002); end
  def test_control_v8; assert_in_delta(1.0, worksheet.control_v8, 0.002); end
  def test_control_w8; assert_in_delta(1.0, worksheet.control_w8, 0.002); end
  def test_control_x8; assert_in_delta(1.0, worksheet.control_x8, 0.002); end
  def test_control_y8; assert_in_delta(1.0, worksheet.control_y8, 0.002); end
  def test_control_z8; assert_in_delta(1.0, worksheet.control_z8, 0.002); end
  def test_control_aa8; assert_in_delta(1.0, worksheet.control_aa8, 0.002); end
  def test_control_n9; assert_in_delta(1.0, worksheet.control_n9, 0.002); end
  def test_control_o9; assert_in_delta(1.0, worksheet.control_o9, 0.002); end
  def test_control_p9; assert_in_delta(1.0, worksheet.control_p9, 0.002); end
  def test_control_q9; assert_in_delta(1.0, worksheet.control_q9, 0.002); end
  def test_control_r9; assert_in_delta(1.0, worksheet.control_r9, 0.002); end
  def test_control_s9; assert_in_delta(1.0, worksheet.control_s9, 0.002); end
  def test_control_t9; assert_in_delta(1.0, worksheet.control_t9, 0.002); end
  def test_control_u9; assert_in_delta(1.0, worksheet.control_u9, 0.002); end
  def test_control_v9; assert_in_delta(1.0, worksheet.control_v9, 0.002); end
  def test_control_w9; assert_in_delta(1.0, worksheet.control_w9, 0.002); end
  def test_control_x9; assert_in_delta(1.0, worksheet.control_x9, 0.002); end
  def test_control_y9; assert_in_delta(1.0, worksheet.control_y9, 0.002); end
  def test_control_z9; assert_in_delta(1.0, worksheet.control_z9, 0.002); end
  def test_control_aa9; assert_in_delta(1.0, worksheet.control_aa9, 0.002); end
  def test_control_n10; assert_in_delta(1.0, worksheet.control_n10, 0.002); end
  def test_control_o10; assert_in_delta(1.0, worksheet.control_o10, 0.002); end
  def test_control_p10; assert_in_delta(1.0, worksheet.control_p10, 0.002); end
  def test_control_q10; assert_in_delta(1.0, worksheet.control_q10, 0.002); end
  def test_control_r10; assert_in_delta(1.0, worksheet.control_r10, 0.002); end
  def test_control_s10; assert_in_delta(1.0, worksheet.control_s10, 0.002); end
  def test_control_t10; assert_in_delta(1.0, worksheet.control_t10, 0.002); end
  def test_control_u10; assert_in_delta(1.0, worksheet.control_u10, 0.002); end
  def test_control_v10; assert_in_delta(1.0, worksheet.control_v10, 0.002); end
  def test_control_w10; assert_in_delta(1.0, worksheet.control_w10, 0.002); end
  def test_control_x10; assert_in_delta(1.0, worksheet.control_x10, 0.002); end
  def test_control_y10; assert_in_delta(1.0, worksheet.control_y10, 0.002); end
  def test_control_z10; assert_in_delta(1.0, worksheet.control_z10, 0.002); end
  def test_control_aa10; assert_in_delta(1.0, worksheet.control_aa10, 0.002); end
  def test_control_n11; assert_in_delta(1.0, worksheet.control_n11, 0.002); end
  def test_control_o11; assert_in_delta(1.0, worksheet.control_o11, 0.002); end
  def test_control_p11; assert_in_delta(1.0, worksheet.control_p11, 0.002); end
  def test_control_q11; assert_in_delta(1.0, worksheet.control_q11, 0.002); end
  def test_control_r11; assert_in_delta(1.0, worksheet.control_r11, 0.002); end
  def test_control_s11; assert_in_delta(1.0, worksheet.control_s11, 0.002); end
  def test_control_t11; assert_in_delta(1.0, worksheet.control_t11, 0.002); end
  def test_control_u11; assert_in_delta(1.0, worksheet.control_u11, 0.002); end
  def test_control_v11; assert_in_delta(1.0, worksheet.control_v11, 0.002); end
  def test_control_w11; assert_in_delta(1.0, worksheet.control_w11, 0.002); end
  def test_control_x11; assert_in_delta(1.0, worksheet.control_x11, 0.002); end
  def test_control_y11; assert_in_delta(1.0, worksheet.control_y11, 0.002); end
  def test_control_z11; assert_in_delta(1.0, worksheet.control_z11, 0.002); end
  def test_control_aa11; assert_in_delta(1.0, worksheet.control_aa11, 0.002); end
  def test_control_n12; assert_in_delta(1.0, worksheet.control_n12, 0.002); end
  def test_control_o12; assert_in_delta(1.0, worksheet.control_o12, 0.002); end
  def test_control_p12; assert_in_delta(1.0, worksheet.control_p12, 0.002); end
  def test_control_q12; assert_in_delta(1.0, worksheet.control_q12, 0.002); end
  def test_control_r12; assert_in_delta(1.0, worksheet.control_r12, 0.002); end
  def test_control_s12; assert_in_delta(1.0, worksheet.control_s12, 0.002); end
  def test_control_t12; assert_in_delta(1.0, worksheet.control_t12, 0.002); end
  def test_control_u12; assert_in_delta(1.0, worksheet.control_u12, 0.002); end
  def test_control_v12; assert_in_delta(1.0, worksheet.control_v12, 0.002); end
  def test_control_w12; assert_in_delta(1.0, worksheet.control_w12, 0.002); end
  def test_control_x12; assert_in_delta(1.0, worksheet.control_x12, 0.002); end
  def test_control_y12; assert_in_delta(1.0, worksheet.control_y12, 0.002); end
  def test_control_z12; assert_in_delta(1.0, worksheet.control_z12, 0.002); end
  def test_control_aa12; assert_in_delta(1.0, worksheet.control_aa12, 0.002); end
  def test_control_n13; assert_in_delta(1.0, worksheet.control_n13, 0.002); end
  def test_control_o13; assert_in_delta(1.0, worksheet.control_o13, 0.002); end
  def test_control_p13; assert_in_delta(1.0, worksheet.control_p13, 0.002); end
  def test_control_q13; assert_in_delta(1.0, worksheet.control_q13, 0.002); end
  def test_control_r13; assert_in_delta(1.0, worksheet.control_r13, 0.002); end
  def test_control_s13; assert_in_delta(1.0, worksheet.control_s13, 0.002); end
  def test_control_t13; assert_in_delta(1.0, worksheet.control_t13, 0.002); end
  def test_control_u13; assert_in_delta(1.0, worksheet.control_u13, 0.002); end
  def test_control_v13; assert_in_delta(1.0, worksheet.control_v13, 0.002); end
  def test_control_w13; assert_in_delta(1.0, worksheet.control_w13, 0.002); end
  def test_control_x13; assert_in_delta(1.0, worksheet.control_x13, 0.002); end
  def test_control_y13; assert_in_delta(1.0, worksheet.control_y13, 0.002); end
  def test_control_z13; assert_in_delta(1.0, worksheet.control_z13, 0.002); end
  def test_control_aa13; assert_in_delta(1.0, worksheet.control_aa13, 0.002); end
  def test_control_n14; assert_in_delta(1.0, worksheet.control_n14, 0.002); end
  def test_control_o14; assert_in_delta(1.0, worksheet.control_o14, 0.002); end
  def test_control_p14; assert_in_delta(1.0, worksheet.control_p14, 0.002); end
  def test_control_q14; assert_in_delta(1.0, worksheet.control_q14, 0.002); end
  def test_control_r14; assert_in_delta(1.0, worksheet.control_r14, 0.002); end
  def test_control_s14; assert_in_delta(1.0, worksheet.control_s14, 0.002); end
  def test_control_t14; assert_in_delta(1.0, worksheet.control_t14, 0.002); end
  def test_control_u14; assert_in_delta(1.0, worksheet.control_u14, 0.002); end
  def test_control_v14; assert_in_delta(1.0, worksheet.control_v14, 0.002); end
  def test_control_w14; assert_in_delta(1.0, worksheet.control_w14, 0.002); end
  def test_control_x14; assert_in_delta(1.0, worksheet.control_x14, 0.002); end
  def test_control_y14; assert_in_delta(1.0, worksheet.control_y14, 0.002); end
  def test_control_z14; assert_in_delta(1.0, worksheet.control_z14, 0.002); end
  def test_control_aa14; assert_in_delta(1.0, worksheet.control_aa14, 0.002); end
  def test_control_n15; assert_in_delta(1.0, worksheet.control_n15, 0.002); end
  def test_control_o15; assert_in_delta(1.0, worksheet.control_o15, 0.002); end
  def test_control_p15; assert_in_delta(1.0, worksheet.control_p15, 0.002); end
  def test_control_q15; assert_in_delta(1.0, worksheet.control_q15, 0.002); end
  def test_control_r15; assert_in_delta(1.0, worksheet.control_r15, 0.002); end
  def test_control_s15; assert_in_delta(1.0, worksheet.control_s15, 0.002); end
  def test_control_t15; assert_in_delta(1.0, worksheet.control_t15, 0.002); end
  def test_control_u15; assert_in_delta(1.0, worksheet.control_u15, 0.002); end
  def test_control_v15; assert_in_delta(1.0, worksheet.control_v15, 0.002); end
  def test_control_w15; assert_in_delta(1.0, worksheet.control_w15, 0.002); end
  def test_control_x15; assert_in_delta(1.0, worksheet.control_x15, 0.002); end
  def test_control_y15; assert_in_delta(1.0, worksheet.control_y15, 0.002); end
  def test_control_z15; assert_in_delta(1.0, worksheet.control_z15, 0.002); end
  def test_control_aa15; assert_in_delta(1.0, worksheet.control_aa15, 0.002); end
  def test_control_n17; assert_in_delta(1.0, worksheet.control_n17, 0.002); end
  def test_control_o17; assert_in_delta(1.0, worksheet.control_o17, 0.002); end
  def test_control_p17; assert_in_delta(1.0, worksheet.control_p17, 0.002); end
  def test_control_q17; assert_in_delta(1.0, worksheet.control_q17, 0.002); end
  def test_control_r17; assert_in_delta(1.0, worksheet.control_r17, 0.002); end
  def test_control_s17; assert_in_delta(1.0, worksheet.control_s17, 0.002); end
  def test_control_t17; assert_in_delta(1.0, worksheet.control_t17, 0.002); end
  def test_control_u17; assert_in_delta(1.0, worksheet.control_u17, 0.002); end
  def test_control_v17; assert_in_delta(1.0, worksheet.control_v17, 0.002); end
  def test_control_w17; assert_in_delta(1.0, worksheet.control_w17, 0.002); end
  def test_control_x17; assert_in_delta(1.0, worksheet.control_x17, 0.002); end
  def test_control_y17; assert_in_delta(1.0, worksheet.control_y17, 0.002); end
  def test_control_z17; assert_in_delta(1.0, worksheet.control_z17, 0.002); end
  def test_control_aa17; assert_in_delta(1.0, worksheet.control_aa17, 0.002); end
  def test_control_n18; assert_in_delta(1.0, worksheet.control_n18, 0.002); end
  def test_control_o18; assert_in_delta(1.0, worksheet.control_o18, 0.002); end
  def test_control_p18; assert_in_epsilon(4.0, worksheet.control_p18, 0.002); end
  def test_control_q18; assert_in_epsilon(3.0, worksheet.control_q18, 0.002); end
  def test_control_r18; assert_in_epsilon(2.0, worksheet.control_r18, 0.002); end
  def test_control_s18; assert_in_epsilon(4.0, worksheet.control_s18, 0.002); end
  def test_control_t18; assert_in_epsilon(3.0, worksheet.control_t18, 0.002); end
  def test_control_u18; assert_in_epsilon(3.0, worksheet.control_u18, 0.002); end
  def test_control_v18; assert_in_epsilon(2.0, worksheet.control_v18, 0.002); end
  def test_control_w18; assert_in_epsilon(2.0, worksheet.control_w18, 0.002); end
  def test_control_x18; assert_in_epsilon(3.0, worksheet.control_x18, 0.002); end
  def test_control_y18; assert_in_epsilon(3.0, worksheet.control_y18, 0.002); end
  def test_control_z18; assert_in_epsilon(3.0, worksheet.control_z18, 0.002); end
  def test_control_aa18; assert_in_delta(1.0, worksheet.control_aa18, 0.002); end
  def test_control_n19; assert_in_delta(1.0, worksheet.control_n19, 0.002); end
  def test_control_o19; assert_in_delta(1.0, worksheet.control_o19, 0.002); end
  def test_control_p19; assert_in_epsilon(4.0, worksheet.control_p19, 0.002); end
  def test_control_q19; assert_in_epsilon(2.0, worksheet.control_q19, 0.002); end
  def test_control_r19; assert_in_epsilon(2.0, worksheet.control_r19, 0.002); end
  def test_control_s19; assert_in_epsilon(2.0, worksheet.control_s19, 0.002); end
  def test_control_t19; assert_in_epsilon(2.0, worksheet.control_t19, 0.002); end
  def test_control_u19; assert_in_epsilon(2.0, worksheet.control_u19, 0.002); end
  def test_control_v19; assert_in_epsilon(4.0, worksheet.control_v19, 0.002); end
  def test_control_w19; assert_in_epsilon(3.0, worksheet.control_w19, 0.002); end
  def test_control_x19; assert_in_epsilon(4.0, worksheet.control_x19, 0.002); end
  def test_control_y19; assert_in_epsilon(2.0, worksheet.control_y19, 0.002); end
  def test_control_z19; assert_in_epsilon(4.0, worksheet.control_z19, 0.002); end
  def test_control_aa19; assert_in_delta(1.0, worksheet.control_aa19, 0.002); end
  def test_control_n20; assert_in_delta(1.0, worksheet.control_n20, 0.002); end
  def test_control_o20; assert_in_delta(1.0, worksheet.control_o20, 0.002); end
  def test_control_p20; assert_in_epsilon(4.0, worksheet.control_p20, 0.002); end
  def test_control_q20; assert_in_delta(1.0, worksheet.control_q20, 0.002); end
  def test_control_r20; assert_in_delta(1.0, worksheet.control_r20, 0.002); end
  def test_control_s20; assert_in_epsilon(3.0, worksheet.control_s20, 0.002); end
  def test_control_t20; assert_in_delta(1.0, worksheet.control_t20, 0.002); end
  def test_control_u20; assert_in_delta(1.0, worksheet.control_u20, 0.002); end
  def test_control_v20; assert_in_delta(1.0, worksheet.control_v20, 0.002); end
  def test_control_w20; assert_in_delta(1.0, worksheet.control_w20, 0.002); end
  def test_control_x20; assert_in_epsilon(3.0, worksheet.control_x20, 0.002); end
  def test_control_y20; assert_in_epsilon(2.0, worksheet.control_y20, 0.002); end
  def test_control_z20; assert_in_delta(1.0, worksheet.control_z20, 0.002); end
  def test_control_aa20; assert_in_delta(1.0, worksheet.control_aa20, 0.002); end
  def test_control_n21; assert_in_delta(1.0, worksheet.control_n21, 0.002); end
  def test_control_o21; assert_in_delta(1.0, worksheet.control_o21, 0.002); end
  def test_control_p21; assert_in_epsilon(4.0, worksheet.control_p21, 0.002); end
  def test_control_q21; assert_in_epsilon(2.5, worksheet.control_q21, 0.002); end
  def test_control_r21; assert_in_epsilon(2.0, worksheet.control_r21, 0.002); end
  def test_control_s21; assert_in_epsilon(3.7, worksheet.control_s21, 0.002); end
  def test_control_t21; assert_in_epsilon(3.0, worksheet.control_t21, 0.002); end
  def test_control_u21; assert_in_epsilon(2.1, worksheet.control_u21, 0.002); end
  def test_control_v21; assert_in_delta(1.0, worksheet.control_v21, 0.002); end
  def test_control_w21; assert_in_epsilon(2.0, worksheet.control_w21, 0.002); end
  def test_control_x21; assert_in_delta(1.0, worksheet.control_x21, 0.002); end
  def test_control_y21; assert_in_epsilon(2.0, worksheet.control_y21, 0.002); end
  def test_control_z21; assert_in_delta(1.0, worksheet.control_z21, 0.002); end
  def test_control_aa21; assert_in_delta(1.0, worksheet.control_aa21, 0.002); end
  def test_control_n24; assert_in_delta(1.0, worksheet.control_n24, 0.002); end
  def test_control_o24; assert_in_delta(1.0, worksheet.control_o24, 0.002); end
  def test_control_p24; assert_in_delta(1.0, worksheet.control_p24, 0.002); end
  def test_control_q24; assert_in_delta(1.0, worksheet.control_q24, 0.002); end
  def test_control_r24; assert_in_delta(1.0, worksheet.control_r24, 0.002); end
  def test_control_s24; assert_in_delta(1.0, worksheet.control_s24, 0.002); end
  def test_control_t24; assert_in_delta(1.0, worksheet.control_t24, 0.002); end
  def test_control_u24; assert_in_delta(1.0, worksheet.control_u24, 0.002); end
  def test_control_v24; assert_in_delta(1.0, worksheet.control_v24, 0.002); end
  def test_control_w24; assert_in_delta(1.0, worksheet.control_w24, 0.002); end
  def test_control_x24; assert_in_delta(1.0, worksheet.control_x24, 0.002); end
  def test_control_y24; assert_in_delta(1.0, worksheet.control_y24, 0.002); end
  def test_control_z24; assert_in_delta(1.0, worksheet.control_z24, 0.002); end
  def test_control_aa24; assert_in_delta(1.0, worksheet.control_aa24, 0.002); end
  def test_control_n25; assert_in_delta(1.0, worksheet.control_n25, 0.002); end
  def test_control_o25; assert_in_delta(1.0, worksheet.control_o25, 0.002); end
  def test_control_p25; assert_in_delta(1.0, worksheet.control_p25, 0.002); end
  def test_control_q25; assert_in_delta(1.0, worksheet.control_q25, 0.002); end
  def test_control_r25; assert_in_delta(1.0, worksheet.control_r25, 0.002); end
  def test_control_s25; assert_in_delta(1.0, worksheet.control_s25, 0.002); end
  def test_control_t25; assert_in_delta(1.0, worksheet.control_t25, 0.002); end
  def test_control_u25; assert_in_delta(1.0, worksheet.control_u25, 0.002); end
  def test_control_v25; assert_in_delta(1.0, worksheet.control_v25, 0.002); end
  def test_control_w25; assert_in_delta(1.0, worksheet.control_w25, 0.002); end
  def test_control_x25; assert_in_delta(1.0, worksheet.control_x25, 0.002); end
  def test_control_y25; assert_in_delta(1.0, worksheet.control_y25, 0.002); end
  def test_control_z25; assert_in_delta(1.0, worksheet.control_z25, 0.002); end
  def test_control_aa25; assert_in_delta(1.0, worksheet.control_aa25, 0.002); end
  def test_control_n26; assert_in_delta(1.0, worksheet.control_n26, 0.002); end
  def test_control_o26; assert_in_delta(1.0, worksheet.control_o26, 0.002); end
  def test_control_p26; assert_in_delta(1.0, worksheet.control_p26, 0.002); end
  def test_control_q26; assert_in_delta(1.0, worksheet.control_q26, 0.002); end
  def test_control_r26; assert_in_delta(1.0, worksheet.control_r26, 0.002); end
  def test_control_s26; assert_in_delta(1.0, worksheet.control_s26, 0.002); end
  def test_control_t26; assert_in_delta(1.0, worksheet.control_t26, 0.002); end
  def test_control_u26; assert_in_delta(1.0, worksheet.control_u26, 0.002); end
  def test_control_v26; assert_in_delta(1.0, worksheet.control_v26, 0.002); end
  def test_control_w26; assert_in_delta(1.0, worksheet.control_w26, 0.002); end
  def test_control_x26; assert_in_delta(1.0, worksheet.control_x26, 0.002); end
  def test_control_y26; assert_in_delta(1.0, worksheet.control_y26, 0.002); end
  def test_control_z26; assert_in_delta(1.0, worksheet.control_z26, 0.002); end
  def test_control_aa26; assert_in_delta(1.0, worksheet.control_aa26, 0.002); end
  def test_control_n27; assert_in_delta(1.0, worksheet.control_n27, 0.002); end
  def test_control_o27; assert_in_delta(1.0, worksheet.control_o27, 0.002); end
  def test_control_p27; assert_in_delta(1.0, worksheet.control_p27, 0.002); end
  def test_control_q27; assert_in_delta(1.0, worksheet.control_q27, 0.002); end
  def test_control_r27; assert_in_delta(1.0, worksheet.control_r27, 0.002); end
  def test_control_s27; assert_in_delta(1.0, worksheet.control_s27, 0.002); end
  def test_control_t27; assert_in_delta(1.0, worksheet.control_t27, 0.002); end
  def test_control_u27; assert_in_delta(1.0, worksheet.control_u27, 0.002); end
  def test_control_v27; assert_in_delta(1.0, worksheet.control_v27, 0.002); end
  def test_control_w27; assert_in_delta(1.0, worksheet.control_w27, 0.002); end
  def test_control_x27; assert_in_delta(1.0, worksheet.control_x27, 0.002); end
  def test_control_y27; assert_in_delta(1.0, worksheet.control_y27, 0.002); end
  def test_control_z27; assert_in_delta(1.0, worksheet.control_z27, 0.002); end
  def test_control_aa27; assert_in_delta(1.0, worksheet.control_aa27, 0.002); end
  def test_control_n28; assert_in_delta(1.0, worksheet.control_n28, 0.002); end
  def test_control_o28; assert_in_delta(1.0, worksheet.control_o28, 0.002); end
  def test_control_p28; assert_in_delta(1.0, worksheet.control_p28, 0.002); end
  def test_control_q28; assert_in_delta(1.0, worksheet.control_q28, 0.002); end
  def test_control_r28; assert_in_delta(1.0, worksheet.control_r28, 0.002); end
  def test_control_s28; assert_in_delta(1.0, worksheet.control_s28, 0.002); end
  def test_control_t28; assert_in_delta(1.0, worksheet.control_t28, 0.002); end
  def test_control_u28; assert_in_delta(1.0, worksheet.control_u28, 0.002); end
  def test_control_v28; assert_in_delta(1.0, worksheet.control_v28, 0.002); end
  def test_control_w28; assert_in_delta(1.0, worksheet.control_w28, 0.002); end
  def test_control_x28; assert_in_delta(1.0, worksheet.control_x28, 0.002); end
  def test_control_y28; assert_in_delta(1.0, worksheet.control_y28, 0.002); end
  def test_control_z28; assert_in_delta(1.0, worksheet.control_z28, 0.002); end
  def test_control_aa28; assert_in_delta(1.0, worksheet.control_aa28, 0.002); end
  def test_control_n29; assert_in_delta(1.0, worksheet.control_n29, 0.002); end
  def test_control_o29; assert_in_delta(1.0, worksheet.control_o29, 0.002); end
  def test_control_p29; assert_in_delta(1.0, worksheet.control_p29, 0.002); end
  def test_control_q29; assert_in_delta(1.0, worksheet.control_q29, 0.002); end
  def test_control_r29; assert_in_delta(1.0, worksheet.control_r29, 0.002); end
  def test_control_s29; assert_in_delta(1.0, worksheet.control_s29, 0.002); end
  def test_control_t29; assert_in_delta(1.0, worksheet.control_t29, 0.002); end
  def test_control_u29; assert_in_delta(1.0, worksheet.control_u29, 0.002); end
  def test_control_v29; assert_in_delta(1.0, worksheet.control_v29, 0.002); end
  def test_control_w29; assert_in_delta(1.0, worksheet.control_w29, 0.002); end
  def test_control_x29; assert_in_delta(1.0, worksheet.control_x29, 0.002); end
  def test_control_y29; assert_in_delta(1.0, worksheet.control_y29, 0.002); end
  def test_control_z29; assert_in_delta(1.0, worksheet.control_z29, 0.002); end
  def test_control_aa29; assert_in_delta(1.0, worksheet.control_aa29, 0.002); end
  def test_control_n30; assert_in_delta(1.0, worksheet.control_n30, 0.002); end
  def test_control_o30; assert_in_delta(1.0, worksheet.control_o30, 0.002); end
  def test_control_p30; assert_in_delta(1.0, worksheet.control_p30, 0.002); end
  def test_control_q30; assert_in_delta(1.0, worksheet.control_q30, 0.002); end
  def test_control_r30; assert_in_delta(1.0, worksheet.control_r30, 0.002); end
  def test_control_s30; assert_in_delta(1.0, worksheet.control_s30, 0.002); end
  def test_control_t30; assert_in_delta(1.0, worksheet.control_t30, 0.002); end
  def test_control_u30; assert_in_delta(1.0, worksheet.control_u30, 0.002); end
  def test_control_v30; assert_in_delta(1.0, worksheet.control_v30, 0.002); end
  def test_control_w30; assert_in_delta(1.0, worksheet.control_w30, 0.002); end
  def test_control_x30; assert_in_delta(1.0, worksheet.control_x30, 0.002); end
  def test_control_y30; assert_in_delta(1.0, worksheet.control_y30, 0.002); end
  def test_control_z30; assert_in_delta(1.0, worksheet.control_z30, 0.002); end
  def test_control_aa30; assert_in_delta(1.0, worksheet.control_aa30, 0.002); end
  def test_control_n32; assert_in_delta(1.0, worksheet.control_n32, 0.002); end
  def test_control_o32; assert_in_delta(1.0, worksheet.control_o32, 0.002); end
  def test_control_p32; assert_in_delta(1.0, worksheet.control_p32, 0.002); end
  def test_control_q32; assert_in_delta(1.0, worksheet.control_q32, 0.002); end
  def test_control_r32; assert_in_delta(1.0, worksheet.control_r32, 0.002); end
  def test_control_s32; assert_in_delta(1.0, worksheet.control_s32, 0.002); end
  def test_control_t32; assert_in_delta(1.0, worksheet.control_t32, 0.002); end
  def test_control_u32; assert_in_delta(1.0, worksheet.control_u32, 0.002); end
  def test_control_v32; assert_in_delta(1.0, worksheet.control_v32, 0.002); end
  def test_control_w32; assert_in_delta(1.0, worksheet.control_w32, 0.002); end
  def test_control_x32; assert_in_delta(1.0, worksheet.control_x32, 0.002); end
  def test_control_y32; assert_in_delta(1.0, worksheet.control_y32, 0.002); end
  def test_control_z32; assert_in_delta(1.0, worksheet.control_z32, 0.002); end
  def test_control_aa32; assert_in_delta(1.0, worksheet.control_aa32, 0.002); end
  def test_control_n33; assert_in_delta(1.0, worksheet.control_n33, 0.002); end
  def test_control_o33; assert_in_delta(1.0, worksheet.control_o33, 0.002); end
  def test_control_p33; assert_in_delta(1.0, worksheet.control_p33, 0.002); end
  def test_control_q33; assert_in_delta(1.0, worksheet.control_q33, 0.002); end
  def test_control_r33; assert_in_delta(1.0, worksheet.control_r33, 0.002); end
  def test_control_s33; assert_in_delta(1.0, worksheet.control_s33, 0.002); end
  def test_control_t33; assert_in_delta(1.0, worksheet.control_t33, 0.002); end
  def test_control_u33; assert_in_delta(1.0, worksheet.control_u33, 0.002); end
  def test_control_v33; assert_in_delta(1.0, worksheet.control_v33, 0.002); end
  def test_control_w33; assert_in_delta(1.0, worksheet.control_w33, 0.002); end
  def test_control_x33; assert_in_delta(1.0, worksheet.control_x33, 0.002); end
  def test_control_y33; assert_in_delta(1.0, worksheet.control_y33, 0.002); end
  def test_control_z33; assert_in_delta(1.0, worksheet.control_z33, 0.002); end
  def test_control_aa33; assert_in_delta(1.0, worksheet.control_aa33, 0.002); end
  def test_control_n35; assert_in_delta(1.0, worksheet.control_n35, 0.002); end
  def test_control_o35; assert_in_delta(1.0, worksheet.control_o35, 0.002); end
  def test_control_p35; assert_in_delta(1.0, worksheet.control_p35, 0.002); end
  def test_control_q35; assert_in_delta(1.0, worksheet.control_q35, 0.002); end
  def test_control_r35; assert_in_delta(1.0, worksheet.control_r35, 0.002); end
  def test_control_s35; assert_in_delta(1.0, worksheet.control_s35, 0.002); end
  def test_control_t35; assert_in_delta(1.0, worksheet.control_t35, 0.002); end
  def test_control_u35; assert_in_delta(1.0, worksheet.control_u35, 0.002); end
  def test_control_v35; assert_in_delta(1.0, worksheet.control_v35, 0.002); end
  def test_control_w35; assert_in_delta(1.0, worksheet.control_w35, 0.002); end
  def test_control_x35; assert_in_delta(1.0, worksheet.control_x35, 0.002); end
  def test_control_y35; assert_in_delta(1.0, worksheet.control_y35, 0.002); end
  def test_control_z35; assert_in_delta(1.0, worksheet.control_z35, 0.002); end
  def test_control_aa35; assert_in_delta(1.0, worksheet.control_aa35, 0.002); end
  def test_control_n36; assert_in_delta(1.0, worksheet.control_n36, 0.002); end
  def test_control_o36; assert_in_delta(1.0, worksheet.control_o36, 0.002); end
  def test_control_p36; assert_in_delta(1.0, worksheet.control_p36, 0.002); end
  def test_control_q36; assert_in_delta(1.0, worksheet.control_q36, 0.002); end
  def test_control_r36; assert_in_delta(1.0, worksheet.control_r36, 0.002); end
  def test_control_s36; assert_in_delta(1.0, worksheet.control_s36, 0.002); end
  def test_control_t36; assert_in_delta(1.0, worksheet.control_t36, 0.002); end
  def test_control_u36; assert_in_delta(1.0, worksheet.control_u36, 0.002); end
  def test_control_v36; assert_in_delta(1.0, worksheet.control_v36, 0.002); end
  def test_control_w36; assert_in_delta(1.0, worksheet.control_w36, 0.002); end
  def test_control_x36; assert_in_delta(1.0, worksheet.control_x36, 0.002); end
  def test_control_y36; assert_in_delta(1.0, worksheet.control_y36, 0.002); end
  def test_control_z36; assert_in_delta(1.0, worksheet.control_z36, 0.002); end
  def test_control_aa36; assert_in_delta(1.0, worksheet.control_aa36, 0.002); end
  def test_control_n37; assert_in_delta(1.0, worksheet.control_n37, 0.002); end
  def test_control_o37; assert_in_delta(1.0, worksheet.control_o37, 0.002); end
  def test_control_p37; assert_in_delta(1.0, worksheet.control_p37, 0.002); end
  def test_control_q37; assert_in_delta(1.0, worksheet.control_q37, 0.002); end
  def test_control_r37; assert_in_delta(1.0, worksheet.control_r37, 0.002); end
  def test_control_s37; assert_in_delta(1.0, worksheet.control_s37, 0.002); end
  def test_control_t37; assert_in_delta(1.0, worksheet.control_t37, 0.002); end
  def test_control_u37; assert_in_delta(1.0, worksheet.control_u37, 0.002); end
  def test_control_v37; assert_in_delta(1.0, worksheet.control_v37, 0.002); end
  def test_control_w37; assert_in_delta(1.0, worksheet.control_w37, 0.002); end
  def test_control_x37; assert_in_delta(1.0, worksheet.control_x37, 0.002); end
  def test_control_y37; assert_in_delta(1.0, worksheet.control_y37, 0.002); end
  def test_control_z37; assert_in_delta(1.0, worksheet.control_z37, 0.002); end
  def test_control_aa37; assert_in_delta(1.0, worksheet.control_aa37, 0.002); end
  def test_control_n38; assert_in_delta(1.0, worksheet.control_n38, 0.002); end
  def test_control_o38; assert_in_delta(1.0, worksheet.control_o38, 0.002); end
  def test_control_p38; assert_in_delta(1.0, worksheet.control_p38, 0.002); end
  def test_control_q38; assert_in_delta(1.0, worksheet.control_q38, 0.002); end
  def test_control_r38; assert_in_delta(1.0, worksheet.control_r38, 0.002); end
  def test_control_s38; assert_in_delta(1.0, worksheet.control_s38, 0.002); end
  def test_control_t38; assert_in_delta(1.0, worksheet.control_t38, 0.002); end
  def test_control_u38; assert_in_delta(1.0, worksheet.control_u38, 0.002); end
  def test_control_v38; assert_in_delta(1.0, worksheet.control_v38, 0.002); end
  def test_control_w38; assert_in_delta(1.0, worksheet.control_w38, 0.002); end
  def test_control_x38; assert_in_delta(1.0, worksheet.control_x38, 0.002); end
  def test_control_y38; assert_in_delta(1.0, worksheet.control_y38, 0.002); end
  def test_control_z38; assert_in_delta(1.0, worksheet.control_z38, 0.002); end
  def test_control_aa38; assert_in_delta(1.0, worksheet.control_aa38, 0.002); end
  def test_control_n39; assert_in_delta(1.0, worksheet.control_n39, 0.002); end
  def test_control_o39; assert_in_delta(1.0, worksheet.control_o39, 0.002); end
  def test_control_p39; assert_in_delta(1.0, worksheet.control_p39, 0.002); end
  def test_control_q39; assert_in_delta(1.0, worksheet.control_q39, 0.002); end
  def test_control_r39; assert_in_delta(1.0, worksheet.control_r39, 0.002); end
  def test_control_s39; assert_in_delta(1.0, worksheet.control_s39, 0.002); end
  def test_control_t39; assert_in_delta(1.0, worksheet.control_t39, 0.002); end
  def test_control_u39; assert_in_delta(1.0, worksheet.control_u39, 0.002); end
  def test_control_v39; assert_in_delta(1.0, worksheet.control_v39, 0.002); end
  def test_control_w39; assert_in_delta(1.0, worksheet.control_w39, 0.002); end
  def test_control_x39; assert_in_delta(1.0, worksheet.control_x39, 0.002); end
  def test_control_y39; assert_in_delta(1.0, worksheet.control_y39, 0.002); end
  def test_control_z39; assert_in_delta(1.0, worksheet.control_z39, 0.002); end
  def test_control_aa39; assert_in_delta(1.0, worksheet.control_aa39, 0.002); end
  def test_control_n41; assert_in_delta(1.0, worksheet.control_n41, 0.002); end
  def test_control_o41; assert_in_epsilon(4.0, worksheet.control_o41, 0.002); end
  def test_control_p41; assert_in_delta(1.0, worksheet.control_p41, 0.002); end
  def test_control_q41; assert_in_epsilon(4.0, worksheet.control_q41, 0.002); end
  def test_control_r41; assert_in_epsilon(4.0, worksheet.control_r41, 0.002); end
  def test_control_s41; assert_in_epsilon(2.0, worksheet.control_s41, 0.002); end
  def test_control_t41; assert_in_epsilon(3.0, worksheet.control_t41, 0.002); end
  def test_control_u41; assert_in_epsilon(4.0, worksheet.control_u41, 0.002); end
  def test_control_v41; assert_in_epsilon(4.0, worksheet.control_v41, 0.002); end
  def test_control_w41; assert_in_epsilon(4.0, worksheet.control_w41, 0.002); end
  def test_control_x41; assert_in_epsilon(4.0, worksheet.control_x41, 0.002); end
  def test_control_y41; assert_in_epsilon(3.0, worksheet.control_y41, 0.002); end
  def test_control_z41; assert_in_epsilon(4.0, worksheet.control_z41, 0.002); end
  def test_control_aa41; assert_in_delta(1.0, worksheet.control_aa41, 0.002); end
  def test_control_n42; assert_in_delta(1.0, worksheet.control_n42, 0.002); end
  def test_control_o42; assert_in_epsilon(2.0, worksheet.control_o42, 0.002); end
  def test_control_p42; assert_in_delta(1.0, worksheet.control_p42, 0.002); end
  def test_control_q42; assert_in_epsilon(2.0, worksheet.control_q42, 0.002); end
  def test_control_r42; assert_in_epsilon(2.0, worksheet.control_r42, 0.002); end
  def test_control_s42; assert_in_epsilon(2.0, worksheet.control_s42, 0.002); end
  def test_control_t42; assert_in_delta(1.0, worksheet.control_t42, 0.002); end
  def test_control_u42; assert_in_delta(1.0, worksheet.control_u42, 0.002); end
  def test_control_v42; assert_in_epsilon(2.0, worksheet.control_v42, 0.002); end
  def test_control_w42; assert_in_delta(1.0, worksheet.control_w42, 0.002); end
  def test_control_x42; assert_in_epsilon(2.0, worksheet.control_x42, 0.002); end
  def test_control_y42; assert_in_epsilon(2.0, worksheet.control_y42, 0.002); end
  def test_control_z42; assert_in_epsilon(2.0, worksheet.control_z42, 0.002); end
  def test_control_aa42; assert_in_delta(1.0, worksheet.control_aa42, 0.002); end
  def test_control_n44; assert_in_delta(1.0, worksheet.control_n44, 0.002); end
  def test_control_o44; assert_in_delta(1.0, worksheet.control_o44, 0.002); end
  def test_control_p44; assert_in_delta(1.0, worksheet.control_p44, 0.002); end
  def test_control_q44; assert_in_delta(1.0, worksheet.control_q44, 0.002); end
  def test_control_r44; assert_in_delta(1.0, worksheet.control_r44, 0.002); end
  def test_control_s44; assert_in_delta(1.0, worksheet.control_s44, 0.002); end
  def test_control_t44; assert_in_delta(1.0, worksheet.control_t44, 0.002); end
  def test_control_u44; assert_in_delta(1.0, worksheet.control_u44, 0.002); end
  def test_control_v44; assert_in_delta(1.0, worksheet.control_v44, 0.002); end
  def test_control_w44; assert_in_delta(1.0, worksheet.control_w44, 0.002); end
  def test_control_x44; assert_in_delta(1.0, worksheet.control_x44, 0.002); end
  def test_control_y44; assert_in_delta(1.0, worksheet.control_y44, 0.002); end
  def test_control_z44; assert_in_delta(1.0, worksheet.control_z44, 0.002); end
  def test_control_aa44; assert_in_delta(1.0, worksheet.control_aa44, 0.002); end
  def test_control_n45; assert_in_delta(1.0, worksheet.control_n45, 0.002); end
  def test_control_o45; assert_in_delta(1.0, worksheet.control_o45, 0.002); end
  def test_control_p45; assert_in_delta(1.0, worksheet.control_p45, 0.002); end
  def test_control_q45; assert_in_delta(1.0, worksheet.control_q45, 0.002); end
  def test_control_r45; assert_in_delta(1.0, worksheet.control_r45, 0.002); end
  def test_control_s45; assert_in_delta(1.0, worksheet.control_s45, 0.002); end
  def test_control_t45; assert_in_delta(1.0, worksheet.control_t45, 0.002); end
  def test_control_u45; assert_in_delta(1.0, worksheet.control_u45, 0.002); end
  def test_control_v45; assert_in_delta(1.0, worksheet.control_v45, 0.002); end
  def test_control_w45; assert_in_delta(1.0, worksheet.control_w45, 0.002); end
  def test_control_x45; assert_in_delta(1.0, worksheet.control_x45, 0.002); end
  def test_control_y45; assert_in_delta(1.0, worksheet.control_y45, 0.002); end
  def test_control_z45; assert_in_delta(1.0, worksheet.control_z45, 0.002); end
  def test_control_aa45; assert_in_delta(1.0, worksheet.control_aa45, 0.002); end
  def test_control_n46; assert_in_delta(1.0, worksheet.control_n46, 0.002); end
  def test_control_o46; assert_in_delta(1.0, worksheet.control_o46, 0.002); end
  def test_control_p46; assert_in_delta(1.0, worksheet.control_p46, 0.002); end
  def test_control_q46; assert_in_delta(1.0, worksheet.control_q46, 0.002); end
  def test_control_r46; assert_in_delta(1.0, worksheet.control_r46, 0.002); end
  def test_control_s46; assert_in_delta(1.0, worksheet.control_s46, 0.002); end
  def test_control_t46; assert_in_delta(1.0, worksheet.control_t46, 0.002); end
  def test_control_u46; assert_in_delta(1.0, worksheet.control_u46, 0.002); end
  def test_control_v46; assert_in_delta(1.0, worksheet.control_v46, 0.002); end
  def test_control_w46; assert_in_delta(1.0, worksheet.control_w46, 0.002); end
  def test_control_x46; assert_in_delta(1.0, worksheet.control_x46, 0.002); end
  def test_control_y46; assert_in_delta(1.0, worksheet.control_y46, 0.002); end
  def test_control_z46; assert_in_delta(1.0, worksheet.control_z46, 0.002); end
  def test_control_aa46; assert_in_delta(1.0, worksheet.control_aa46, 0.002); end
  def test_control_n47; assert_equal("Imported natural gas for electricity and heat. Imported oil for vehicles.", worksheet.control_n47); end
  def test_control_p47; assert_equal("Cost-optimising model based. Mix of supply sources. Ambitious demand reduction.", worksheet.control_p47); end
  def test_control_q47; assert_equal("Renewables largest supply component. Very ambitious demand reduction. Lots of storage.", worksheet.control_q47); end
  def test_control_r47; assert_equal("Lots of nuclear. Moderate energy demand reduction. Minimal renewables.", worksheet.control_r47); end
  def test_control_s47; assert_equal("Lots of CCS and biomass co-firing. Ambitious demand reduction. ", worksheet.control_s47); end
  def test_control_t47; assert_equal("TBD", worksheet.control_t47); end
  def test_control_u47; assert_equal("Generation from wind, marine renewables and hydro. Ambitious demand reduction. ", worksheet.control_u47); end
  def test_control_v47; assert_equal("Offshore renewables, solar, geothermal and electricity imports. Ambitious demand reduction.", worksheet.control_v47); end
  def test_control_w47; assert_equal("Marine renewables, geothermal and algae supply. Some nuclear and CCS.", worksheet.control_w47); end
  def test_control_x47; assert_equal("Wide range of generation sources. Moderate demand reduction. Considerable bioenergy.", worksheet.control_x47); end
  def test_control_y47; assert_equal("Energy from a range of sources. Emphasis on UK self-reliance.", worksheet.control_y47); end
  def test_control_n48; assert_equal("No", worksheet.control_n48); end
  def test_control_o48; assert_equal("No", worksheet.control_o48); end
  def test_control_p48; assert_in_epsilon(112.0, worksheet.control_p48, 0.002); end
  def test_control_q48; assert_in_epsilon(109.0, worksheet.control_q48, 0.002); end
  def test_control_r48; assert_in_epsilon(110.0, worksheet.control_r48, 0.002); end
  def test_control_s48; assert_in_epsilon(111.0, worksheet.control_s48, 0.002); end
  def test_control_t48; assert_in_epsilon(170.0, worksheet.control_t48, 0.002); end
  def test_control_u48; assert_in_epsilon(95.0, worksheet.control_u48, 0.002); end
  def test_control_v48; assert_in_epsilon(96.0, worksheet.control_v48, 0.002); end
  def test_control_w48; assert_in_epsilon(94.0, worksheet.control_w48, 0.002); end
  def test_control_x48; assert_in_epsilon(97.0, worksheet.control_x48, 0.002); end
  def test_control_y48; assert_in_epsilon(92.0, worksheet.control_y48, 0.002); end
  def test_control_n49; assert_equal("No", worksheet.control_n49); end
  def test_control_o49; assert_equal("No", worksheet.control_o49); end
  def test_control_p49; assert_in_delta(0.0, (worksheet.control_p49||0), 0.002); end
  def test_control_q49; assert_in_delta(1.0, worksheet.control_q49, 0.002); end
  def test_control_r49; assert_in_epsilon(2.0, worksheet.control_r49, 0.002); end
  def test_control_s49; assert_in_epsilon(3.0, worksheet.control_s49, 0.002); end
  def test_control_t49; assert_in_epsilon(4.0, worksheet.control_t49, 0.002); end
  def test_control_u49; assert_in_epsilon(5.0, worksheet.control_u49, 0.002); end
  def test_control_v49; assert_in_epsilon(6.0, worksheet.control_v49, 0.002); end
  def test_control_w49; assert_in_epsilon(7.0, worksheet.control_w49, 0.002); end
  def test_control_x49; assert_in_epsilon(8.0, worksheet.control_x49, 0.002); end
  def test_control_y49; assert_in_epsilon(9.0, worksheet.control_y49, 0.002); end
  def test_control_bp5; assert_equal("6.5GW with 2.9GW available and produced 17,604GWh ", worksheet.control_bp5); end
  def test_control_bq5; assert_equal("11.3GW and remain the same up to 2050. This should produce 74,556GWh ", worksheet.control_bq5); end
  def test_control_br5; assert_equal("20.17GW through independent Power Producer (IPPs) should be achieved which should produce 132,517GWh.", worksheet.control_br5); end
  def test_control_bs5; assert_equal("80.56GW by 2050 which should produce 529,279GWh. This target is based on “energy requirement for vision 20:2020 and beyond” for Nigeria.", worksheet.control_bs5); end
  def test_control_bp6; assert_equal("0.005GW of biomass power plant will be available up to year 2050. This will produce about 0.04TWh.", worksheet.control_bp6); end
  def test_control_bq6; assert_equal("1GW of biomass power plant should be available by 2050 and producing 7.88TWh", worksheet.control_bq6); end
  def test_control_br6; assert_equal("4GW of biomass power plant by 2050 which will produce 31.54TWh", worksheet.control_br6); end
  def test_control_bs6; assert_equal("10GW  of biomass power plants by 2050. This can produce 78.84TWh.", worksheet.control_bs6); end
  def test_control_bp7; assert_equal("Coal power plants will not be available in the electricity generation mix up to 2050. ", worksheet.control_bp7); end
  def test_control_bq7; assert_equal("1.4 GW by 2020 which is maintained up to 2050. This will generate approximately 9,198GWh", worksheet.control_bq7); end
  def test_control_br7; assert_equal("4.5 GW by 2030 which should remain constant up to 2050. This will generate approximately 29,565GWh. ", worksheet.control_br7); end
  def test_control_bs7; assert_equal("reach 55GW by 2050 and produce 361,350GWh/y ", worksheet.control_bs7); end
  def test_control_bp8; assert_equal("No nuclear power station will be available in the electricity generation mix by 2050. ", worksheet.control_bp8); end
  def test_control_bq8; assert_equal("~5 1GW power stations starting from 2020 up to 2030 will be built, delivering ~35,040 GWh", worksheet.control_bq8); end
  def test_control_br8; assert_equal("7.2 GW should become available by 2030 and remains constant up to 2050, delivering 50,457GWh of electricity", worksheet.control_br8); end
  def test_control_bs8; assert_equal("~40 1 GW Capacity addition grows at the rate of 14% per annum from 2022 through to 2050 delivering 280,320GWh of electricity~40 1 GW Capacity addition grows at the rate of 14% per annum from 2022 through to 2050 delivering 280,320GWh of electricity", worksheet.control_bs8); end
  def test_control_bp9; assert_equal("No installation of wind power systems up to 2050.", worksheet.control_bp9); end
  def test_control_bq9; assert_equal("0.01GW wind power plant by 2020 and no more installation up to 2050 delivering 17.52GWh of electricity ", worksheet.control_bq9); end
  def test_control_br9; assert_equal("1GW capacity of wind power plant should be available by 2030 delivering 1,752GWh of electricity", worksheet.control_br9); end
  def test_control_bs9; assert_equal("14.7GW of wind power plant by 2050 delivering 25,735GWh of electricity", worksheet.control_bs9); end
  def test_control_bp10; assert_equal("1.94 GW total hydropower capacity is maintained to 2050 delivering 11,883GWh of electricity", worksheet.control_bp10); end
  def test_control_bq10; assert_equal("5.24 GW by 2030 through rehabilitating the existing hydropower to operate at full capacity and adding 3.3 GW large hydro power stations delivering 32,119GWh of electricity", worksheet.control_bq10); end
  def test_control_br10; assert_equal("hydropower capacity reaches 6.99 GW by 2035 delivering 42,850GWh of electricity", worksheet.control_br10); end
  def test_control_bs10; assert_equal("hydropower capacity reaches 15 GW by 2050 delivering 91,980 GWh of electricity", worksheet.control_bs10); end
  def test_control_bp11; assert_equal("0.064 GW of Small Hydropower capacity will be maintained up to 2050, which will generate approximately 0.28TWh of electricity ", worksheet.control_bp11); end
  def test_control_bq11; assert_equal("Small hydropower capacity reaches 0.53 GW by 2050 and will generate approximately 2.32TWh of electricity ", worksheet.control_bq11); end
  def test_control_br11; assert_equal("small hydropower capacity reaches 1.75 GW by 2050. This capacity represents 47% of the country’s small hydropower potentials and will generate about 7.67TWh of electricity.", worksheet.control_br11); end
  def test_control_bs11; assert_equal("Small hydropower capacity reaches 3.5 GW by 2050, through utilising about 95% of the country’s hydropower potentials. This capacity can generate 15.33TWh of electricity. ", worksheet.control_bs11); end
  def test_control_bp12; assert_equal("The grid connected solar PV’s contribution remains 0.7GW which produces 1.29TWh .", worksheet.control_bp12); end
  def test_control_bq12; assert_equal("The grid connected solar PV capacity reaches 2GW in 2020 producing and 9GW by 2050. This should produce 16.56TWh ", worksheet.control_bq12); end
  def test_control_br12; assert_equal("The grid connected solar PV capacity reaches 25GW in 2050 thereby producing 43.97TWh. ", worksheet.control_br12); end
  def test_control_bs12; assert_equal("The grid connected solar PV capacity reaches 110GW in 2050 by utilising 0.05% of Nigeria’s land mass which should produce 202.36TWh", worksheet.control_bs12); end
  def test_control_bp13; assert_equal("No deployment of solar CSP installations up to 2050.", worksheet.control_bp13); end
  def test_control_bq13; assert_equal("1GW CSP power plant by 2050 which should generate 1.84TWh of electricity", worksheet.control_bq13); end
  def test_control_br13; assert_equal("10GW CSP power plant by 2050 contributing 18.4TWh of electricity", worksheet.control_br13); end
  def test_control_bs13; assert_equal("40GW CSP power plant by 2050 contributing 73.58TWh of electricity", worksheet.control_bs13); end
  def test_control_bp14; assert_equal("Stand-alone solar PV’s contribution remains 4GW which produces 7.36TWh by 2050.", worksheet.control_bp14); end
  def test_control_bq14; assert_equal("Stand-alone solar PV’s capacity reaches 2GW in 2020 and 16GW by 2050. This should produce 29.4TWh", worksheet.control_bq14); end
  def test_control_br14; assert_equal("Stand-alone solar PV’s capacity reaches 30GW in 2050 thereby producing 55.19TWh", worksheet.control_br14); end
  def test_control_bs14; assert_equal("Stand-alone solar PV’s capacity reaches 60GW in 2050 by utilising 0.05% of Nigeria’s land mass which should produce 110.38TWh.", worksheet.control_bs14); end
  def test_control_bp15; assert_equal("No electricity imports", worksheet.control_bp15); end
  def test_control_bq15; assert_equal("1.3GW capacity shall be wheeled from Grand Inga hydro electric project by 2030 and remain the same up to 2050. With 5% transmission losses, 11TWh of electricity shall be imported.", worksheet.control_bq15); end
  def test_control_br15; assert_equal("4 GW capacities shall be wheeled to Nigeria Grand Inga hydro electric project by 2030 and remain the same up to 2050. Considering 5% transmission losses, 35TWh shall be imported into the country.", worksheet.control_br15); end
  def test_control_bs15; assert_equal("8 GW capacities shall be wheeled to Nigeria from grand Inga hydro electric project by 2050. Considering 5% transmission losses, 70TWh shall be imported.", worksheet.control_bs15); end
  def test_control_bp17; assert_equal("Energy crops and food production similar to today at 5% of land used", worksheet.control_bp17); end
  def test_control_bq17; assert_equal("11% of land used for energy crops", worksheet.control_bq17); end
  def test_control_br17; assert_equal("19% of land used for energy crops", worksheet.control_br17); end
  def test_control_bs17; assert_equal("19% of land used for energy crops", worksheet.control_bs17); end
  def test_control_bp18; assert_equal("Livestock numbers increase by 400%", worksheet.control_bp18); end
  def test_control_bq18; assert_equal("Livestock numbers increase by 900%", worksheet.control_bq18); end
  def test_control_br18; assert_equal("Livestock numbers increase by 1,800%", worksheet.control_br18); end
  def test_control_bs18; assert_equal("Livestock numbers increase by 3,800%", worksheet.control_bs18); end
  def test_control_bp19; assert_equal("Total waste generated is about 47% increase from 2010 level of 91 million tonnes of waste. ", worksheet.control_bp19); end
  def test_control_bq19; assert_equal("Total waste generated is about 33% increase from 2010 level of 91 million tonnes of waste. ", worksheet.control_bq19); end
  def test_control_br19; assert_equal("Total waste generated is about 19% increase from 2010 level of 91 million tonnes of waste. ", worksheet.control_br19); end
  def test_control_bs19; assert_equal("Total waste generated is about 21% reduction from 2010 level of 91 million tonnes of waste. ", worksheet.control_bs19); end
  def test_control_bp20; assert_equal("No development of macro-algae cultivation", worksheet.control_bp20); end
  def test_control_bq20; assert_equal("Area same as half of natural reserve used, delivering ~4 TWh/yr", worksheet.control_bq20); end
  def test_control_br20; assert_equal("Area same as all of natural reserve used, delivering ~9 TWh/yr", worksheet.control_br20); end
  def test_control_bs20; assert_equal("Area same as four times natural reserve used, delivering ~46 TWh/yr", worksheet.control_bs20); end
  def test_control_bp21; assert_equal("Biomass converted to a mixture of solid, liquid and gas biofuels", worksheet.control_bp21); end
  def test_control_bq21; assert_equal("Biomass mainly converted to solid biofuel", worksheet.control_bq21); end
  def test_control_br21; assert_equal("Biomass mainly converted to liquid biofuel", worksheet.control_br21); end
  def test_control_bs21; assert_equal("Biomass mainly converted to biogas fuel", worksheet.control_bs21); end
  def test_control_bp24; assert_equal("Individuals travel will increase from 6,000km in 2010 to 12,000km by 2050.", worksheet.control_bp24); end
  def test_control_bq24; assert_equal("Individuals travel will increase from 6,000km in 2010 to 10,800km by 2050.", worksheet.control_bq24); end
  def test_control_br24; assert_equal("Individuals travel will increase from 6,000km in 2010 to 9,600km by 2050.", worksheet.control_br24); end
  def test_control_bs24; assert_equal("Individuals travel will increase from 6,000km in 2010 to 8,400km by 2050.", worksheet.control_bs24); end
  def test_control_bp25; assert_equal("100% Internal Combustion Engine (ICE) By 2050", worksheet.control_bp25); end
  def test_control_bq25; assert_equal("90% Internal Combustion Engine (ICE), 7% Hybrid Electric Vehicle (HEV) and 3% Electric Vehicle (EV) by 2050", worksheet.control_bq25); end
  def test_control_br25; assert_equal("75% Internal Combustion Engine (ICE), 17% Hybrid Electric Vehicle (HEV) and 8% Electric Vehicle (EV) by 2051", worksheet.control_br25); end
  def test_control_bs25; assert_equal("60% Internal Combustion Engine (ICE), 25% Hybrid Electric Vehicle (HEV) and 10% Electric Vehicle (EV) by 2051", worksheet.control_bs25); end
  def test_control_bp26; assert_equal("100% liquid hydrocarbon by 2050", worksheet.control_bp26); end
  def test_control_bq26; assert_equal("90% liquid hydrocarbon and 10% Gaseous hydrocarbon by 2050", worksheet.control_bq26); end
  def test_control_br26; assert_equal("75% liquid hydrocarbon and 25% Gaseous hydrocarbon by 2050", worksheet.control_br26); end
  def test_control_bs26; assert_equal("60% liquid hydrocarbon and 40% Gaseous hydrocarbon by 2051", worksheet.control_bs26); end
  def test_control_bp27; assert_equal("Road haulage makes up 73% of distance, using conventional engines. Rail all diesel", worksheet.control_bp27); end
  def test_control_bq27; assert_equal("Some shift from road to rail and water, and more efficient engines", worksheet.control_bq27); end
  def test_control_br27; assert_equal("Greater modal shift to rail and water; more efficient HGVs; more efficient logistics", worksheet.control_br27); end
  def test_control_bs27; assert_equal("Road modal share falls to half; greater hybridisation. Rail freight is all electric ", worksheet.control_bs27); end
  def test_control_bp29; assert_equal("Cooling demand increases 3.5 folds from 2010", worksheet.control_bp29); end
  def test_control_bq29; assert_equal("Cooling demand reduces by 20%", worksheet.control_bq29); end
  def test_control_br29; assert_equal("Cooling demand reduces by 40%", worksheet.control_br29); end
  def test_control_bs29; assert_equal("Cooling demand reduces by 60%", worksheet.control_bs29); end
  def test_control_bp30; assert_equal("Same as 2010", worksheet.control_bp30); end
  def test_control_bq30; assert_equal("10% more efficient", worksheet.control_bq30); end
  def test_control_br30; assert_equal("20% more efficient", worksheet.control_br30); end
  def test_control_bs30; assert_equal("30% more efficient", worksheet.control_bs30); end
  def test_control_bp32; assert_equal("Energy demand for Household lights and appliances increases by 1200%, and 150% for Cooking  (relative to 2010)", worksheet.control_bp32); end
  def test_control_bq32; assert_equal("Energy demand reduces by 25% for both  Household lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_bq32); end
  def test_control_br32; assert_equal("Energy demand reduces by 50% for both  Household lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_br32); end
  def test_control_bs32; assert_equal("Energy demand reduces by 75% for both  Household lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_bs32); end
  def test_control_bp33; assert_equal("Same as 2010, 80% Fuelwood, 12% Liquid hydrocarbon, 5% Gaseous hydrocarbon & 3% Electricity", worksheet.control_bp33); end
  def test_control_bq33; assert_equal("30% Reduction in Fuelwood:- 16% Liquid hydrocarbon,18% Gaseous hydrocarbon & 10% Electricity", worksheet.control_bq33); end
  def test_control_br33; assert_equal("50% Reduction in Fuelwood:- 20% Liquid hydrocarbon, 25% Gaseous hydrocarbon & 15% Electricity", worksheet.control_br33); end
  def test_control_bs33; assert_equal("80% Reduction in Fuelwood:- 24% Liquid hydrocarbon, 40% Gaseous hydrocarbon & 20% Electricity", worksheet.control_bs33); end
  def test_control_bp35; assert_equal("Nigeria industry energy demand will increase by 2104% by 2050", worksheet.control_bp35); end
  def test_control_bq35; assert_equal("Nigeria industry energy demand will fall by 75% compared to 2050 level", worksheet.control_bq35); end
  def test_control_br35; assert_equal("Nigeria industry energy demand will fall by 50% compared to 2050 level", worksheet.control_br35); end
  def test_control_bs35; assert_equal("Nigeria industry energy demand will fall by 30% compared to 2050 level", worksheet.control_bs35); end
  def test_control_bp36; assert_equal("No effort to reduce energy intensity", worksheet.control_bp36); end
  def test_control_bq36; assert_equal("20% reduction in energy intensity", worksheet.control_bq36); end
  def test_control_br36; assert_equal("30% reduction in energy intensity", worksheet.control_br36); end
  def test_control_bs36; assert_equal("50% reduction in energy intensity", worksheet.control_bs36); end
  def test_control_bp38; assert_equal("Cooling demand increases 3.5 folds from 2010", worksheet.control_bp38); end
  def test_control_bq38; assert_equal("Cooling demand reduces by 20%", worksheet.control_bq38); end
  def test_control_br38; assert_equal("Cooling demand reduces by 40%", worksheet.control_br38); end
  def test_control_bs38; assert_equal("Cooling demand reduces by 60%", worksheet.control_bs38); end
  def test_control_bp39; assert_equal("Same as 2010", worksheet.control_bp39); end
  def test_control_bq39; assert_equal("10% more efficient", worksheet.control_bq39); end
  def test_control_br39; assert_equal("20% more efficient", worksheet.control_br39); end
  def test_control_bs39; assert_equal("30% more efficient", worksheet.control_bs39); end
  def test_control_bp41; assert_equal("Energy demand for Service Sector lights and appliances increases by 1200%, and 150% for Cooking  (relative to 2010)", worksheet.control_bp41); end
  def test_control_bq41; assert_equal("Energy demand reduces by 25% for both  Service Sector lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_bq41); end
  def test_control_br41; assert_equal("Energy demand reduces by 50% for both  Service Sector lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_br41); end
  def test_control_bs41; assert_equal("Energy demand reduces by 75% for both  Service Sector lights,  appliances and  Cooking  (relative to 2050 level 1)", worksheet.control_bs41); end
  def test_control_bp42; assert_equal("Same as 2010, 80% Fuelwood, 12% Liquid hydrocarbon, 5% Gaseous hydrocarbon & 3% Electricity", worksheet.control_bp42); end
  def test_control_bq42; assert_equal("30% Reduction in Fuelwood:- 16% Liquid hydrocarbon,18% Gaseous hydrocarbon & 10% Electricity", worksheet.control_bq42); end
  def test_control_br42; assert_equal("50% Reduction in Fuelwood:- 20% Liquid hydrocarbon, 25% Gaseous hydrocarbon & 15% Electricity", worksheet.control_br42); end
  def test_control_bs42; assert_equal("80% Reduction in Fuelwood:- 24% Liquid hydrocarbon, 40% Gaseous hydrocarbon & 20% Electricity", worksheet.control_bs42); end
  def test_control_bp44; assert_equal("Coal production will increase from minimal value of 0.046 million TCE to a high value of 135.12 million TCE by 2050", worksheet.control_bp44); end
  def test_control_bq44; assert_equal("Coal production will increase from minimal value of 0.046 million TCE to 49.13  million TCE by 2050", worksheet.control_bq44); end
  def test_control_br44; assert_equal("Coal production will increase from minimal value of 0.046 million TCE to 12.28  million TCE by 2050.", worksheet.control_br44); end
  def test_control_bp45; assert_equal("Crude oil production increase to 1,011.47 million boe ", worksheet.control_bp45); end
  def test_control_bq45; assert_equal("Crude oil production will remain same as 2010, at 919.52 million boe. ", worksheet.control_bq45); end
  def test_control_br45; assert_equal("Crude oil production decreases to 873.54 million boe.", worksheet.control_br45); end
  def test_control_bp46; assert_equal("Gas production will increase to 5.43Tcf while gas flaring reduces to 2%.", worksheet.control_bp46); end
  def test_control_bq46; assert_equal("Gas production will increase to 3.62Tcf,  and domestic consumption is expected to increases", worksheet.control_bq46); end
  def test_control_br46; assert_equal("Gas production increases minimally to 3.26Tcf.", worksheet.control_br46); end
  def test_control_d5; assert_equal("Natural gas power stations", worksheet.control_d5); end
  def test_control_d6; assert_equal("Biomass power ", worksheet.control_d6); end
  def test_control_d7; assert_equal("Coal power stations", worksheet.control_d7); end
  def test_control_d8; assert_equal("Nuclear power stations", worksheet.control_d8); end
  def test_control_d9; assert_equal("Wind ", worksheet.control_d9); end
  def test_control_d10; assert_equal("Hydroelectric power stations", worksheet.control_d10); end
  def test_control_d11; assert_equal("Small Hydroelectric power stations", worksheet.control_d11); end
  def test_control_d12; assert_equal("Grid Connected Solar PV", worksheet.control_d12); end
  def test_control_d13; assert_equal("Concentrated Solar Power", worksheet.control_d13); end
  def test_control_d14; assert_equal("Stand Alone Solar Photo Voltaic ", worksheet.control_d14); end
  def test_control_d15; assert_equal("Electricity imports", worksheet.control_d15); end
  def test_control_d16; assert_equal("Agriculture and land use", worksheet.control_d16); end
  def test_control_d17; assert_equal("Land dedicated to bioenergy", worksheet.control_d17); end
  def test_control_d18; assert_equal("Livestock and their management", worksheet.control_d18); end
  def test_control_d19; assert_equal("Volume of waste and recycling", worksheet.control_d19); end
  def test_control_d20; assert_equal("Type of fuels from biomass", worksheet.control_d20); end
  def test_control_d21; assert_equal("Bioenergy imports", worksheet.control_d21); end
  def test_control_d23; assert_equal("Domestic passenger transport", worksheet.control_d23); end
  def test_control_d24; assert_equal("Domestic transport behaviour", worksheet.control_d24); end
  def test_control_d25; assert_equal("Shift to low carbon emission transport technology", worksheet.control_d25); end
  def test_control_d26; assert_equal("Fuel switch for Internal Combustion Engine", worksheet.control_d26); end
  def test_control_d27; assert_equal("Domestic freight", worksheet.control_d27); end
  def test_control_d28; assert_equal("Residential Cooling", worksheet.control_d28); end
  def test_control_d29; assert_equal("Cooling Demand", worksheet.control_d29); end
  def test_control_d30; assert_equal("Efficiency of Cooling System", worksheet.control_d30); end
  def test_control_d31; assert_equal("Residential Lighting, Appliances, and Cooking", worksheet.control_d31); end
  def test_control_d32; assert_equal("Residential Lighting, Appliances & Cooking", worksheet.control_d32); end
  def test_control_d33; assert_equal("Technology Pathway (Cooking)", worksheet.control_d33); end
  def test_control_d34; assert_equal("Industrial processes", worksheet.control_d34); end
  def test_control_d35; assert_equal("Growth in industry with GDP", worksheet.control_d35); end
  def test_control_d36; assert_equal("Energy intensity of industry", worksheet.control_d36); end
  def test_control_d37; assert_equal("Service Sector Cooling", worksheet.control_d37); end
  def test_control_d38; assert_equal("Service Sector Demand for Cooling", worksheet.control_d38); end
  def test_control_d39; assert_equal("Efficiency of Cooling System", worksheet.control_d39); end
  def test_control_d40; assert_equal("Service Sector Lighting, Appliances, and Cooking", worksheet.control_d40); end
  def test_control_d41; assert_equal("Service Sector lighting, appliances & Cooking", worksheet.control_d41); end
  def test_control_d42; assert_equal("Technology Pathway (Cooking)", worksheet.control_d42); end
  def test_control_d44; assert_equal("Indigenous fossil-fuel: Coal", worksheet.control_d44); end
  def test_control_d45; assert_equal("Indigenous fossil-fuel: Oil", worksheet.control_d45); end
  def test_control_d46; assert_equal("Indigenous fossil-fuel production: Gas", worksheet.control_d46); end
  def test_control_g5; assert_equal("0.pdf", worksheet.control_g5); end
  def test_control_g6; assert_equal("1.pdf", worksheet.control_g6); end
  def test_control_g7; assert_equal("2.pdf", worksheet.control_g7); end
  def test_control_g8; assert_equal("3.pdf", worksheet.control_g8); end
  def test_control_g9; assert_equal("4.pdf", worksheet.control_g9); end
  def test_control_g10; assert_equal("5.pdf", worksheet.control_g10); end
  def test_control_g11; assert_equal("6.pdf", worksheet.control_g11); end
  def test_control_g12; assert_equal("7.pdf", worksheet.control_g12); end
  def test_control_g13; assert_equal("8.pdf", worksheet.control_g13); end
  def test_control_g14; assert_equal("9.pdf", worksheet.control_g14); end
  def test_control_g15; assert_equal("10.pdf", worksheet.control_g15); end
  def test_control_g16; assert_equal("11.pdf", worksheet.control_g16); end
  def test_control_g17; assert_equal("11.pdf", worksheet.control_g17); end
  def test_control_g18; assert_equal("11.pdf", worksheet.control_g18); end
  def test_control_g19; assert_equal("12.pdf", worksheet.control_g19); end
  def test_control_g20; assert_equal("13.pdf", worksheet.control_g20); end
  def test_control_g21; assert_equal("14.pdf", worksheet.control_g21); end
  def test_control_g23; assert_equal("15.pdf", worksheet.control_g23); end
  def test_control_g24; assert_equal("15.pdf", worksheet.control_g24); end
  def test_control_g25; assert_equal("16.pdf", worksheet.control_g25); end
  def test_control_g26; assert_equal("16.pdf", worksheet.control_g26); end
  def test_control_g27; assert_equal("18.pdf", worksheet.control_g27); end
  def test_control_g28; assert_equal("19.pdf", worksheet.control_g28); end
  def test_control_g29; assert_equal("19.pdf", worksheet.control_g29); end
  def test_control_g30; assert_equal("19.pdf", worksheet.control_g30); end
  def test_control_g31; assert_equal("20.pdf", worksheet.control_g31); end
  def test_control_g32; assert_equal("20.pdf", worksheet.control_g32); end
  def test_control_g33; assert_equal("21.pdf", worksheet.control_g33); end
  def test_control_g34; assert_equal("22.pdf", worksheet.control_g34); end
  def test_control_g35; assert_equal("22.pdf", worksheet.control_g35); end
  def test_control_g36; assert_equal("23.pdf", worksheet.control_g36); end
  def test_control_g37; assert_equal("24.pdf", worksheet.control_g37); end
  def test_control_g38; assert_equal("24.pdf", worksheet.control_g38); end
  def test_control_g39; assert_equal("25.pdf", worksheet.control_g39); end
  def test_control_g40; assert_equal("26.pdf", worksheet.control_g40); end
  def test_control_g41; assert_equal("26.pdf", worksheet.control_g41); end
  def test_control_g42; assert_equal("27.pdf", worksheet.control_g42); end
  def test_control_g44; assert_equal("28.pdf", worksheet.control_g44); end
  def test_control_g45; assert_equal("29.pdf", worksheet.control_g45); end
  def test_control_g46; assert_equal("30.pdf", worksheet.control_g46); end
  def test_control_f5; assert_in_epsilon(4.0, worksheet.control_f5, 0.002); end
  def test_control_f6; assert_in_epsilon(4.0, worksheet.control_f6, 0.002); end
  def test_control_f7; assert_in_epsilon(4.0, worksheet.control_f7, 0.002); end
  def test_control_f8; assert_in_epsilon(4.0, worksheet.control_f8, 0.002); end
  def test_control_f9; assert_in_epsilon(4.0, worksheet.control_f9, 0.002); end
  def test_control_f10; assert_in_epsilon(4.0, worksheet.control_f10, 0.002); end
  def test_control_f11; assert_in_epsilon(4.0, worksheet.control_f11, 0.002); end
  def test_control_f12; assert_in_epsilon(4.0, worksheet.control_f12, 0.002); end
  def test_control_f13; assert_in_epsilon(4.0, worksheet.control_f13, 0.002); end
  def test_control_f14; assert_in_epsilon(4.0, worksheet.control_f14, 0.002); end
  def test_control_f15; assert_in_epsilon(4.0, worksheet.control_f15, 0.002); end
  def test_control_f16; assert_in_delta(0.0, (worksheet.control_f16||0), 0.002); end
  def test_control_f17; assert_in_epsilon(4.0, worksheet.control_f17, 0.002); end
  def test_control_f18; assert_in_epsilon(4.0, worksheet.control_f18, 0.002); end
  def test_control_f19; assert_in_epsilon(4.0, worksheet.control_f19, 0.002); end
  def test_control_f20; assert_in_epsilon(4.0, worksheet.control_f20, 0.002); end
  def test_control_f21; assert_in_epsilon(4.0, worksheet.control_f21, 0.002); end
  def test_control_f23; assert_in_delta(0.0, (worksheet.control_f23||0), 0.002); end
  def test_control_f24; assert_in_epsilon(4.0, worksheet.control_f24, 0.002); end
  def test_control_f25; assert_in_epsilon(4.0, worksheet.control_f25, 0.002); end
  def test_control_f26; assert_in_epsilon(4.0, worksheet.control_f26, 0.002); end
  def test_control_f27; assert_in_epsilon(4.0, worksheet.control_f27, 0.002); end
  def test_control_f28; assert_in_delta(0.0, (worksheet.control_f28||0), 0.002); end
  def test_control_f29; assert_in_epsilon(4.0, worksheet.control_f29, 0.002); end
  def test_control_f30; assert_in_epsilon(4.0, worksheet.control_f30, 0.002); end
  def test_control_f31; assert_in_delta(0.0, (worksheet.control_f31||0), 0.002); end
  def test_control_f32; assert_in_epsilon(4.0, worksheet.control_f32, 0.002); end
  def test_control_f33; assert_in_epsilon(4.0, worksheet.control_f33, 0.002); end
  def test_control_f34; assert_in_delta(0.0, (worksheet.control_f34||0), 0.002); end
  def test_control_f35; assert_in_epsilon(4.0, worksheet.control_f35, 0.002); end
  def test_control_f36; assert_in_epsilon(4.0, worksheet.control_f36, 0.002); end
  def test_control_f37; assert_in_delta(0.0, (worksheet.control_f37||0), 0.002); end
  def test_control_f38; assert_in_epsilon(4.0, worksheet.control_f38, 0.002); end
  def test_control_f39; assert_in_epsilon(4.0, worksheet.control_f39, 0.002); end
  def test_control_f40; assert_in_delta(0.0, (worksheet.control_f40||0), 0.002); end
  def test_control_f41; assert_in_epsilon(4.0, worksheet.control_f41, 0.002); end
  def test_control_f42; assert_in_epsilon(4.0, worksheet.control_f42, 0.002); end
  def test_control_f44; assert_in_epsilon(3.0, worksheet.control_f44, 0.002); end
  def test_control_f45; assert_in_epsilon(3.0, worksheet.control_f45, 0.002); end
  def test_control_f46; assert_in_epsilon(3.0, worksheet.control_f46, 0.002); end
  def test_control_n1; assert_equal("Version 1.0", worksheet.control_n1); end
  def test_air_quality_c3; assert_equal("High", worksheet.air_quality_c3); end
  def test_air_quality_d3; assert_in_epsilon(67.0289147704017, worksheet.air_quality_d3, 0.002); end
  def test_air_quality_c4; assert_equal("Low", worksheet.air_quality_c4); end
  def test_air_quality_d4; assert_in_epsilon(37.470763681420635, worksheet.air_quality_d4, 0.002); end
  def test_land_use_c5; assert_equal("III.a.1", worksheet.land_use_c5); end
  def test_land_use_d5; assert_in_delta(0.0, (worksheet.land_use_d5||0), 0.002); end
  def test_land_use_e5; assert_in_delta(0.0, (worksheet.land_use_e5||0), 0.002); end
  def test_land_use_f5; assert_in_epsilon(3.999999999999999, worksheet.land_use_f5, 0.002); end
  def test_land_use_g5; assert_in_epsilon(3.999999999999999, worksheet.land_use_g5, 0.002); end
  def test_land_use_h5; assert_in_epsilon(3.999999999999999, worksheet.land_use_h5, 0.002); end
  def test_land_use_i5; assert_in_epsilon(3.999999999999999, worksheet.land_use_i5, 0.002); end
  def test_land_use_j5; assert_in_epsilon(3.999999999999999, worksheet.land_use_j5, 0.002); end
  def test_land_use_k5; assert_in_epsilon(3.999999999999999, worksheet.land_use_k5, 0.002); end
  def test_land_use_l5; assert_in_epsilon(3.999999999999999, worksheet.land_use_l5, 0.002); end
  def test_land_use_c6; assert_equal("III.b.1", worksheet.land_use_c6); end
  def test_land_use_d6; assert_in_epsilon(62.18181818181816, worksheet.land_use_d6, 0.002); end
  def test_land_use_e6; assert_in_epsilon(62.18181818181816, worksheet.land_use_e6, 0.002); end
  def test_land_use_f6; assert_in_epsilon(62.18181818181816, worksheet.land_use_f6, 0.002); end
  def test_land_use_g6; assert_in_epsilon(62.18181818181816, worksheet.land_use_g6, 0.002); end
  def test_land_use_h6; assert_in_epsilon(62.18181818181816, worksheet.land_use_h6, 0.002); end
  def test_land_use_i6; assert_in_epsilon(62.18181818181816, worksheet.land_use_i6, 0.002); end
  def test_land_use_j6; assert_in_epsilon(62.18181818181816, worksheet.land_use_j6, 0.002); end
  def test_land_use_k6; assert_in_epsilon(62.18181818181816, worksheet.land_use_k6, 0.002); end
  def test_land_use_l6; assert_in_epsilon(62.18181818181816, worksheet.land_use_l6, 0.002); end
  def test_land_use_c7; assert_equal("III.b.2", worksheet.land_use_c7); end
  def test_land_use_d7; assert_in_epsilon(2.094545454545454, worksheet.land_use_d7, 0.002); end
  def test_land_use_e7; assert_in_epsilon(2.094545454545454, worksheet.land_use_e7, 0.002); end
  def test_land_use_f7; assert_in_epsilon(2.094545454545454, worksheet.land_use_f7, 0.002); end
  def test_land_use_g7; assert_in_epsilon(2.094545454545454, worksheet.land_use_g7, 0.002); end
  def test_land_use_h7; assert_in_epsilon(2.094545454545454, worksheet.land_use_h7, 0.002); end
  def test_land_use_i7; assert_in_epsilon(2.094545454545454, worksheet.land_use_i7, 0.002); end
  def test_land_use_j7; assert_in_epsilon(2.094545454545454, worksheet.land_use_j7, 0.002); end
  def test_land_use_k7; assert_in_epsilon(2.094545454545454, worksheet.land_use_k7, 0.002); end
  def test_land_use_l7; assert_in_epsilon(2.094545454545454, worksheet.land_use_l7, 0.002); end
  def test_land_use_c8; assert_equal("IV.a", worksheet.land_use_c8); end
  def test_land_use_d8; assert_in_delta(0.01635514018691588, worksheet.land_use_d8, 0.002); end
  def test_land_use_e8; assert_in_delta(0.5451713395638628, worksheet.land_use_e8, 0.002); end
  def test_land_use_f8; assert_in_epsilon(1.0903426791277255, worksheet.land_use_f8, 0.002); end
  def test_land_use_g8; assert_in_epsilon(1.6355140186915884, worksheet.land_use_g8, 0.002); end
  def test_land_use_h8; assert_in_epsilon(2.180685358255451, worksheet.land_use_h8, 0.002); end
  def test_land_use_i8; assert_in_epsilon(2.725856697819314, worksheet.land_use_i8, 0.002); end
  def test_land_use_j8; assert_in_epsilon(3.271028037383177, worksheet.land_use_j8, 0.002); end
  def test_land_use_k8; assert_in_epsilon(3.8161993769470395, worksheet.land_use_k8, 0.002); end
  def test_land_use_l8; assert_in_epsilon(4.361370716510902, worksheet.land_use_l8, 0.002); end
  def test_land_use_c9; assert_equal("VI.a.Biocrop", worksheet.land_use_c9); end
  def test_land_use_d9; assert_in_epsilon(323318.8, worksheet.land_use_d9, 0.002); end
  def test_land_use_e9; assert_in_epsilon(323318.8, worksheet.land_use_e9, 0.002); end
  def test_land_use_f9; assert_in_epsilon(323318.8, worksheet.land_use_f9, 0.002); end
  def test_land_use_g9; assert_in_epsilon(323318.8, worksheet.land_use_g9, 0.002); end
  def test_land_use_h9; assert_in_epsilon(323318.8, worksheet.land_use_h9, 0.002); end
  def test_land_use_i9; assert_in_epsilon(323318.8, worksheet.land_use_i9, 0.002); end
  def test_land_use_j9; assert_in_epsilon(323318.8, worksheet.land_use_j9, 0.002); end
  def test_land_use_k9; assert_in_epsilon(323318.8, worksheet.land_use_k9, 0.002); end
  def test_land_use_l9; assert_in_epsilon(323318.8, worksheet.land_use_l9, 0.002); end
  def test_land_use_c10; assert_equal("VI.a.Forestry", worksheet.land_use_c10); end
  def test_land_use_d10; assert_in_epsilon(286368.08, worksheet.land_use_d10, 0.002); end
  def test_land_use_e10; assert_in_epsilon(286368.08, worksheet.land_use_e10, 0.002); end
  def test_land_use_f10; assert_in_epsilon(286368.08, worksheet.land_use_f10, 0.002); end
  def test_land_use_g10; assert_in_epsilon(286368.08, worksheet.land_use_g10, 0.002); end
  def test_land_use_h10; assert_in_epsilon(286368.08, worksheet.land_use_h10, 0.002); end
  def test_land_use_i10; assert_in_epsilon(286368.08, worksheet.land_use_i10, 0.002); end
  def test_land_use_j10; assert_in_epsilon(286368.08, worksheet.land_use_j10, 0.002); end
  def test_land_use_k10; assert_in_epsilon(286368.08, worksheet.land_use_k10, 0.002); end
  def test_land_use_l10; assert_in_epsilon(286368.08, worksheet.land_use_l10, 0.002); end
  def test_land_use_c11; assert_equal("V.b", worksheet.land_use_c11); end
  def test_land_use_d11; assert_in_epsilon(-7995.574973973376, worksheet.land_use_d11, 0.002); end
  def test_land_use_e11; assert_in_epsilon(-8398.457297466484, worksheet.land_use_e11, 0.002); end
  def test_land_use_f11; assert_in_epsilon(-8814.376605661442, worksheet.land_use_f11, 0.002); end
  def test_land_use_g11; assert_in_epsilon(-4937.406792727832, worksheet.land_use_g11, 0.002); end
  def test_land_use_h11; assert_in_epsilon(-5440.937265179468, worksheet.land_use_h11, 0.002); end
  def test_land_use_i11; assert_in_epsilon(-5928.589166189386, worksheet.land_use_i11, 0.002); end
  def test_land_use_j11; assert_in_epsilon(-6408.134380288619, worksheet.land_use_j11, 0.002); end
  def test_land_use_k11; assert_in_epsilon(-6901.724027631305, worksheet.land_use_k11, 0.002); end
  def test_land_use_l11; assert_in_epsilon(-7375.992050485127, worksheet.land_use_l11, 0.002); end
  def test_land_use_c12; assert_equal("VII.a", worksheet.land_use_c12); end
  def test_land_use_d12; assert_in_delta(0.0, (worksheet.land_use_d12||0), 0.002); end
  def test_land_use_e12; assert_in_delta(0.0, (worksheet.land_use_e12||0), 0.002); end
  def test_land_use_f12; assert_in_delta(0.0, (worksheet.land_use_f12||0), 0.002); end
  def test_land_use_g12; assert_in_delta(0.0, (worksheet.land_use_g12||0), 0.002); end
  def test_land_use_h12; assert_in_delta(0.0, (worksheet.land_use_h12||0), 0.002); end
  def test_land_use_i12; assert_in_delta(0.0, (worksheet.land_use_i12||0), 0.002); end
  def test_land_use_j12; assert_in_delta(0.0, (worksheet.land_use_j12||0), 0.002); end
  def test_land_use_k12; assert_in_delta(0.0, (worksheet.land_use_k12||0), 0.002); end
  def test_land_use_l12; assert_in_delta(0.0, (worksheet.land_use_l12||0), 0.002); end
  def test_land_use_c13; assert_equal("I.a", worksheet.land_use_c13); end
  def test_land_use_d13; assert_in_epsilon(3.0, worksheet.land_use_d13, 0.002); end
  def test_land_use_e13; assert_in_epsilon(3.44, worksheet.land_use_e13, 0.002); end
  def test_land_use_f13; assert_in_epsilon(3.88, worksheet.land_use_f13, 0.002); end
  def test_land_use_g13; assert_in_epsilon(4.31, worksheet.land_use_g13, 0.002); end
  def test_land_use_h13; assert_in_epsilon(4.75, worksheet.land_use_h13, 0.002); end
  def test_land_use_i13; assert_in_epsilon(5.19, worksheet.land_use_i13, 0.002); end
  def test_land_use_j13; assert_in_epsilon(5.63, worksheet.land_use_j13, 0.002); end
  def test_land_use_k13; assert_in_epsilon(6.05, worksheet.land_use_k13, 0.002); end
  def test_land_use_l13; assert_in_epsilon(6.5, worksheet.land_use_l13, 0.002); end
  def test_land_use_c14; assert_equal("I.b", worksheet.land_use_c14); end
  def test_land_use_d14; assert_in_delta(0.0, (worksheet.land_use_d14||0), 0.002); end
  def test_land_use_e14; assert_in_delta(0.0, (worksheet.land_use_e14||0), 0.002); end
  def test_land_use_f14; assert_in_delta(1.0, worksheet.land_use_f14, 0.002); end
  def test_land_use_g14; assert_in_delta(1.0, worksheet.land_use_g14, 0.002); end
  def test_land_use_h14; assert_in_delta(1.0, worksheet.land_use_h14, 0.002); end
  def test_land_use_i14; assert_in_delta(1.0, worksheet.land_use_i14, 0.002); end
  def test_land_use_j14; assert_in_delta(1.0, worksheet.land_use_j14, 0.002); end
  def test_land_use_k14; assert_in_delta(1.0, worksheet.land_use_k14, 0.002); end
  def test_land_use_l14; assert_in_delta(1.0, worksheet.land_use_l14, 0.002); end
  def test_land_use_c15; assert_equal("I.c", worksheet.land_use_c15); end
  def test_land_use_d15; assert_in_delta(0.0, (worksheet.land_use_d15||0), 0.002); end
  def test_land_use_e15; assert_in_delta(0.0, (worksheet.land_use_e15||0), 0.002); end
  def test_land_use_f15; assert_in_delta(0.0, (worksheet.land_use_f15||0), 0.002); end
  def test_land_use_g15; assert_in_epsilon(1.4, worksheet.land_use_g15, 0.002); end
  def test_land_use_h15; assert_in_epsilon(1.4, worksheet.land_use_h15, 0.002); end
  def test_land_use_i15; assert_in_epsilon(1.4, worksheet.land_use_i15, 0.002); end
  def test_land_use_j15; assert_in_epsilon(1.4, worksheet.land_use_j15, 0.002); end
  def test_land_use_k15; assert_in_epsilon(1.4, worksheet.land_use_k15, 0.002); end
  def test_land_use_l15; assert_in_epsilon(1.4, worksheet.land_use_l15, 0.002); end
  def test_land_use_c16; assert_equal("II.a", worksheet.land_use_c16); end
  def test_land_use_d16; assert_in_delta(0.0, (worksheet.land_use_d16||0), 0.002); end
  def test_land_use_e16; assert_in_delta(0.0, (worksheet.land_use_e16||0), 0.002); end
  def test_land_use_f16; assert_in_delta(0.0, (worksheet.land_use_f16||0), 0.002); end
  def test_land_use_g16; assert_in_delta(0.0, (worksheet.land_use_g16||0), 0.002); end
  def test_land_use_h16; assert_in_delta(0.0, (worksheet.land_use_h16||0), 0.002); end
  def test_land_use_i16; assert_in_delta(0.0, (worksheet.land_use_i16||0), 0.002); end
  def test_land_use_j16; assert_in_delta(0.0, (worksheet.land_use_j16||0), 0.002); end
  def test_land_use_k16; assert_in_delta(0.0, (worksheet.land_use_k16||0), 0.002); end
  def test_land_use_l16; assert_in_delta(0.0, (worksheet.land_use_l16||0), 0.002); end
  def test_land_use_c17; assert_equal("III.f", worksheet.land_use_c17); end
  def test_land_use_d17; assert_in_delta(0.0, (worksheet.land_use_d17||0), 0.002); end
  def test_land_use_e17; assert_in_delta(0.0, (worksheet.land_use_e17||0), 0.002); end
  def test_land_use_f17; assert_in_delta(0.10903426791277257, worksheet.land_use_f17, 0.002); end
  def test_land_use_g17; assert_in_delta(0.21806853582554514, worksheet.land_use_g17, 0.002); end
  def test_land_use_h17; assert_in_delta(0.3271028037383177, worksheet.land_use_h17, 0.002); end
  def test_land_use_i17; assert_in_delta(0.4361370716510903, worksheet.land_use_i17, 0.002); end
  def test_land_use_j17; assert_in_delta(0.5451713395638628, worksheet.land_use_j17, 0.002); end
  def test_land_use_k17; assert_in_delta(0.6542056074766354, worksheet.land_use_k17, 0.002); end
  def test_land_use_l17; assert_in_delta(0.7632398753894079, worksheet.land_use_l17, 0.002); end
  def test_land_use_c18; assert_equal("III.g", worksheet.land_use_c18); end
  def test_land_use_d18; assert_in_delta(0.0, (worksheet.land_use_d18||0), 0.002); end
  def test_land_use_e18; assert_in_delta(0.0, (worksheet.land_use_e18||0), 0.002); end
  def test_land_use_f18; assert_in_delta(0.0, (worksheet.land_use_f18||0), 0.002); end
  def test_land_use_g18; assert_in_delta(0.0, (worksheet.land_use_g18||0), 0.002); end
  def test_land_use_h18; assert_in_delta(0.0, (worksheet.land_use_h18||0), 0.002); end
  def test_land_use_i18; assert_in_delta(0.0, (worksheet.land_use_i18||0), 0.002); end
  def test_land_use_j18; assert_in_delta(0.0, (worksheet.land_use_j18||0), 0.002); end
  def test_land_use_k18; assert_in_delta(0.0, (worksheet.land_use_k18||0), 0.002); end
  def test_land_use_l18; assert_in_delta(0.0, (worksheet.land_use_l18||0), 0.002); end
  def test_land_use_c19; assert_equal("VI.b", worksheet.land_use_c19); end
  def test_land_use_d19; assert_in_epsilon(20.214669767441862, worksheet.land_use_d19, 0.002); end
  def test_land_use_e19; assert_in_epsilon(24.41767137209302, worksheet.land_use_e19, 0.002); end
  def test_land_use_f19; assert_in_epsilon(30.724844558139534, worksheet.land_use_f19, 0.002); end
  def test_land_use_g19; assert_in_epsilon(36.8549868372093, worksheet.land_use_g19, 0.002); end
  def test_land_use_h19; assert_in_epsilon(44.84816744186046, worksheet.land_use_h19, 0.002); end
  def test_land_use_i19; assert_in_epsilon(51.82461358139535, worksheet.land_use_i19, 0.002); end
  def test_land_use_j19; assert_in_epsilon(59.09527106976744, worksheet.land_use_j19, 0.002); end
  def test_land_use_k19; assert_in_epsilon(67.37753525581395, worksheet.land_use_k19, 0.002); end
  def test_land_use_l19; assert_in_epsilon(75.25373172093023, worksheet.land_use_l19, 0.002); end
  def test_energy_security_d128; assert_equal("Automatically built Self Generation", worksheet.energy_security_d128); end
  def test_energy_security_e128; assert_in_epsilon(26.42279885102571, worksheet.energy_security_e128, 0.002); end
  def test_energy_security_f128; assert_in_epsilon(31.12469483366499, worksheet.energy_security_f128, 0.002); end
  def test_energy_security_g128; assert_in_epsilon(41.903011579354704, worksheet.energy_security_g128, 0.002); end
  def test_energy_security_h128; assert_in_epsilon(59.92529338337988, worksheet.energy_security_h128, 0.002); end
  def test_energy_security_i128; assert_in_epsilon(80.49534823382962, worksheet.energy_security_i128, 0.002); end
  def test_energy_security_j128; assert_in_epsilon(101.38680317207442, worksheet.energy_security_j128, 0.002); end
  def test_energy_security_k128; assert_in_epsilon(125.76610266515979, worksheet.energy_security_k128, 0.002); end
  def test_energy_security_l128; assert_in_epsilon(147.3680146743518, worksheet.energy_security_l128, 0.002); end
  def test_energy_security_m128; assert_in_epsilon(173.5570104807672, worksheet.energy_security_m128, 0.002); end
  def test_energy_security_d129; assert_equal("Automatically built peaking gas", worksheet.energy_security_d129); end
  def test_energy_security_e129; assert_in_delta(0.0, (worksheet.energy_security_e129||0), 0.002); end
  def test_energy_security_f129; assert_in_delta(0.0, (worksheet.energy_security_f129||0), 0.002); end
  def test_energy_security_g129; assert_in_delta(0.0, (worksheet.energy_security_g129||0), 0.002); end
  def test_energy_security_h129; assert_in_delta(0.0, (worksheet.energy_security_h129||0), 0.002); end
  def test_energy_security_i129; assert_in_delta(0.0, (worksheet.energy_security_i129||0), 0.002); end
  def test_energy_security_j129; assert_in_delta(0.0, (worksheet.energy_security_j129||0), 0.002); end
  def test_energy_security_k129; assert_in_delta(0.0, (worksheet.energy_security_k129||0), 0.002); end
  def test_energy_security_l129; assert_in_delta(0.0, (worksheet.energy_security_l129||0), 0.002); end
  def test_energy_security_m129; assert_in_delta(0.0, (worksheet.energy_security_m129||0), 0.002); end
  def test_energy_security_d32; assert_equal("Nuclear fission", worksheet.energy_security_d32); end
  def test_energy_security_e32; assert_in_delta(0.0, (worksheet.energy_security_e32||0), 0.002); end
  def test_energy_security_f32; assert_in_delta(0.0, (worksheet.energy_security_f32||0), 0.002); end
  def test_energy_security_g32; assert_in_delta(0.0, (worksheet.energy_security_g32||0), 0.002); end
  def test_energy_security_h32; assert_in_delta(0.0, (worksheet.energy_security_h32||0), 0.002); end
  def test_energy_security_i32; assert_in_delta(0.0, (worksheet.energy_security_i32||0), 0.002); end
  def test_energy_security_j32; assert_in_delta(0.0, (worksheet.energy_security_j32||0), 0.002); end
  def test_energy_security_k32; assert_in_delta(0.0, (worksheet.energy_security_k32||0), 0.002); end
  def test_energy_security_l32; assert_in_delta(0.0, (worksheet.energy_security_l32||0), 0.002); end
  def test_energy_security_m32; assert_in_delta(0.0, (worksheet.energy_security_m32||0), 0.002); end
  def test_energy_security_d33; assert_equal("Solar", worksheet.energy_security_d33); end
  def test_energy_security_e33; assert_in_delta(6.808780851633277e-06, worksheet.energy_security_e33, 0.002); end
  def test_energy_security_f33; assert_in_delta(0.00022056952072102394, worksheet.energy_security_f33, 0.002); end
  def test_energy_security_g33; assert_in_delta(0.00046572542264136765, worksheet.energy_security_g33, 0.002); end
  def test_energy_security_h33; assert_in_delta(0.0006397821874941362, worksheet.energy_security_h33, 0.002); end
  def test_energy_security_i33; assert_in_delta(0.0007454352596164658, worksheet.energy_security_i33, 0.002); end
  def test_energy_security_j33; assert_in_delta(0.0008249899807257838, worksheet.energy_security_j33, 0.002); end
  def test_energy_security_k33; assert_in_delta(0.0008807095805885178, worksheet.energy_security_k33, 0.002); end
  def test_energy_security_l33; assert_in_delta(0.000932372424871206, worksheet.energy_security_l33, 0.002); end
  def test_energy_security_m33; assert_in_delta(0.0009652555097466939, worksheet.energy_security_m33, 0.002); end
  def test_energy_security_d34; assert_equal("Wind", worksheet.energy_security_d34); end
  def test_energy_security_e34; assert_in_delta(0.0, (worksheet.energy_security_e34||0), 0.002); end
  def test_energy_security_f34; assert_in_delta(0.0, (worksheet.energy_security_f34||0), 0.002); end
  def test_energy_security_g34; assert_in_delta(4.032254741483703e-06, worksheet.energy_security_g34, 0.002); end
  def test_energy_security_h34; assert_in_delta(3.584213935541379e-06, worksheet.energy_security_h34, 0.002); end
  def test_energy_security_i34; assert_in_delta(3.086688445616836e-06, worksheet.energy_security_i34, 0.002); end
  def test_energy_security_j34; assert_in_delta(2.7093267018909154e-06, worksheet.energy_security_j34, 0.002); end
  def test_energy_security_k34; assert_in_delta(2.396488654662634e-06, worksheet.energy_security_k34, 0.002); end
  def test_energy_security_l34; assert_in_delta(2.1657896048111637e-06, worksheet.energy_security_l34, 0.002); end
  def test_energy_security_m34; assert_in_delta(1.9559382163053574e-06, worksheet.energy_security_m34, 0.002); end
  def test_energy_security_d35; assert_equal("Hydro", worksheet.energy_security_d35); end
  def test_energy_security_e35; assert_in_delta(0.002533298780353714, worksheet.energy_security_e35, 0.002); end
  def test_energy_security_f35; assert_in_delta(0.002461975983667048, worksheet.energy_security_f35, 0.002); end
  def test_energy_security_g35; assert_in_delta(0.0023629012785094496, worksheet.energy_security_g35, 0.002); end
  def test_energy_security_h35; assert_in_delta(0.002100349366227248, worksheet.energy_security_h35, 0.002); end
  def test_energy_security_i35; assert_in_delta(0.0018087994291314656, worksheet.energy_security_i35, 0.002); end
  def test_energy_security_j35; assert_in_delta(0.0015876654473080763, worksheet.energy_security_j35, 0.002); end
  def test_energy_security_k35; assert_in_delta(0.0014043423516323032, worksheet.energy_security_k35, 0.002); end
  def test_energy_security_l35; assert_in_delta(0.0012691527084193418, worksheet.energy_security_l35, 0.002); end
  def test_energy_security_m35; assert_in_delta(0.0011461797947549394, worksheet.energy_security_m35, 0.002); end
  def test_energy_security_d36; assert_equal("Electricity imports", worksheet.energy_security_d36); end
  def test_energy_security_e36; assert_in_delta(0.0, (worksheet.energy_security_e36||0), 0.002); end
  def test_energy_security_f36; assert_in_delta(0.0, (worksheet.energy_security_f36||0), 0.002); end
  def test_energy_security_g36; assert_in_delta(0.0, (worksheet.energy_security_g36||0), 0.002); end
  def test_energy_security_h36; assert_in_delta(0.0, (worksheet.energy_security_h36||0), 0.002); end
  def test_energy_security_i36; assert_in_delta(0.0, (worksheet.energy_security_i36||0), 0.002); end
  def test_energy_security_j36; assert_in_delta(0.0, (worksheet.energy_security_j36||0), 0.002); end
  def test_energy_security_k36; assert_in_delta(0.0, (worksheet.energy_security_k36||0), 0.002); end
  def test_energy_security_l36; assert_in_delta(0.0, (worksheet.energy_security_l36||0), 0.002); end
  def test_energy_security_m36; assert_in_delta(0.0, (worksheet.energy_security_m36||0), 0.002); end
  def test_energy_security_d37; assert_equal("Waste", worksheet.energy_security_d37); end
  def test_energy_security_e37; assert_in_delta(0.03585617490742909, worksheet.energy_security_e37, 0.002); end
  def test_energy_security_f37; assert_in_delta(0.0375789201246558, worksheet.energy_security_f37, 0.002); end
  def test_energy_security_g37; assert_in_delta(0.04142534927628631, worksheet.energy_security_g37, 0.002); end
  def test_energy_security_h37; assert_in_delta(0.03871217934645985, worksheet.energy_security_h37, 0.002); end
  def test_energy_security_i37; assert_in_delta(0.03521214061136662, worksheet.energy_security_i37, 0.002); end
  def test_energy_security_j37; assert_in_delta(0.03263314976802328, worksheet.energy_security_j37, 0.002); end
  def test_energy_security_k37; assert_in_delta(0.030422762229544004, worksheet.energy_security_k37, 0.002); end
  def test_energy_security_l37; assert_in_delta(0.029007367348685607, worksheet.energy_security_l37, 0.002); end
  def test_energy_security_m37; assert_in_delta(0.027598024226597205, worksheet.energy_security_m37, 0.002); end
  def test_energy_security_d38; assert_equal("Agriculture", worksheet.energy_security_d38); end
  def test_energy_security_e38; assert_in_delta(0.41258360770679503, worksheet.energy_security_e38, 0.002); end
  def test_energy_security_f38; assert_in_delta(0.406168695617057, worksheet.energy_security_f38, 0.002); end
  def test_energy_security_g38; assert_in_delta(0.39489004837435815, worksheet.energy_security_g38, 0.002); end
  def test_energy_security_h38; assert_in_delta(0.35558357746580405, worksheet.energy_security_h38, 0.002); end
  def test_energy_security_i38; assert_in_delta(0.3102218551842887, worksheet.energy_security_i38, 0.002); end
  def test_energy_security_j38; assert_in_delta(0.27585815817727566, worksheet.energy_security_j38, 0.002); end
  def test_energy_security_k38; assert_in_delta(0.24720572957312675, worksheet.energy_security_k38, 0.002); end
  def test_energy_security_l38; assert_in_delta(0.22634599276599465, worksheet.energy_security_l38, 0.002); end
  def test_energy_security_m38; assert_in_delta(0.207109805134457, worksheet.energy_security_m38, 0.002); end
  def test_energy_security_d39; assert_equal("Biomass imports", worksheet.energy_security_d39); end
  def test_energy_security_e39; assert_in_delta(0.0, (worksheet.energy_security_e39||0), 0.002); end
  def test_energy_security_f39; assert_in_delta(0.0, (worksheet.energy_security_f39||0), 0.002); end
  def test_energy_security_g39; assert_in_delta(0.0, (worksheet.energy_security_g39||0), 0.002); end
  def test_energy_security_h39; assert_in_delta(0.0, (worksheet.energy_security_h39||0), 0.002); end
  def test_energy_security_i39; assert_in_delta(0.0, (worksheet.energy_security_i39||0), 0.002); end
  def test_energy_security_j39; assert_in_delta(0.0, (worksheet.energy_security_j39||0), 0.002); end
  def test_energy_security_k39; assert_in_delta(0.0, (worksheet.energy_security_k39||0), 0.002); end
  def test_energy_security_l39; assert_in_delta(0.0, (worksheet.energy_security_l39||0), 0.002); end
  def test_energy_security_m39; assert_in_delta(0.0, (worksheet.energy_security_m39||0), 0.002); end
  def test_energy_security_d40; assert_equal("Coal reserves", worksheet.energy_security_d40); end
  def test_energy_security_e40; assert_in_delta(0.0015219271179031382, worksheet.energy_security_e40, 0.002); end
  def test_energy_security_f40; assert_in_delta(0.001479078599898099, worksheet.energy_security_f40, 0.002); end
  def test_energy_security_g40; assert_in_delta(0.0016495515946150692, worksheet.energy_security_g40, 0.002); end
  def test_energy_security_h40; assert_in_delta(0.03765073768702212, worksheet.energy_security_h40, 0.002); end
  def test_energy_security_i40; assert_in_delta(0.06467280148813123, worksheet.energy_security_i40, 0.002); end
  def test_energy_security_j40; assert_in_delta(0.08507211666615042, worksheet.energy_security_j40, 0.002); end
  def test_energy_security_k40; assert_in_delta(0.10028655275900182, worksheet.energy_security_k40, 0.002); end
  def test_energy_security_l40; assert_in_delta(0.11325964537290106, worksheet.energy_security_l40, 0.002); end
  def test_energy_security_m40; assert_in_delta(0.12272028507505665, worksheet.energy_security_m40, 0.002); end
  def test_energy_security_d41; assert_equal("Coal imports", worksheet.energy_security_d41); end
  def test_energy_security_e41; assert_in_delta(0.0, (worksheet.energy_security_e41||0), 0.002); end
  def test_energy_security_f41; assert_in_delta(0.0, (worksheet.energy_security_f41||0), 0.002); end
  def test_energy_security_g41; assert_in_delta(0.0, (worksheet.energy_security_g41||0), 0.002); end
  def test_energy_security_h41; assert_in_delta(0.0, (worksheet.energy_security_h41||0), 0.002); end
  def test_energy_security_i41; assert_in_delta(0.0, (worksheet.energy_security_i41||0), 0.002); end
  def test_energy_security_j41; assert_in_delta(0.0, (worksheet.energy_security_j41||0), 0.002); end
  def test_energy_security_k41; assert_in_delta(0.0, (worksheet.energy_security_k41||0), 0.002); end
  def test_energy_security_l41; assert_in_delta(0.0, (worksheet.energy_security_l41||0), 0.002); end
  def test_energy_security_m41; assert_in_delta(0.0, (worksheet.energy_security_m41||0), 0.002); end
  def test_energy_security_d42; assert_equal("Oil reserves", worksheet.energy_security_d42); end
  def test_energy_security_e42; assert_in_delta(0.35974447418811145, worksheet.energy_security_e42, 0.002); end
  def test_energy_security_f42; assert_in_delta(0.3496161852588096, worksheet.energy_security_f42, 0.002); end
  def test_energy_security_g42; assert_in_delta(0.3403404773804445, worksheet.energy_security_g42, 0.002); end
  def test_energy_security_h42; assert_in_delta(0.30678471239704713, worksheet.energy_security_h42, 0.002); end
  def test_energy_security_i42; assert_in_delta(0.26786930449930346, worksheet.energy_security_i42, 0.002); end
  def test_energy_security_j42; assert_in_delta(0.23834189646256934, worksheet.energy_security_j42, 0.002); end
  def test_energy_security_k42; assert_in_delta(0.2136701891223085, worksheet.energy_security_k42, 0.002); end
  def test_energy_security_l42; assert_in_delta(0.19567581478269114, worksheet.energy_security_l42, 0.002); end
  def test_energy_security_m42; assert_in_delta(0.1790412705621478, worksheet.energy_security_m42, 0.002); end
  def test_energy_security_d43; assert_equal("Oil imports", worksheet.energy_security_d43); end
  def test_energy_security_e43; assert_in_delta(0.0, (worksheet.energy_security_e43||0), 0.002); end
  def test_energy_security_f43; assert_in_delta(0.0, (worksheet.energy_security_f43||0), 0.002); end
  def test_energy_security_g43; assert_in_delta(0.0, (worksheet.energy_security_g43||0), 0.002); end
  def test_energy_security_h43; assert_in_delta(0.04217274315048202, worksheet.energy_security_h43, 0.002); end
  def test_energy_security_i43; assert_in_delta(0.11436439104649464, worksheet.energy_security_i43, 0.002); end
  def test_energy_security_j43; assert_in_delta(0.16916619805499714, worksheet.energy_security_j43, 0.002); end
  def test_energy_security_k43; assert_in_delta(0.21772293465135226, worksheet.energy_security_k43, 0.002); end
  def test_energy_security_l43; assert_in_delta(0.2500616232811529, worksheet.energy_security_l43, 0.002); end
  def test_energy_security_m43; assert_in_delta(0.28384469005193375, worksheet.energy_security_m43, 0.002); end
  def test_energy_security_d44; assert_equal("Gas reserves", worksheet.energy_security_d44); end
  def test_energy_security_e44; assert_in_delta(0.187753708518556, worksheet.energy_security_e44, 0.002); end
  def test_energy_security_f44; assert_in_delta(0.20247457489519152, worksheet.energy_security_f44, 0.002); end
  def test_energy_security_g44; assert_in_delta(0.21886191441840372, worksheet.energy_security_g44, 0.002); end
  def test_energy_security_h44; assert_in_delta(0.21635233418552782, worksheet.energy_security_h44, 0.002); end
  def test_energy_security_i44; assert_in_delta(0.20510218579322187, worksheet.energy_security_i44, 0.002); end
  def test_energy_security_j44; assert_in_delta(0.19651311611624858, worksheet.energy_security_j44, 0.002); end
  def test_energy_security_k44; assert_in_delta(0.1884043832437912, worksheet.energy_security_k44, 0.002); end
  def test_energy_security_l44; assert_in_delta(0.18344586552567924, worksheet.energy_security_l44, 0.002); end
  def test_energy_security_m44; assert_in_delta(0.17757253370708953, worksheet.energy_security_m44, 0.002); end
  def test_energy_security_d45; assert_equal("Gas imports", worksheet.energy_security_d45); end
  def test_energy_security_e45; assert_in_delta(0.0, (worksheet.energy_security_e45||0), 0.002); end
  def test_energy_security_f45; assert_in_delta(0.0, (worksheet.energy_security_f45||0), 0.002); end
  def test_energy_security_g45; assert_in_delta(0.0, (worksheet.energy_security_g45||0), 0.002); end
  def test_energy_security_h45; assert_in_delta(0.0, (worksheet.energy_security_h45||0), 0.002); end
  def test_energy_security_i45; assert_in_delta(0.0, (worksheet.energy_security_i45||0), 0.002); end
  def test_energy_security_j45; assert_in_delta(0.0, (worksheet.energy_security_j45||0), 0.002); end
  def test_energy_security_k45; assert_in_delta(0.0, (worksheet.energy_security_k45||0), 0.002); end
  def test_energy_security_l45; assert_in_delta(0.0, (worksheet.energy_security_l45||0), 0.002); end
  def test_energy_security_m45; assert_in_delta(0.0, (worksheet.energy_security_m45||0), 0.002); end
  def test_energy_security_d114; assert_equal("Uranium", worksheet.energy_security_d114); end
  def test_energy_security_e114; assert_in_delta(0.0, (worksheet.energy_security_e114||0), 0.002); end
  def test_energy_security_f114; assert_in_delta(0.0, (worksheet.energy_security_f114||0), 0.002); end
  def test_energy_security_g114; assert_in_delta(0.0, (worksheet.energy_security_g114||0), 0.002); end
  def test_energy_security_h114; assert_in_delta(0.0, (worksheet.energy_security_h114||0), 0.002); end
  def test_energy_security_i114; assert_in_delta(0.0, (worksheet.energy_security_i114||0), 0.002); end
  def test_energy_security_j114; assert_in_delta(0.0, (worksheet.energy_security_j114||0), 0.002); end
  def test_energy_security_k114; assert_in_delta(0.0, (worksheet.energy_security_k114||0), 0.002); end
  def test_energy_security_l114; assert_in_delta(0.0, (worksheet.energy_security_l114||0), 0.002); end
  def test_energy_security_m114; assert_in_delta(0.0, (worksheet.energy_security_m114||0), 0.002); end
  def test_energy_security_d115; assert_equal("Electricity", worksheet.energy_security_d115); end
  def test_energy_security_e115; assert_in_delta(0.0, (worksheet.energy_security_e115||0), 0.002); end
  def test_energy_security_f115; assert_in_delta(0.0, (worksheet.energy_security_f115||0), 0.002); end
  def test_energy_security_g115; assert_in_delta(0.0, (worksheet.energy_security_g115||0), 0.002); end
  def test_energy_security_h115; assert_in_delta(0.0, (worksheet.energy_security_h115||0), 0.002); end
  def test_energy_security_i115; assert_in_delta(0.0, (worksheet.energy_security_i115||0), 0.002); end
  def test_energy_security_j115; assert_in_delta(0.0, (worksheet.energy_security_j115||0), 0.002); end
  def test_energy_security_k115; assert_in_delta(0.0, (worksheet.energy_security_k115||0), 0.002); end
  def test_energy_security_l115; assert_in_delta(0.0, (worksheet.energy_security_l115||0), 0.002); end
  def test_energy_security_m115; assert_in_delta(0.0, (worksheet.energy_security_m115||0), 0.002); end
  def test_energy_security_d116; assert_equal("Bioenergy", worksheet.energy_security_d116); end
  def test_energy_security_e116; assert_in_delta(0.0, (worksheet.energy_security_e116||0), 0.002); end
  def test_energy_security_f116; assert_in_delta(0.0, (worksheet.energy_security_f116||0), 0.002); end
  def test_energy_security_g116; assert_in_delta(0.0, (worksheet.energy_security_g116||0), 0.002); end
  def test_energy_security_h116; assert_in_delta(0.0, (worksheet.energy_security_h116||0), 0.002); end
  def test_energy_security_i116; assert_in_delta(0.0, (worksheet.energy_security_i116||0), 0.002); end
  def test_energy_security_j116; assert_in_delta(0.0, (worksheet.energy_security_j116||0), 0.002); end
  def test_energy_security_k116; assert_in_delta(0.0, (worksheet.energy_security_k116||0), 0.002); end
  def test_energy_security_l116; assert_in_delta(0.0, (worksheet.energy_security_l116||0), 0.002); end
  def test_energy_security_m116; assert_in_delta(0.0, (worksheet.energy_security_m116||0), 0.002); end
  def test_energy_security_d117; assert_equal("Coal", worksheet.energy_security_d117); end
  def test_energy_security_e117; assert_in_delta(0.0, (worksheet.energy_security_e117||0), 0.002); end
  def test_energy_security_f117; assert_in_delta(0.0, (worksheet.energy_security_f117||0), 0.002); end
  def test_energy_security_g117; assert_in_delta(0.0, (worksheet.energy_security_g117||0), 0.002); end
  def test_energy_security_h117; assert_in_delta(0.0, (worksheet.energy_security_h117||0), 0.002); end
  def test_energy_security_i117; assert_in_delta(0.0, (worksheet.energy_security_i117||0), 0.002); end
  def test_energy_security_j117; assert_in_delta(0.0, (worksheet.energy_security_j117||0), 0.002); end
  def test_energy_security_k117; assert_in_delta(0.0, (worksheet.energy_security_k117||0), 0.002); end
  def test_energy_security_l117; assert_in_delta(0.0, (worksheet.energy_security_l117||0), 0.002); end
  def test_energy_security_m117; assert_in_delta(0.0, (worksheet.energy_security_m117||0), 0.002); end
  def test_energy_security_d118; assert_equal("Oil", worksheet.energy_security_d118); end
  def test_energy_security_e118; assert_in_delta(0.0, (worksheet.energy_security_e118||0), 0.002); end
  def test_energy_security_f118; assert_in_delta(0.0, (worksheet.energy_security_f118||0), 0.002); end
  def test_energy_security_g118; assert_in_delta(0.0, (worksheet.energy_security_g118||0), 0.002); end
  def test_energy_security_h118; assert_in_delta(0.12085353810340917, worksheet.energy_security_h118, 0.002); end
  def test_energy_security_i118; assert_in_delta(0.299200181405231, worksheet.energy_security_i118, 0.002); end
  def test_energy_security_j118; assert_in_delta(0.41512352841792416, worksheet.energy_security_j118, 0.002); end
  def test_energy_security_k118; assert_in_delta(0.504697276458178, worksheet.energy_security_k118, 0.002); end
  def test_energy_security_l118; assert_in_delta(0.5610065521248317, worksheet.energy_security_l118, 0.002); end
  def test_energy_security_m118; assert_in_delta(0.6132065221320926, worksheet.energy_security_m118, 0.002); end
  def test_energy_security_d119; assert_equal("Gas", worksheet.energy_security_d119); end
  def test_energy_security_e119; assert_in_delta(0.0, (worksheet.energy_security_e119||0), 0.002); end
  def test_energy_security_f119; assert_in_delta(0.0, (worksheet.energy_security_f119||0), 0.002); end
  def test_energy_security_g119; assert_in_delta(0.0, (worksheet.energy_security_g119||0), 0.002); end
  def test_energy_security_h119; assert_in_delta(0.0, (worksheet.energy_security_h119||0), 0.002); end
  def test_energy_security_i119; assert_in_delta(0.0, (worksheet.energy_security_i119||0), 0.002); end
  def test_energy_security_j119; assert_in_delta(0.0, (worksheet.energy_security_j119||0), 0.002); end
  def test_energy_security_k119; assert_in_delta(0.0, (worksheet.energy_security_k119||0), 0.002); end
  def test_energy_security_l119; assert_in_delta(0.0, (worksheet.energy_security_l119||0), 0.002); end
  def test_energy_security_m119; assert_in_delta(0.0, (worksheet.energy_security_m119||0), 0.002); end
  def test_energy_security_d120; assert_equal("Total", worksheet.energy_security_d120); end
  def test_energy_security_e120; assert_in_delta(0.0, (worksheet.energy_security_e120||0), 0.002); end
  def test_energy_security_f120; assert_in_delta(0.0, (worksheet.energy_security_f120||0), 0.002); end
  def test_energy_security_g120; assert_in_delta(0.0, (worksheet.energy_security_g120||0), 0.002); end
  def test_energy_security_h120; assert_in_delta(0.05292202367021196, worksheet.energy_security_h120, 0.002); end
  def test_energy_security_i120; assert_in_delta(0.1491352945610093, worksheet.energy_security_i120, 0.002); end
  def test_energy_security_j120; assert_in_delta(0.22734650439855703, worksheet.energy_security_j120, 0.002); end
  def test_energy_security_k120; assert_in_delta(0.2989427863629368, worksheet.energy_security_k120, 0.002); end
  def test_energy_security_l120; assert_in_delta(0.3505183329754975, worksheet.energy_security_l120, 0.002); end
  def test_energy_security_m120; assert_in_delta(0.40306246579131627, worksheet.energy_security_m120, 0.002); end
  def test_energy_security_d92; assert_equal("Uranium", worksheet.energy_security_d92); end
  def test_energy_security_e92; assert_in_delta(0.0, (worksheet.energy_security_e92||0), 0.002); end
  def test_energy_security_f92; assert_in_delta(0.0, (worksheet.energy_security_f92||0), 0.002); end
  def test_energy_security_g92; assert_in_delta(0.0, (worksheet.energy_security_g92||0), 0.002); end
  def test_energy_security_h92; assert_in_delta(0.0, (worksheet.energy_security_h92||0), 0.002); end
  def test_energy_security_i92; assert_in_delta(0.0, (worksheet.energy_security_i92||0), 0.002); end
  def test_energy_security_j92; assert_in_delta(0.0, (worksheet.energy_security_j92||0), 0.002); end
  def test_energy_security_k92; assert_in_delta(0.0, (worksheet.energy_security_k92||0), 0.002); end
  def test_energy_security_l92; assert_in_delta(0.0, (worksheet.energy_security_l92||0), 0.002); end
  def test_energy_security_m92; assert_in_delta(0.0, (worksheet.energy_security_m92||0), 0.002); end
  def test_energy_security_d93; assert_equal("Electricity", worksheet.energy_security_d93); end
  def test_energy_security_e93; assert_in_delta(0.0, (worksheet.energy_security_e93||0), 0.002); end
  def test_energy_security_f93; assert_in_delta(0.0, (worksheet.energy_security_f93||0), 0.002); end
  def test_energy_security_g93; assert_in_delta(0.0, (worksheet.energy_security_g93||0), 0.002); end
  def test_energy_security_h93; assert_in_delta(0.0, (worksheet.energy_security_h93||0), 0.002); end
  def test_energy_security_i93; assert_in_delta(0.0, (worksheet.energy_security_i93||0), 0.002); end
  def test_energy_security_j93; assert_in_delta(0.0, (worksheet.energy_security_j93||0), 0.002); end
  def test_energy_security_k93; assert_in_delta(0.0, (worksheet.energy_security_k93||0), 0.002); end
  def test_energy_security_l93; assert_in_delta(0.0, (worksheet.energy_security_l93||0), 0.002); end
  def test_energy_security_m93; assert_in_delta(0.0, (worksheet.energy_security_m93||0), 0.002); end
  def test_energy_security_d94; assert_equal("Bioenergy", worksheet.energy_security_d94); end
  def test_energy_security_e94; assert_in_delta(0.0, (worksheet.energy_security_e94||0), 0.002); end
  def test_energy_security_f94; assert_in_delta(0.0, (worksheet.energy_security_f94||0), 0.002); end
  def test_energy_security_g94; assert_in_delta(0.0, (worksheet.energy_security_g94||0), 0.002); end
  def test_energy_security_h94; assert_in_delta(0.0, (worksheet.energy_security_h94||0), 0.002); end
  def test_energy_security_i94; assert_in_delta(0.0, (worksheet.energy_security_i94||0), 0.002); end
  def test_energy_security_j94; assert_in_delta(0.0, (worksheet.energy_security_j94||0), 0.002); end
  def test_energy_security_k94; assert_in_delta(0.0, (worksheet.energy_security_k94||0), 0.002); end
  def test_energy_security_l94; assert_in_delta(0.0, (worksheet.energy_security_l94||0), 0.002); end
  def test_energy_security_m94; assert_in_delta(0.0, (worksheet.energy_security_m94||0), 0.002); end
  def test_energy_security_d95; assert_equal("Coal", worksheet.energy_security_d95); end
  def test_energy_security_e95; assert_in_delta(0.0, (worksheet.energy_security_e95||0), 0.002); end
  def test_energy_security_f95; assert_in_delta(0.0, (worksheet.energy_security_f95||0), 0.002); end
  def test_energy_security_g95; assert_in_delta(0.0, (worksheet.energy_security_g95||0), 0.002); end
  def test_energy_security_h95; assert_in_delta(0.0, (worksheet.energy_security_h95||0), 0.002); end
  def test_energy_security_i95; assert_in_delta(0.0, (worksheet.energy_security_i95||0), 0.002); end
  def test_energy_security_j95; assert_in_delta(0.0, (worksheet.energy_security_j95||0), 0.002); end
  def test_energy_security_k95; assert_in_delta(0.0, (worksheet.energy_security_k95||0), 0.002); end
  def test_energy_security_l95; assert_in_delta(0.0, (worksheet.energy_security_l95||0), 0.002); end
  def test_energy_security_m95; assert_in_delta(0.0, (worksheet.energy_security_m95||0), 0.002); end
  def test_energy_security_d96; assert_equal("Oil", worksheet.energy_security_d96); end
  def test_energy_security_e96; assert_in_delta(0.0, (worksheet.energy_security_e96||0), 0.002); end
  def test_energy_security_f96; assert_in_delta(0.0, (worksheet.energy_security_f96||0), 0.002); end
  def test_energy_security_g96; assert_in_delta(0.0, (worksheet.energy_security_g96||0), 0.002); end
  def test_energy_security_h96; assert_in_epsilon(206.28582618424866, worksheet.energy_security_h96, 0.002); end
  def test_energy_security_i96; assert_in_epsilon(649.5752775678864, worksheet.energy_security_i96, 0.002); end
  def test_energy_security_j96; assert_in_epsilon(1094.6711528846922, worksheet.energy_security_j96, 0.002); end
  def test_energy_security_k96; assert_in_epsilon(1592.796395209667, worksheet.energy_security_k96, 0.002); end
  def test_energy_security_l96; assert_in_epsilon(2024.2411218643847, worksheet.energy_security_l96, 0.002); end
  def test_energy_security_m96; assert_in_epsilon(2544.2343037759847, worksheet.energy_security_m96, 0.002); end
  def test_energy_security_d97; assert_equal("Gas", worksheet.energy_security_d97); end
  def test_energy_security_e97; assert_in_delta(0.0, (worksheet.energy_security_e97||0), 0.002); end
  def test_energy_security_f97; assert_in_delta(0.0, (worksheet.energy_security_f97||0), 0.002); end
  def test_energy_security_g97; assert_in_delta(0.0, (worksheet.energy_security_g97||0), 0.002); end
  def test_energy_security_h97; assert_in_delta(0.0, (worksheet.energy_security_h97||0), 0.002); end
  def test_energy_security_i97; assert_in_delta(0.0, (worksheet.energy_security_i97||0), 0.002); end
  def test_energy_security_j97; assert_in_delta(0.0, (worksheet.energy_security_j97||0), 0.002); end
  def test_energy_security_k97; assert_in_delta(0.0, (worksheet.energy_security_k97||0), 0.002); end
  def test_energy_security_l97; assert_in_delta(0.0, (worksheet.energy_security_l97||0), 0.002); end
  def test_energy_security_m97; assert_in_delta(0.0, (worksheet.energy_security_m97||0), 0.002); end
  def test_energy_security_d98; assert_equal("Total", worksheet.energy_security_d98); end
  def test_energy_security_e98; assert_in_delta(0.0, (worksheet.energy_security_e98||0), 0.002); end
  def test_energy_security_f98; assert_in_delta(0.0, (worksheet.energy_security_f98||0), 0.002); end
  def test_energy_security_g98; assert_in_delta(0.0, (worksheet.energy_security_g98||0), 0.002); end
  def test_energy_security_h98; assert_in_epsilon(206.28582618424866, worksheet.energy_security_h98, 0.002); end
  def test_energy_security_i98; assert_in_epsilon(649.5752775678864, worksheet.energy_security_i98, 0.002); end
  def test_energy_security_j98; assert_in_epsilon(1094.6711528846922, worksheet.energy_security_j98, 0.002); end
  def test_energy_security_k98; assert_in_epsilon(1592.796395209667, worksheet.energy_security_k98, 0.002); end
  def test_energy_security_l98; assert_in_epsilon(2024.2411218643847, worksheet.energy_security_l98, 0.002); end
  def test_energy_security_m98; assert_in_epsilon(2544.2343037759847, worksheet.energy_security_m98, 0.002); end
  def test_energy_security_d65; assert_equal("Shannon-Weiner Index", worksheet.energy_security_d65); end
  def test_energy_security_e65; assert_in_epsilon(1.1914537794408355, worksheet.energy_security_e65, 0.002); end
  def test_energy_security_f65; assert_in_epsilon(1.2044863497588862, worksheet.energy_security_f65, 0.002); end
  def test_energy_security_g65; assert_in_epsilon(1.2230555350660581, worksheet.energy_security_g65, 0.002); end
  def test_energy_security_h65; assert_in_epsilon(1.4572351118138758, worksheet.energy_security_h65, 0.002); end
  def test_energy_security_i65; assert_in_epsilon(1.5952689023146216, worksheet.energy_security_i65, 0.002); end
  def test_energy_security_j65; assert_in_epsilon(1.6489739730663255, worksheet.energy_security_j65, 0.002); end
  def test_energy_security_k65; assert_in_epsilon(1.6677836435691102, worksheet.energy_security_k65, 0.002); end
  def test_energy_security_l65; assert_in_epsilon(1.6710491787501343, worksheet.energy_security_l65, 0.002); end
  def test_energy_security_m65; assert_in_epsilon(1.662749765905819, worksheet.energy_security_m65, 0.002); end
  def test_costs_per_capita_e209; assert_equal("name", worksheet.costs_per_capita_e209); end
  def test_costs_per_capita_f209; assert_equal("low", worksheet.costs_per_capita_f209); end
  def test_costs_per_capita_g209; assert_equal("point", worksheet.costs_per_capita_g209); end
  def test_costs_per_capita_h209; assert_equal("high", worksheet.costs_per_capita_h209); end
  def test_costs_per_capita_i209; assert_equal("range", worksheet.costs_per_capita_i209); end
  def test_costs_per_capita_j209; assert_equal("finance_low", worksheet.costs_per_capita_j209); end
  def test_costs_per_capita_k209; assert_equal("finance_point", worksheet.costs_per_capita_k209); end
  def test_costs_per_capita_l209; assert_equal("finance_high", worksheet.costs_per_capita_l209); end
  def test_costs_per_capita_m209; assert_equal("finance_range", worksheet.costs_per_capita_m209); end
  def test_costs_per_capita_e210; assert_equal("Conventional thermal plant", worksheet.costs_per_capita_e210); end
  def test_costs_per_capita_f210; assert_in_delta(0.0, (worksheet.costs_per_capita_f210||0), 0.002); end
  def test_costs_per_capita_g210; assert_in_epsilon(2.945652369123549, worksheet.costs_per_capita_g210, 0.002); end
  def test_costs_per_capita_h210; assert_in_epsilon(3.500904955372067, worksheet.costs_per_capita_h210, 0.002); end
  def test_costs_per_capita_i210; assert_in_epsilon(3.500904955372067, worksheet.costs_per_capita_i210, 0.002); end
  def test_costs_per_capita_j210; assert_in_delta(0.0, (worksheet.costs_per_capita_j210||0), 0.002); end
  def test_costs_per_capita_k210; assert_in_delta(-0.11840052892289415, worksheet.costs_per_capita_k210, 0.002); end
  def test_costs_per_capita_l210; assert_in_epsilon(1.3916255654274128, worksheet.costs_per_capita_l210, 0.002); end
  def test_costs_per_capita_m210; assert_in_epsilon(1.3916255654274128, worksheet.costs_per_capita_m210, 0.002); end
  def test_costs_per_capita_e211; assert_equal("Combustion + CCS", worksheet.costs_per_capita_e211); end
  def test_costs_per_capita_f211; assert_in_delta(0.0, (worksheet.costs_per_capita_f211||0), 0.002); end
  def test_costs_per_capita_g211; assert_in_delta(0.0, (worksheet.costs_per_capita_g211||0), 0.002); end
  def test_costs_per_capita_h211; assert_in_delta(0.0, (worksheet.costs_per_capita_h211||0), 0.002); end
  def test_costs_per_capita_i211; assert_in_delta(0.0, (worksheet.costs_per_capita_i211||0), 0.002); end
  def test_costs_per_capita_j211; assert_in_delta(0.0, (worksheet.costs_per_capita_j211||0), 0.002); end
  def test_costs_per_capita_k211; assert_in_delta(0.0, (worksheet.costs_per_capita_k211||0), 0.002); end
  def test_costs_per_capita_l211; assert_in_delta(0.0, (worksheet.costs_per_capita_l211||0), 0.002); end
  def test_costs_per_capita_m211; assert_in_delta(0.0, (worksheet.costs_per_capita_m211||0), 0.002); end
  def test_costs_per_capita_e212; assert_equal("Nuclear power", worksheet.costs_per_capita_e212); end
  def test_costs_per_capita_f212; assert_in_delta(0.0, (worksheet.costs_per_capita_f212||0), 0.002); end
  def test_costs_per_capita_g212; assert_in_delta(0.0, (worksheet.costs_per_capita_g212||0), 0.002); end
  def test_costs_per_capita_h212; assert_in_delta(0.0, (worksheet.costs_per_capita_h212||0), 0.002); end
  def test_costs_per_capita_i212; assert_in_delta(0.0, (worksheet.costs_per_capita_i212||0), 0.002); end
  def test_costs_per_capita_j212; assert_in_delta(0.0, (worksheet.costs_per_capita_j212||0), 0.002); end
  def test_costs_per_capita_k212; assert_in_delta(0.0, (worksheet.costs_per_capita_k212||0), 0.002); end
  def test_costs_per_capita_l212; assert_in_delta(0.0, (worksheet.costs_per_capita_l212||0), 0.002); end
  def test_costs_per_capita_m212; assert_in_delta(0.0, (worksheet.costs_per_capita_m212||0), 0.002); end
  def test_costs_per_capita_e213; assert_equal("Onshore wind", worksheet.costs_per_capita_e213); end
  def test_costs_per_capita_f213; assert_in_delta(0.018485805849733087, worksheet.costs_per_capita_f213, 0.002); end
  def test_costs_per_capita_g213; assert_in_delta(0.06565008406900465, worksheet.costs_per_capita_g213, 0.002); end
  def test_costs_per_capita_h213; assert_in_delta(0.04248930357522954, worksheet.costs_per_capita_h213, 0.002); end
  def test_costs_per_capita_i213; assert_in_delta(0.02400349772549645, worksheet.costs_per_capita_i213, 0.002); end
  def test_costs_per_capita_j213; assert_in_delta(0.0, (worksheet.costs_per_capita_j213||0), 0.002); end
  def test_costs_per_capita_k213; assert_in_delta(0.0, (worksheet.costs_per_capita_k213||0), 0.002); end
  def test_costs_per_capita_l213; assert_in_delta(0.029197093738358278, worksheet.costs_per_capita_l213, 0.002); end
  def test_costs_per_capita_m213; assert_in_delta(0.029197093738358278, worksheet.costs_per_capita_m213, 0.002); end
  def test_costs_per_capita_e214; assert_equal("Offshore wind", worksheet.costs_per_capita_e214); end
  def test_costs_per_capita_f214; assert_in_delta(0.0, (worksheet.costs_per_capita_f214||0), 0.002); end
  def test_costs_per_capita_g214; assert_in_delta(0.0, (worksheet.costs_per_capita_g214||0), 0.002); end
  def test_costs_per_capita_h214; assert_in_delta(0.0, (worksheet.costs_per_capita_h214||0), 0.002); end
  def test_costs_per_capita_i214; assert_in_delta(0.0, (worksheet.costs_per_capita_i214||0), 0.002); end
  def test_costs_per_capita_j214; assert_in_delta(0.0, (worksheet.costs_per_capita_j214||0), 0.002); end
  def test_costs_per_capita_k214; assert_in_delta(-0.0048346148426873636, worksheet.costs_per_capita_k214, 0.002); end
  def test_costs_per_capita_l214; assert_in_delta(0.0, (worksheet.costs_per_capita_l214||0), 0.002); end
  def test_costs_per_capita_m214; assert_in_delta(0.0, (worksheet.costs_per_capita_m214||0), 0.002); end
  def test_costs_per_capita_e215; assert_equal("Hydroelectric", worksheet.costs_per_capita_e215); end
  def test_costs_per_capita_f215; assert_in_delta(0.0, (worksheet.costs_per_capita_f215||0), 0.002); end
  def test_costs_per_capita_g215; assert_in_delta(0.0, (worksheet.costs_per_capita_g215||0), 0.002); end
  def test_costs_per_capita_h215; assert_in_delta(0.0, (worksheet.costs_per_capita_h215||0), 0.002); end
  def test_costs_per_capita_i215; assert_in_delta(0.0, (worksheet.costs_per_capita_i215||0), 0.002); end
  def test_costs_per_capita_j215; assert_in_delta(0.0, (worksheet.costs_per_capita_j215||0), 0.002); end
  def test_costs_per_capita_k215; assert_in_delta(0.0, (worksheet.costs_per_capita_k215||0), 0.002); end
  def test_costs_per_capita_l215; assert_in_delta(0.0, (worksheet.costs_per_capita_l215||0), 0.002); end
  def test_costs_per_capita_m215; assert_in_delta(0.0, (worksheet.costs_per_capita_m215||0), 0.002); end
  def test_costs_per_capita_e216; assert_equal("Wave and Tidal", worksheet.costs_per_capita_e216); end
  def test_costs_per_capita_f216; assert_in_delta(0.0, (worksheet.costs_per_capita_f216||0), 0.002); end
  def test_costs_per_capita_g216; assert_in_delta(0.0, (worksheet.costs_per_capita_g216||0), 0.002); end
  def test_costs_per_capita_h216; assert_in_delta(0.0, (worksheet.costs_per_capita_h216||0), 0.002); end
  def test_costs_per_capita_i216; assert_in_delta(0.0, (worksheet.costs_per_capita_i216||0), 0.002); end
  def test_costs_per_capita_j216; assert_in_delta(0.0, (worksheet.costs_per_capita_j216||0), 0.002); end
  def test_costs_per_capita_k216; assert_in_delta(0.0, (worksheet.costs_per_capita_k216||0), 0.002); end
  def test_costs_per_capita_l216; assert_in_delta(0.0, (worksheet.costs_per_capita_l216||0), 0.002); end
  def test_costs_per_capita_m216; assert_in_delta(0.0, (worksheet.costs_per_capita_m216||0), 0.002); end
  def test_costs_per_capita_e217; assert_equal("Geothermal", worksheet.costs_per_capita_e217); end
  def test_costs_per_capita_f217; assert_in_delta(0.0, (worksheet.costs_per_capita_f217||0), 0.002); end
  def test_costs_per_capita_g217; assert_in_delta(0.0, (worksheet.costs_per_capita_g217||0), 0.002); end
  def test_costs_per_capita_h217; assert_in_delta(0.0, (worksheet.costs_per_capita_h217||0), 0.002); end
  def test_costs_per_capita_i217; assert_in_delta(0.0, (worksheet.costs_per_capita_i217||0), 0.002); end
  def test_costs_per_capita_j217; assert_in_delta(0.0, (worksheet.costs_per_capita_j217||0), 0.002); end
  def test_costs_per_capita_k217; assert_in_delta(0.0, (worksheet.costs_per_capita_k217||0), 0.002); end
  def test_costs_per_capita_l217; assert_in_delta(0.0, (worksheet.costs_per_capita_l217||0), 0.002); end
  def test_costs_per_capita_m217; assert_in_delta(0.0, (worksheet.costs_per_capita_m217||0), 0.002); end
  def test_costs_per_capita_e218; assert_equal("Distributed solar PV", worksheet.costs_per_capita_e218); end
  def test_costs_per_capita_f218; assert_in_delta(0.0, (worksheet.costs_per_capita_f218||0), 0.002); end
  def test_costs_per_capita_g218; assert_in_delta(0.8883701716539542, worksheet.costs_per_capita_g218, 0.002); end
  def test_costs_per_capita_h218; assert_in_epsilon(2.1385009790722727, worksheet.costs_per_capita_h218, 0.002); end
  def test_costs_per_capita_i218; assert_in_epsilon(2.1385009790722727, worksheet.costs_per_capita_i218, 0.002); end
  def test_costs_per_capita_j218; assert_in_delta(0.0, (worksheet.costs_per_capita_j218||0), 0.002); end
  def test_costs_per_capita_k218; assert_in_delta(0.0, (worksheet.costs_per_capita_k218||0), 0.002); end
  def test_costs_per_capita_l218; assert_in_epsilon(1.5980807182940442, worksheet.costs_per_capita_l218, 0.002); end
  def test_costs_per_capita_m218; assert_in_epsilon(1.5980807182940442, worksheet.costs_per_capita_m218, 0.002); end
  def test_costs_per_capita_e219; assert_equal("Distributed solar thermal", worksheet.costs_per_capita_e219); end
  def test_costs_per_capita_f219; assert_in_delta(0.0, (worksheet.costs_per_capita_f219||0), 0.002); end
  def test_costs_per_capita_g219; assert_in_delta(0.0, (worksheet.costs_per_capita_g219||0), 0.002); end
  def test_costs_per_capita_h219; assert_in_delta(0.0, (worksheet.costs_per_capita_h219||0), 0.002); end
  def test_costs_per_capita_i219; assert_in_delta(0.0, (worksheet.costs_per_capita_i219||0), 0.002); end
  def test_costs_per_capita_j219; assert_in_delta(0.0, (worksheet.costs_per_capita_j219||0), 0.002); end
  def test_costs_per_capita_k219; assert_in_delta(0.0, (worksheet.costs_per_capita_k219||0), 0.002); end
  def test_costs_per_capita_l219; assert_in_delta(0.0, (worksheet.costs_per_capita_l219||0), 0.002); end
  def test_costs_per_capita_m219; assert_in_delta(0.0, (worksheet.costs_per_capita_m219||0), 0.002); end
  def test_costs_per_capita_e220; assert_equal("Micro wind", worksheet.costs_per_capita_e220); end
  def test_costs_per_capita_f220; assert_in_delta(0.0, (worksheet.costs_per_capita_f220||0), 0.002); end
  def test_costs_per_capita_g220; assert_in_delta(0.0, (worksheet.costs_per_capita_g220||0), 0.002); end
  def test_costs_per_capita_h220; assert_in_delta(0.0, (worksheet.costs_per_capita_h220||0), 0.002); end
  def test_costs_per_capita_i220; assert_in_delta(0.0, (worksheet.costs_per_capita_i220||0), 0.002); end
  def test_costs_per_capita_j220; assert_in_delta(0.0, (worksheet.costs_per_capita_j220||0), 0.002); end
  def test_costs_per_capita_k220; assert_in_delta(0.0, (worksheet.costs_per_capita_k220||0), 0.002); end
  def test_costs_per_capita_l220; assert_in_delta(0.0, (worksheet.costs_per_capita_l220||0), 0.002); end
  def test_costs_per_capita_m220; assert_in_delta(0.0, (worksheet.costs_per_capita_m220||0), 0.002); end
  def test_costs_per_capita_e221; assert_equal("Biomatter to fuel conversion", worksheet.costs_per_capita_e221); end
  def test_costs_per_capita_f221; assert_in_delta(0.919638340600953, worksheet.costs_per_capita_f221, 0.002); end
  def test_costs_per_capita_g221; assert_in_epsilon(10.57565923552919, worksheet.costs_per_capita_g221, 0.002); end
  def test_costs_per_capita_h221; assert_in_epsilon(20.618436829169045, worksheet.costs_per_capita_h221, 0.002); end
  def test_costs_per_capita_i221; assert_in_epsilon(19.69879848856809, worksheet.costs_per_capita_i221, 0.002); end
  def test_costs_per_capita_j221; assert_in_delta(0.0, (worksheet.costs_per_capita_j221||0), 0.002); end
  def test_costs_per_capita_k221; assert_in_delta(0.0, (worksheet.costs_per_capita_k221||0), 0.002); end
  def test_costs_per_capita_l221; assert_in_epsilon(7.768398326868708, worksheet.costs_per_capita_l221, 0.002); end
  def test_costs_per_capita_m221; assert_in_epsilon(7.768398326868708, worksheet.costs_per_capita_m221, 0.002); end
  def test_costs_per_capita_e222; assert_equal("Bioenergy imports", worksheet.costs_per_capita_e222); end
  def test_costs_per_capita_f222; assert_in_delta(0.0, (worksheet.costs_per_capita_f222||0), 0.002); end
  def test_costs_per_capita_g222; assert_in_delta(0.0, (worksheet.costs_per_capita_g222||0), 0.002); end
  def test_costs_per_capita_h222; assert_in_delta(0.0, (worksheet.costs_per_capita_h222||0), 0.002); end
  def test_costs_per_capita_i222; assert_in_delta(0.0, (worksheet.costs_per_capita_i222||0), 0.002); end
  def test_costs_per_capita_j222; assert_in_delta(0.0, (worksheet.costs_per_capita_j222||0), 0.002); end
  def test_costs_per_capita_k222; assert_in_delta(-0.1033299433156957, worksheet.costs_per_capita_k222, 0.002); end
  def test_costs_per_capita_l222; assert_in_delta(0.0, (worksheet.costs_per_capita_l222||0), 0.002); end
  def test_costs_per_capita_m222; assert_in_delta(0.0, (worksheet.costs_per_capita_m222||0), 0.002); end
  def test_costs_per_capita_e223; assert_equal("Agriculture and land use", worksheet.costs_per_capita_e223); end
  def test_costs_per_capita_f223; assert_in_epsilon(54.61684084817734, worksheet.costs_per_capita_f223, 0.002); end
  def test_costs_per_capita_g223; assert_in_epsilon(360.35607811363536, worksheet.costs_per_capita_g223, 0.002); end
  def test_costs_per_capita_h223; assert_in_epsilon(270.33765024826477, worksheet.costs_per_capita_h223, 0.002); end
  def test_costs_per_capita_i223; assert_in_epsilon(215.72080940008743, worksheet.costs_per_capita_i223, 0.002); end
  def test_costs_per_capita_j223; assert_in_delta(0.0, (worksheet.costs_per_capita_j223||0), 0.002); end
  def test_costs_per_capita_k223; assert_in_delta(0.0, (worksheet.costs_per_capita_k223||0), 0.002); end
  def test_costs_per_capita_l223; assert_in_delta(0.0, (worksheet.costs_per_capita_l223||0), 0.002); end
  def test_costs_per_capita_m223; assert_in_delta(0.0, (worksheet.costs_per_capita_m223||0), 0.002); end
  def test_costs_per_capita_e224; assert_equal("Energy from waste", worksheet.costs_per_capita_e224); end
  def test_costs_per_capita_f224; assert_in_epsilon(2.2295971739663782, worksheet.costs_per_capita_f224, 0.002); end
  def test_costs_per_capita_g224; assert_in_epsilon(1.5231288372770675, worksheet.costs_per_capita_g224, 0.002); end
  def test_costs_per_capita_h224; assert_in_epsilon(1.467256605317613, worksheet.costs_per_capita_h224, 0.002); end
  def test_costs_per_capita_i224; assert_in_delta(-0.7623405686487652, worksheet.costs_per_capita_i224, 0.002); end
  def test_costs_per_capita_j224; assert_in_delta(0.0, (worksheet.costs_per_capita_j224||0), 0.002); end
  def test_costs_per_capita_k224; assert_in_delta(-0.07904976976838793, worksheet.costs_per_capita_k224, 0.002); end
  def test_costs_per_capita_l224; assert_in_delta(0.33866134244207896, worksheet.costs_per_capita_l224, 0.002); end
  def test_costs_per_capita_m224; assert_in_delta(0.33866134244207896, worksheet.costs_per_capita_m224, 0.002); end
  def test_costs_per_capita_e225; assert_equal("Waste arising", worksheet.costs_per_capita_e225); end
  def test_costs_per_capita_f225; assert_in_epsilon(16.63521209197423, worksheet.costs_per_capita_f225, 0.002); end
  def test_costs_per_capita_g225; assert_in_epsilon(21.92884739883715, worksheet.costs_per_capita_g225, 0.002); end
  def test_costs_per_capita_h225; assert_in_epsilon(31.75988439729687, worksheet.costs_per_capita_h225, 0.002); end
  def test_costs_per_capita_i225; assert_in_epsilon(15.12467230532264, worksheet.costs_per_capita_i225, 0.002); end
  def test_costs_per_capita_j225; assert_in_delta(0.0, (worksheet.costs_per_capita_j225||0), 0.002); end
  def test_costs_per_capita_k225; assert_in_delta(0.0, (worksheet.costs_per_capita_k225||0), 0.002); end
  def test_costs_per_capita_l225; assert_in_epsilon(4.49958010743211, worksheet.costs_per_capita_l225, 0.002); end
  def test_costs_per_capita_m225; assert_in_epsilon(4.49958010743211, worksheet.costs_per_capita_m225, 0.002); end
  def test_costs_per_capita_e226; assert_equal("Marine algae", worksheet.costs_per_capita_e226); end
  def test_costs_per_capita_f226; assert_in_delta(0.0, (worksheet.costs_per_capita_f226||0), 0.002); end
  def test_costs_per_capita_g226; assert_in_delta(0.0, (worksheet.costs_per_capita_g226||0), 0.002); end
  def test_costs_per_capita_h226; assert_in_delta(0.0, (worksheet.costs_per_capita_h226||0), 0.002); end
  def test_costs_per_capita_i226; assert_in_delta(0.0, (worksheet.costs_per_capita_i226||0), 0.002); end
  def test_costs_per_capita_j226; assert_in_delta(0.0, (worksheet.costs_per_capita_j226||0), 0.002); end
  def test_costs_per_capita_k226; assert_in_delta(0.0, (worksheet.costs_per_capita_k226||0), 0.002); end
  def test_costs_per_capita_l226; assert_in_delta(0.0, (worksheet.costs_per_capita_l226||0), 0.002); end
  def test_costs_per_capita_m226; assert_in_delta(0.0, (worksheet.costs_per_capita_m226||0), 0.002); end
  def test_costs_per_capita_e227; assert_equal("Electricity imports", worksheet.costs_per_capita_e227); end
  def test_costs_per_capita_f227; assert_in_delta(0.0, (worksheet.costs_per_capita_f227||0), 0.002); end
  def test_costs_per_capita_g227; assert_in_delta(0.0, (worksheet.costs_per_capita_g227||0), 0.002); end
  def test_costs_per_capita_h227; assert_in_delta(0.0, (worksheet.costs_per_capita_h227||0), 0.002); end
  def test_costs_per_capita_i227; assert_in_delta(0.0, (worksheet.costs_per_capita_i227||0), 0.002); end
  def test_costs_per_capita_j227; assert_in_delta(0.0, (worksheet.costs_per_capita_j227||0), 0.002); end
  def test_costs_per_capita_k227; assert_in_delta(0.0, (worksheet.costs_per_capita_k227||0), 0.002); end
  def test_costs_per_capita_l227; assert_in_delta(0.0, (worksheet.costs_per_capita_l227||0), 0.002); end
  def test_costs_per_capita_m227; assert_in_delta(0.0, (worksheet.costs_per_capita_m227||0), 0.002); end
  def test_costs_per_capita_e228; assert_equal("Electricity Exports", worksheet.costs_per_capita_e228); end
  def test_costs_per_capita_f228; assert_in_delta(0.0, (worksheet.costs_per_capita_f228||0), 0.002); end
  def test_costs_per_capita_g228; assert_in_delta(0.0, (worksheet.costs_per_capita_g228||0), 0.002); end
  def test_costs_per_capita_h228; assert_in_delta(0.0, (worksheet.costs_per_capita_h228||0), 0.002); end
  def test_costs_per_capita_i228; assert_in_delta(0.0, (worksheet.costs_per_capita_i228||0), 0.002); end
  def test_costs_per_capita_j228; assert_in_delta(0.0, (worksheet.costs_per_capita_j228||0), 0.002); end
  def test_costs_per_capita_k228; assert_in_delta(-0.355077574276917, worksheet.costs_per_capita_k228, 0.002); end
  def test_costs_per_capita_l228; assert_in_delta(0.0, (worksheet.costs_per_capita_l228||0), 0.002); end
  def test_costs_per_capita_m228; assert_in_delta(0.0, (worksheet.costs_per_capita_m228||0), 0.002); end
  def test_costs_per_capita_e229; assert_equal("Electricity grid distribution", worksheet.costs_per_capita_e229); end
  def test_costs_per_capita_f229; assert_in_epsilon(5.265573042653528, worksheet.costs_per_capita_f229, 0.002); end
  def test_costs_per_capita_g229; assert_in_epsilon(16.92788368829, worksheet.costs_per_capita_g229, 0.002); end
  def test_costs_per_capita_h229; assert_in_epsilon(45.293732129851776, worksheet.costs_per_capita_h229, 0.002); end
  def test_costs_per_capita_i229; assert_in_epsilon(40.02815908719825, worksheet.costs_per_capita_i229, 0.002); end
  def test_costs_per_capita_j229; assert_in_delta(0.0, (worksheet.costs_per_capita_j229||0), 0.002); end
  def test_costs_per_capita_k229; assert_in_epsilon(-1.6959069748423965, worksheet.costs_per_capita_k229, 0.002); end
  def test_costs_per_capita_l229; assert_in_epsilon(54.52233236238384, worksheet.costs_per_capita_l229, 0.002); end
  def test_costs_per_capita_m229; assert_in_epsilon(54.52233236238384, worksheet.costs_per_capita_m229, 0.002); end
  def test_costs_per_capita_e230; assert_equal("Storage, demand shifting, backup", worksheet.costs_per_capita_e230); end
  def test_costs_per_capita_f230; assert_in_delta(0.0, (worksheet.costs_per_capita_f230||0), 0.002); end
  def test_costs_per_capita_g230; assert_in_delta(0.0, (worksheet.costs_per_capita_g230||0), 0.002); end
  def test_costs_per_capita_h230; assert_in_delta(0.0, (worksheet.costs_per_capita_h230||0), 0.002); end
  def test_costs_per_capita_i230; assert_in_delta(0.0, (worksheet.costs_per_capita_i230||0), 0.002); end
  def test_costs_per_capita_j230; assert_in_delta(0.0, (worksheet.costs_per_capita_j230||0), 0.002); end
  def test_costs_per_capita_k230; assert_in_delta(0.0, (worksheet.costs_per_capita_k230||0), 0.002); end
  def test_costs_per_capita_l230; assert_in_delta(0.0, (worksheet.costs_per_capita_l230||0), 0.002); end
  def test_costs_per_capita_m230; assert_in_delta(0.0, (worksheet.costs_per_capita_m230||0), 0.002); end
  def test_costs_per_capita_e231; assert_equal("H2 Production", worksheet.costs_per_capita_e231); end
  def test_costs_per_capita_f231; assert_in_delta(0.0, (worksheet.costs_per_capita_f231||0), 0.002); end
  def test_costs_per_capita_g231; assert_in_delta(0.0, (worksheet.costs_per_capita_g231||0), 0.002); end
  def test_costs_per_capita_h231; assert_in_delta(0.0, (worksheet.costs_per_capita_h231||0), 0.002); end
  def test_costs_per_capita_i231; assert_in_delta(0.0, (worksheet.costs_per_capita_i231||0), 0.002); end
  def test_costs_per_capita_j231; assert_in_delta(0.0, (worksheet.costs_per_capita_j231||0), 0.002); end
  def test_costs_per_capita_k231; assert_in_delta(0.0, (worksheet.costs_per_capita_k231||0), 0.002); end
  def test_costs_per_capita_l231; assert_in_delta(0.0, (worksheet.costs_per_capita_l231||0), 0.002); end
  def test_costs_per_capita_m231; assert_in_delta(0.0, (worksheet.costs_per_capita_m231||0), 0.002); end
  def test_costs_per_capita_e232; assert_equal("Domestic heating", worksheet.costs_per_capita_e232); end
  def test_costs_per_capita_f232; assert_in_delta(0.0, (worksheet.costs_per_capita_f232||0), 0.002); end
  def test_costs_per_capita_g232; assert_in_delta(0.0, (worksheet.costs_per_capita_g232||0), 0.002); end
  def test_costs_per_capita_h232; assert_in_delta(0.0, (worksheet.costs_per_capita_h232||0), 0.002); end
  def test_costs_per_capita_i232; assert_in_delta(0.0, (worksheet.costs_per_capita_i232||0), 0.002); end
  def test_costs_per_capita_j232; assert_in_delta(0.0, (worksheet.costs_per_capita_j232||0), 0.002); end
  def test_costs_per_capita_k232; assert_in_delta(0.0, (worksheet.costs_per_capita_k232||0), 0.002); end
  def test_costs_per_capita_l232; assert_in_delta(0.0, (worksheet.costs_per_capita_l232||0), 0.002); end
  def test_costs_per_capita_m232; assert_in_delta(0.0, (worksheet.costs_per_capita_m232||0), 0.002); end
  def test_costs_per_capita_e233; assert_equal("Domestic insulation", worksheet.costs_per_capita_e233); end
  def test_costs_per_capita_f233; assert_in_delta(0.0, (worksheet.costs_per_capita_f233||0), 0.002); end
  def test_costs_per_capita_g233; assert_in_delta(0.0, (worksheet.costs_per_capita_g233||0), 0.002); end
  def test_costs_per_capita_h233; assert_in_delta(0.0, (worksheet.costs_per_capita_h233||0), 0.002); end
  def test_costs_per_capita_i233; assert_in_delta(0.0, (worksheet.costs_per_capita_i233||0), 0.002); end
  def test_costs_per_capita_j233; assert_in_delta(0.0, (worksheet.costs_per_capita_j233||0), 0.002); end
  def test_costs_per_capita_k233; assert_in_delta(-0.028276876255486312, worksheet.costs_per_capita_k233, 0.002); end
  def test_costs_per_capita_l233; assert_in_delta(0.0, (worksheet.costs_per_capita_l233||0), 0.002); end
  def test_costs_per_capita_m233; assert_in_delta(0.0, (worksheet.costs_per_capita_m233||0), 0.002); end
  def test_costs_per_capita_e234; assert_equal("Commercial heating and cooling", worksheet.costs_per_capita_e234); end
  def test_costs_per_capita_f234; assert_in_epsilon(1.6136087925241678, worksheet.costs_per_capita_f234, 0.002); end
  def test_costs_per_capita_g234; assert_in_epsilon(2.1783718699076267, worksheet.costs_per_capita_g234, 0.002); end
  def test_costs_per_capita_h234; assert_in_epsilon(3.2272175850483356, worksheet.costs_per_capita_h234, 0.002); end
  def test_costs_per_capita_i234; assert_in_epsilon(1.6136087925241678, worksheet.costs_per_capita_i234, 0.002); end
  def test_costs_per_capita_j234; assert_in_delta(0.0, (worksheet.costs_per_capita_j234||0), 0.002); end
  def test_costs_per_capita_k234; assert_in_delta(0.0, (worksheet.costs_per_capita_k234||0), 0.002); end
  def test_costs_per_capita_l234; assert_in_epsilon(2.0192646475460014, worksheet.costs_per_capita_l234, 0.002); end
  def test_costs_per_capita_m234; assert_in_epsilon(2.0192646475460014, worksheet.costs_per_capita_m234, 0.002); end
  def test_costs_per_capita_e235; assert_equal("Domestic lighting, appliances, and cooking", worksheet.costs_per_capita_e235); end
  def test_costs_per_capita_f235; assert_in_epsilon(10.171212369361953, worksheet.costs_per_capita_f235, 0.002); end
  def test_costs_per_capita_g235; assert_in_epsilon(11.805379802289922, worksheet.costs_per_capita_g235, 0.002); end
  def test_costs_per_capita_h235; assert_in_epsilon(15.25681855404293, worksheet.costs_per_capita_h235, 0.002); end
  def test_costs_per_capita_i235; assert_in_epsilon(5.085606184680977, worksheet.costs_per_capita_i235, 0.002); end
  def test_costs_per_capita_j235; assert_in_delta(0.0, (worksheet.costs_per_capita_j235||0), 0.002); end
  def test_costs_per_capita_k235; assert_in_delta(0.0, (worksheet.costs_per_capita_k235||0), 0.002); end
  def test_costs_per_capita_l235; assert_in_epsilon(7.943194340933128, worksheet.costs_per_capita_l235, 0.002); end
  def test_costs_per_capita_m235; assert_in_epsilon(7.943194340933128, worksheet.costs_per_capita_m235, 0.002); end
  def test_costs_per_capita_e236; assert_equal("Commercial lighting, appliances, and catering", worksheet.costs_per_capita_e236); end
  def test_costs_per_capita_f236; assert_in_epsilon(2.506569147762295, worksheet.costs_per_capita_f236, 0.002); end
  def test_costs_per_capita_g236; assert_in_epsilon(3.3838683494790986, worksheet.costs_per_capita_g236, 0.002); end
  def test_costs_per_capita_h236; assert_in_epsilon(5.01313829552459, worksheet.costs_per_capita_h236, 0.002); end
  def test_costs_per_capita_i236; assert_in_epsilon(2.506569147762295, worksheet.costs_per_capita_i236, 0.002); end
  def test_costs_per_capita_j236; assert_in_delta(0.0, (worksheet.costs_per_capita_j236||0), 0.002); end
  def test_costs_per_capita_k236; assert_in_delta(0.0, (worksheet.costs_per_capita_k236||0), 0.002); end
  def test_costs_per_capita_l236; assert_in_epsilon(3.3194985818579634, worksheet.costs_per_capita_l236, 0.002); end
  def test_costs_per_capita_m236; assert_in_epsilon(3.3194985818579634, worksheet.costs_per_capita_m236, 0.002); end
  def test_costs_per_capita_e237; assert_equal("Industrial processes", worksheet.costs_per_capita_e237); end
  def test_costs_per_capita_f237; assert_in_epsilon(48.08879802285441, worksheet.costs_per_capita_f237, 0.002); end
  def test_costs_per_capita_g237; assert_in_epsilon(2836.4376033813624, worksheet.costs_per_capita_g237, 0.002); end
  def test_costs_per_capita_h237; assert_in_epsilon(8014.799670475735, worksheet.costs_per_capita_h237, 0.002); end
  def test_costs_per_capita_i237; assert_in_epsilon(7966.710872452881, worksheet.costs_per_capita_i237, 0.002); end
  def test_costs_per_capita_j237; assert_in_delta(0.0, (worksheet.costs_per_capita_j237||0), 0.002); end
  def test_costs_per_capita_k237; assert_in_delta(0.0, (worksheet.costs_per_capita_k237||0), 0.002); end
  def test_costs_per_capita_l237; assert_in_epsilon(43.68395158099546, worksheet.costs_per_capita_l237, 0.002); end
  def test_costs_per_capita_m237; assert_in_epsilon(43.68395158099546, worksheet.costs_per_capita_m237, 0.002); end
  def test_costs_per_capita_e238; assert_equal("Conventional cars and buses", worksheet.costs_per_capita_e238); end
  def test_costs_per_capita_f238; assert_in_epsilon(10301.535523411478, worksheet.costs_per_capita_f238, 0.002); end
  def test_costs_per_capita_g238; assert_in_epsilon(15060.7684510218, worksheet.costs_per_capita_g238, 0.002); end
  def test_costs_per_capita_h238; assert_in_epsilon(15955.195889859848, worksheet.costs_per_capita_h238, 0.002); end
  def test_costs_per_capita_i238; assert_in_epsilon(5653.66036644837, worksheet.costs_per_capita_i238, 0.002); end
  def test_costs_per_capita_j238; assert_in_delta(0.0, (worksheet.costs_per_capita_j238||0), 0.002); end
  def test_costs_per_capita_k238; assert_in_delta(-0.2834367595392767, worksheet.costs_per_capita_k238, 0.002); end
  def test_costs_per_capita_l238; assert_in_epsilon(3404.0564092216187, worksheet.costs_per_capita_l238, 0.002); end
  def test_costs_per_capita_m238; assert_in_epsilon(3404.0564092216187, worksheet.costs_per_capita_m238, 0.002); end
  def test_costs_per_capita_e239; assert_equal("Hybrid cars and buses", worksheet.costs_per_capita_e239); end
  def test_costs_per_capita_f239; assert_in_epsilon(3937.303325522321, worksheet.costs_per_capita_f239, 0.002); end
  def test_costs_per_capita_g239; assert_in_epsilon(6251.587567744361, worksheet.costs_per_capita_g239, 0.002); end
  def test_costs_per_capita_h239; assert_in_epsilon(7180.296400293673, worksheet.costs_per_capita_h239, 0.002); end
  def test_costs_per_capita_i239; assert_in_epsilon(3242.9930747713524, worksheet.costs_per_capita_i239, 0.002); end
  def test_costs_per_capita_j239; assert_in_delta(0.0, (worksheet.costs_per_capita_j239||0), 0.002); end
  def test_costs_per_capita_k239; assert_in_epsilon(-2.3284949192923023, worksheet.costs_per_capita_k239, 0.002); end
  def test_costs_per_capita_l239; assert_in_epsilon(1852.9158336279304, worksheet.costs_per_capita_l239, 0.002); end
  def test_costs_per_capita_m239; assert_in_epsilon(1852.9158336279304, worksheet.costs_per_capita_m239, 0.002); end
  def test_costs_per_capita_e240; assert_equal("Electric cars and buses", worksheet.costs_per_capita_e240); end
  def test_costs_per_capita_f240; assert_in_epsilon(1047.6858515884644, worksheet.costs_per_capita_f240, 0.002); end
  def test_costs_per_capita_g240; assert_in_epsilon(1044.1700611858635, worksheet.costs_per_capita_g240, 0.002); end
  def test_costs_per_capita_h240; assert_in_epsilon(1601.9534858512116, worksheet.costs_per_capita_h240, 0.002); end
  def test_costs_per_capita_i240; assert_in_epsilon(554.2676342627472, worksheet.costs_per_capita_i240, 0.002); end
  def test_costs_per_capita_j240; assert_in_delta(0.0, (worksheet.costs_per_capita_j240||0), 0.002); end
  def test_costs_per_capita_k240; assert_in_delta(0.0, (worksheet.costs_per_capita_k240||0), 0.002); end
  def test_costs_per_capita_l240; assert_in_epsilon(428.03501495813873, worksheet.costs_per_capita_l240, 0.002); end
  def test_costs_per_capita_m240; assert_in_epsilon(428.03501495813873, worksheet.costs_per_capita_m240, 0.002); end
  def test_costs_per_capita_e241; assert_equal("Fuel cell cars and buses", worksheet.costs_per_capita_e241); end
  def test_costs_per_capita_f241; assert_in_epsilon(4716.486895600389, worksheet.costs_per_capita_f241, 0.002); end
  def test_costs_per_capita_g241; assert_in_epsilon(6202.562283337395, worksheet.costs_per_capita_g241, 0.002); end
  def test_costs_per_capita_h241; assert_in_epsilon(10496.537491697904, worksheet.costs_per_capita_h241, 0.002); end
  def test_costs_per_capita_i241; assert_in_epsilon(5780.050596097514, worksheet.costs_per_capita_i241, 0.002); end
  def test_costs_per_capita_j241; assert_in_delta(0.0, (worksheet.costs_per_capita_j241||0), 0.002); end
  def test_costs_per_capita_k241; assert_in_delta(-0.02712727308892395, worksheet.costs_per_capita_k241, 0.002); end
  def test_costs_per_capita_l241; assert_in_epsilon(2945.9819397779265, worksheet.costs_per_capita_l241, 0.002); end
  def test_costs_per_capita_m241; assert_in_epsilon(2945.9819397779265, worksheet.costs_per_capita_m241, 0.002); end
  def test_costs_per_capita_e242; assert_equal("Bikes", worksheet.costs_per_capita_e242); end
  def test_costs_per_capita_f242; assert_in_epsilon(1.0433503684110077, worksheet.costs_per_capita_f242, 0.002); end
  def test_costs_per_capita_g242; assert_in_epsilon(1.3316222741672776, worksheet.costs_per_capita_g242, 0.002); end
  def test_costs_per_capita_h242; assert_in_epsilon(2.224438944700919, worksheet.costs_per_capita_h242, 0.002); end
  def test_costs_per_capita_i242; assert_in_epsilon(1.1810885762899113, worksheet.costs_per_capita_i242, 0.002); end
  def test_costs_per_capita_j242; assert_in_delta(0.0, (worksheet.costs_per_capita_j242||0), 0.002); end
  def test_costs_per_capita_k242; assert_in_epsilon(-706.0698919906828, worksheet.costs_per_capita_k242, 0.002); end
  def test_costs_per_capita_l242; assert_in_delta(0.44108693925698284, worksheet.costs_per_capita_l242, 0.002); end
  def test_costs_per_capita_m242; assert_in_delta(0.44108693925698284, worksheet.costs_per_capita_m242, 0.002); end
  def test_costs_per_capita_e243; assert_equal("Rail", worksheet.costs_per_capita_e243); end
  def test_costs_per_capita_f243; assert_in_epsilon(15606.652175567187, worksheet.costs_per_capita_f243, 0.002); end
  def test_costs_per_capita_g243; assert_in_epsilon(17135.41032043416, worksheet.costs_per_capita_g243, 0.002); end
  def test_costs_per_capita_h243; assert_in_epsilon(19974.532005284404, worksheet.costs_per_capita_h243, 0.002); end
  def test_costs_per_capita_i243; assert_in_epsilon(4367.879829717216, worksheet.costs_per_capita_i243, 0.002); end
  def test_costs_per_capita_j243; assert_in_delta(0.0, (worksheet.costs_per_capita_j243||0), 0.002); end
  def test_costs_per_capita_k243; assert_in_epsilon(-536.692418831632, worksheet.costs_per_capita_k243, 0.002); end
  def test_costs_per_capita_l243; assert_in_epsilon(168.13577876850024, worksheet.costs_per_capita_l243, 0.002); end
  def test_costs_per_capita_m243; assert_in_epsilon(168.13577876850024, worksheet.costs_per_capita_m243, 0.002); end
  def test_costs_per_capita_e244; assert_equal("Domestic aviation", worksheet.costs_per_capita_e244); end
  def test_costs_per_capita_f244; assert_in_epsilon(34972.70359513044, worksheet.costs_per_capita_f244, 0.002); end
  def test_costs_per_capita_g244; assert_in_epsilon(37994.92466462295, worksheet.costs_per_capita_g244, 0.002); end
  def test_costs_per_capita_h244; assert_in_epsilon(43607.62093653761, worksheet.costs_per_capita_h244, 0.002); end
  def test_costs_per_capita_i244; assert_in_epsilon(8634.91734140717, worksheet.costs_per_capita_i244, 0.002); end
  def test_costs_per_capita_j244; assert_in_delta(0.0, (worksheet.costs_per_capita_j244||0), 0.002); end
  def test_costs_per_capita_k244; assert_in_epsilon(-121.30486008388205, worksheet.costs_per_capita_k244, 0.002); end
  def test_costs_per_capita_l244; assert_in_epsilon(21805.53627842528, worksheet.costs_per_capita_l244, 0.002); end
  def test_costs_per_capita_m244; assert_in_epsilon(21805.53627842528, worksheet.costs_per_capita_m244, 0.002); end
  def test_costs_per_capita_e245; assert_equal("Domestic freight", worksheet.costs_per_capita_e245); end
  def test_costs_per_capita_f245; assert_in_epsilon(15.573648550686679, worksheet.costs_per_capita_f245, 0.002); end
  def test_costs_per_capita_g245; assert_in_epsilon(16.033347733739813, worksheet.costs_per_capita_g245, 0.002); end
  def test_costs_per_capita_h245; assert_in_epsilon(16.46417652504071, worksheet.costs_per_capita_h245, 0.002); end
  def test_costs_per_capita_i245; assert_in_delta(0.8905279743540309, worksheet.costs_per_capita_i245, 0.002); end
  def test_costs_per_capita_j245; assert_in_delta(0.0, (worksheet.costs_per_capita_j245||0), 0.002); end
  def test_costs_per_capita_k245; assert_in_epsilon(-495.0536442576243, worksheet.costs_per_capita_k245, 0.002); end
  def test_costs_per_capita_l245; assert_in_epsilon(5.675751184066261, worksheet.costs_per_capita_l245, 0.002); end
  def test_costs_per_capita_m245; assert_in_epsilon(5.675751184066261, worksheet.costs_per_capita_m245, 0.002); end
  def test_costs_per_capita_e246; assert_equal("International aviation", worksheet.costs_per_capita_e246); end
  def test_costs_per_capita_f246; assert_in_delta(0.0, (worksheet.costs_per_capita_f246||0), 0.002); end
  def test_costs_per_capita_g246; assert_in_delta(0.0, (worksheet.costs_per_capita_g246||0), 0.002); end
  def test_costs_per_capita_h246; assert_in_delta(0.0, (worksheet.costs_per_capita_h246||0), 0.002); end
  def test_costs_per_capita_i246; assert_in_delta(0.0, (worksheet.costs_per_capita_i246||0), 0.002); end
  def test_costs_per_capita_j246; assert_in_delta(0.0, (worksheet.costs_per_capita_j246||0), 0.002); end
  def test_costs_per_capita_k246; assert_in_delta(0.0, (worksheet.costs_per_capita_k246||0), 0.002); end
  def test_costs_per_capita_l246; assert_in_delta(0.0, (worksheet.costs_per_capita_l246||0), 0.002); end
  def test_costs_per_capita_m246; assert_in_delta(0.0, (worksheet.costs_per_capita_m246||0), 0.002); end
  def test_costs_per_capita_e247; assert_equal("International shipping (maritime bunkers)", worksheet.costs_per_capita_e247); end
  def test_costs_per_capita_f247; assert_in_delta(0.0, (worksheet.costs_per_capita_f247||0), 0.002); end
  def test_costs_per_capita_g247; assert_in_delta(0.0, (worksheet.costs_per_capita_g247||0), 0.002); end
  def test_costs_per_capita_h247; assert_in_delta(0.0, (worksheet.costs_per_capita_h247||0), 0.002); end
  def test_costs_per_capita_i247; assert_in_delta(0.0, (worksheet.costs_per_capita_i247||0), 0.002); end
  def test_costs_per_capita_j247; assert_in_delta(0.0, (worksheet.costs_per_capita_j247||0), 0.002); end
  def test_costs_per_capita_k247; assert_in_epsilon(-80.9100951881969, worksheet.costs_per_capita_k247, 0.002); end
  def test_costs_per_capita_l247; assert_in_delta(0.0, (worksheet.costs_per_capita_l247||0), 0.002); end
  def test_costs_per_capita_m247; assert_in_delta(0.0, (worksheet.costs_per_capita_m247||0), 0.002); end
  def test_costs_per_capita_e248; assert_equal("Geosequestration", worksheet.costs_per_capita_e248); end
  def test_costs_per_capita_f248; assert_in_delta(0.0, (worksheet.costs_per_capita_f248||0), 0.002); end
  def test_costs_per_capita_g248; assert_in_delta(0.0, (worksheet.costs_per_capita_g248||0), 0.002); end
  def test_costs_per_capita_h248; assert_in_delta(0.0, (worksheet.costs_per_capita_h248||0), 0.002); end
  def test_costs_per_capita_i248; assert_in_delta(0.0, (worksheet.costs_per_capita_i248||0), 0.002); end
  def test_costs_per_capita_j248; assert_in_delta(0.0, (worksheet.costs_per_capita_j248||0), 0.002); end
  def test_costs_per_capita_k248; assert_in_epsilon(-6316.334128946345, worksheet.costs_per_capita_k248, 0.002); end
  def test_costs_per_capita_l248; assert_in_delta(0.0, (worksheet.costs_per_capita_l248||0), 0.002); end
  def test_costs_per_capita_m248; assert_in_delta(0.0, (worksheet.costs_per_capita_m248||0), 0.002); end
  def test_costs_per_capita_e249; assert_equal("Petroleum refineries", worksheet.costs_per_capita_e249); end
  def test_costs_per_capita_f249; assert_in_epsilon(4.130440214782777, worksheet.costs_per_capita_f249, 0.002); end
  def test_costs_per_capita_g249; assert_in_epsilon(4.694040556386749, worksheet.costs_per_capita_g249, 0.002); end
  def test_costs_per_capita_h249; assert_in_epsilon(5.740726905079838, worksheet.costs_per_capita_h249, 0.002); end
  def test_costs_per_capita_i249; assert_in_epsilon(1.6102866902970616, worksheet.costs_per_capita_i249, 0.002); end
  def test_costs_per_capita_j249; assert_in_delta(0.0, (worksheet.costs_per_capita_j249||0), 0.002); end
  def test_costs_per_capita_k249; assert_in_delta(-0.755324310441972, worksheet.costs_per_capita_k249, 0.002); end
  def test_costs_per_capita_l249; assert_in_epsilon(1.266400575939708, worksheet.costs_per_capita_l249, 0.002); end
  def test_costs_per_capita_m249; assert_in_epsilon(1.266400575939708, worksheet.costs_per_capita_m249, 0.002); end
  def test_costs_per_capita_e250; assert_equal("Fossil fuel transfers", worksheet.costs_per_capita_e250); end
  def test_costs_per_capita_f250; assert_in_epsilon(1.8802162622896692, worksheet.costs_per_capita_f250, 0.002); end
  def test_costs_per_capita_g250; assert_in_epsilon(2.331412172238761, worksheet.costs_per_capita_g250, 0.002); end
  def test_costs_per_capita_h250; assert_in_epsilon(3.1650020524849065, worksheet.costs_per_capita_h250, 0.002); end
  def test_costs_per_capita_i250; assert_in_epsilon(1.2847857901952373, worksheet.costs_per_capita_i250, 0.002); end
  def test_costs_per_capita_j250; assert_in_delta(0.0, (worksheet.costs_per_capita_j250||0), 0.002); end
  def test_costs_per_capita_k250; assert_in_delta(-0.16106660771356324, worksheet.costs_per_capita_k250, 0.002); end
  def test_costs_per_capita_l250; assert_in_epsilon(1.8195196347230553, worksheet.costs_per_capita_l250, 0.002); end
  def test_costs_per_capita_m250; assert_in_epsilon(1.8195196347230553, worksheet.costs_per_capita_m250, 0.002); end
  def test_costs_per_capita_e251; assert_equal("District heating effective demand", worksheet.costs_per_capita_e251); end
  def test_costs_per_capita_f251; assert_in_delta(0.0, (worksheet.costs_per_capita_f251||0), 0.002); end
  def test_costs_per_capita_g251; assert_in_delta(0.0, (worksheet.costs_per_capita_g251||0), 0.002); end
  def test_costs_per_capita_h251; assert_in_delta(0.0, (worksheet.costs_per_capita_h251||0), 0.002); end
  def test_costs_per_capita_i251; assert_in_delta(0.0, (worksheet.costs_per_capita_i251||0), 0.002); end
  def test_costs_per_capita_j251; assert_in_delta(0.0, (worksheet.costs_per_capita_j251||0), 0.002); end
  def test_costs_per_capita_k251; assert_in_delta(-0.31113205837669833, worksheet.costs_per_capita_k251, 0.002); end
  def test_costs_per_capita_l251; assert_in_delta(0.0, (worksheet.costs_per_capita_l251||0), 0.002); end
  def test_costs_per_capita_m251; assert_in_delta(0.0, (worksheet.costs_per_capita_m251||0), 0.002); end
  def test_costs_per_capita_e252; assert_equal("Storage of captured CO2", worksheet.costs_per_capita_e252); end
  def test_costs_per_capita_f252; assert_in_delta(0.0, (worksheet.costs_per_capita_f252||0), 0.002); end
  def test_costs_per_capita_g252; assert_in_delta(0.0, (worksheet.costs_per_capita_g252||0), 0.002); end
  def test_costs_per_capita_h252; assert_in_delta(0.0, (worksheet.costs_per_capita_h252||0), 0.002); end
  def test_costs_per_capita_i252; assert_in_delta(0.0, (worksheet.costs_per_capita_i252||0), 0.002); end
  def test_costs_per_capita_j252; assert_in_delta(0.0, (worksheet.costs_per_capita_j252||0), 0.002); end
  def test_costs_per_capita_k252; assert_in_delta(0.0, (worksheet.costs_per_capita_k252||0), 0.002); end
  def test_costs_per_capita_l252; assert_in_delta(0.0, (worksheet.costs_per_capita_l252||0), 0.002); end
  def test_costs_per_capita_m252; assert_in_delta(0.0, (worksheet.costs_per_capita_m252||0), 0.002); end
  def test_costs_per_capita_e253; assert_equal("Coal", worksheet.costs_per_capita_e253); end
  def test_costs_per_capita_f253; assert_in_delta(-0.3527305030725074, worksheet.costs_per_capita_f253, 0.002); end
  def test_costs_per_capita_g253; assert_in_delta(-0.4489866654738073, worksheet.costs_per_capita_g253, 0.002); end
  def test_costs_per_capita_h253; assert_in_delta(-0.5933709090757517, worksheet.costs_per_capita_h253, 0.002); end
  def test_costs_per_capita_i253; assert_in_delta(-0.24064040600324432, worksheet.costs_per_capita_i253, 0.002); end
  def test_costs_per_capita_j253; assert_in_delta(0.0, (worksheet.costs_per_capita_j253||0), 0.002); end
  def test_costs_per_capita_k253; assert_in_delta(0.0, (worksheet.costs_per_capita_k253||0), 0.002); end
  def test_costs_per_capita_l253; assert_in_delta(0.0, (worksheet.costs_per_capita_l253||0), 0.002); end
  def test_costs_per_capita_m253; assert_in_delta(0.0, (worksheet.costs_per_capita_m253||0), 0.002); end
  def test_costs_per_capita_e254; assert_equal("Oil", worksheet.costs_per_capita_e254); end
  def test_costs_per_capita_f254; assert_in_epsilon(286.7703642076727, worksheet.costs_per_capita_f254, 0.002); end
  def test_costs_per_capita_g254; assert_in_epsilon(365.88417455105696, worksheet.costs_per_capita_g254, 0.002); end
  def test_costs_per_capita_h254; assert_in_epsilon(463.316556430852, worksheet.costs_per_capita_h254, 0.002); end
  def test_costs_per_capita_i254; assert_in_epsilon(176.54619222317933, worksheet.costs_per_capita_i254, 0.002); end
  def test_costs_per_capita_j254; assert_in_delta(0.0, (worksheet.costs_per_capita_j254||0), 0.002); end
  def test_costs_per_capita_k254; assert_in_delta(0.0, (worksheet.costs_per_capita_k254||0), 0.002); end
  def test_costs_per_capita_l254; assert_in_delta(0.0, (worksheet.costs_per_capita_l254||0), 0.002); end
  def test_costs_per_capita_m254; assert_in_delta(0.0, (worksheet.costs_per_capita_m254||0), 0.002); end
  def test_costs_per_capita_e255; assert_equal("Gas", worksheet.costs_per_capita_e255); end
  def test_costs_per_capita_f255; assert_in_epsilon(21.77908668953227, worksheet.costs_per_capita_f255, 0.002); end
  def test_costs_per_capita_g255; assert_in_epsilon(28.882781649313046, worksheet.costs_per_capita_g255, 0.002); end
  def test_costs_per_capita_h255; assert_in_epsilon(37.40721560105, worksheet.costs_per_capita_h255, 0.002); end
  def test_costs_per_capita_i255; assert_in_epsilon(15.628128911517727, worksheet.costs_per_capita_i255, 0.002); end
  def test_costs_per_capita_j255; assert_in_delta(0.0, (worksheet.costs_per_capita_j255||0), 0.002); end
  def test_costs_per_capita_k255; assert_in_delta(0.0, (worksheet.costs_per_capita_k255||0), 0.002); end
  def test_costs_per_capita_l255; assert_in_delta(0.0, (worksheet.costs_per_capita_l255||0), 0.002); end
  def test_costs_per_capita_m255; assert_in_delta(0.0, (worksheet.costs_per_capita_m255||0), 0.002); end
  def test_costs_per_capita_e256; assert_equal("Finance cost", worksheet.costs_per_capita_e256); end
  def test_costs_per_capita_f256; assert_in_delta(0.0, (worksheet.costs_per_capita_f256||0), 0.002); end
  def test_costs_per_capita_g256; assert_in_epsilon(13526.404451176715, worksheet.costs_per_capita_g256, 0.002); end
  def test_costs_per_capita_h256; assert_in_epsilon(30740.977797781306, worksheet.costs_per_capita_h256, 0.002); end
  def test_costs_per_capita_i256; assert_in_epsilon(30740.977797781306, worksheet.costs_per_capita_i256, 0.002); end
  def test_costs_per_capita_j256; assert_in_delta(0.0, (worksheet.costs_per_capita_j256||0), 0.002); end
  def test_costs_per_capita_k256; assert_in_delta(0.0, (worksheet.costs_per_capita_k256||0), 0.002); end
  def test_costs_per_capita_l256; assert_in_delta(0.0, (worksheet.costs_per_capita_l256||0), 0.002); end
  def test_costs_per_capita_m256; assert_in_delta(0.0, (worksheet.costs_per_capita_m256||0), 0.002); end
  def test_electricity_d63; assert_equal("Sector", worksheet.electricity_d63); end
  def test_electricity_e63; assert_in_epsilon(2010.0, worksheet.electricity_e63, 0.002); end
  def test_electricity_f63; assert_in_epsilon(2015.0, worksheet.electricity_f63, 0.002); end
  def test_electricity_g63; assert_in_epsilon(2020.0, worksheet.electricity_g63, 0.002); end
  def test_electricity_h63; assert_in_epsilon(2025.0, worksheet.electricity_h63, 0.002); end
  def test_electricity_i63; assert_in_epsilon(2030.0, worksheet.electricity_i63, 0.002); end
  def test_electricity_j63; assert_in_epsilon(2035.0, worksheet.electricity_j63, 0.002); end
  def test_electricity_k63; assert_in_epsilon(2040.0, worksheet.electricity_k63, 0.002); end
  def test_electricity_l63; assert_in_epsilon(2045.0, worksheet.electricity_l63, 0.002); end
  def test_electricity_m63; assert_in_epsilon(2050.0, worksheet.electricity_m63, 0.002); end
  def test_electricity_d64; assert_equal("Natural gas power stations", worksheet.electricity_d64); end
  def test_electricity_e64; assert_in_epsilon(3.0, worksheet.electricity_e64, 0.002); end
  def test_electricity_f64; assert_in_epsilon(3.44, worksheet.electricity_f64, 0.002); end
  def test_electricity_g64; assert_in_epsilon(3.88, worksheet.electricity_g64, 0.002); end
  def test_electricity_h64; assert_in_epsilon(4.31, worksheet.electricity_h64, 0.002); end
  def test_electricity_i64; assert_in_epsilon(4.75, worksheet.electricity_i64, 0.002); end
  def test_electricity_j64; assert_in_epsilon(5.19, worksheet.electricity_j64, 0.002); end
  def test_electricity_k64; assert_in_epsilon(5.63, worksheet.electricity_k64, 0.002); end
  def test_electricity_l64; assert_in_epsilon(6.05, worksheet.electricity_l64, 0.002); end
  def test_electricity_m64; assert_in_epsilon(6.5, worksheet.electricity_m64, 0.002); end
  def test_electricity_d65; assert_equal("Biomass power station", worksheet.electricity_d65); end
  def test_electricity_e65; assert_in_delta(0.0, (worksheet.electricity_e65||0), 0.002); end
  def test_electricity_f65; assert_in_delta(0.0, (worksheet.electricity_f65||0), 0.002); end
  def test_electricity_g65; assert_in_delta(0.005, worksheet.electricity_g65, 0.002); end
  def test_electricity_h65; assert_in_delta(0.005, worksheet.electricity_h65, 0.002); end
  def test_electricity_i65; assert_in_delta(0.005, worksheet.electricity_i65, 0.002); end
  def test_electricity_j65; assert_in_delta(0.005, worksheet.electricity_j65, 0.002); end
  def test_electricity_k65; assert_in_delta(0.005, worksheet.electricity_k65, 0.002); end
  def test_electricity_l65; assert_in_delta(0.005, worksheet.electricity_l65, 0.002); end
  def test_electricity_m65; assert_in_delta(0.005, worksheet.electricity_m65, 0.002); end
  def test_electricity_d66; assert_equal("Coal power stations", worksheet.electricity_d66); end
  def test_electricity_e66; assert_in_delta(0.0, (worksheet.electricity_e66||0), 0.002); end
  def test_electricity_f66; assert_in_delta(0.0, (worksheet.electricity_f66||0), 0.002); end
  def test_electricity_g66; assert_in_delta(0.0, (worksheet.electricity_g66||0), 0.002); end
  def test_electricity_h66; assert_in_epsilon(1.4, worksheet.electricity_h66, 0.002); end
  def test_electricity_i66; assert_in_epsilon(1.4, worksheet.electricity_i66, 0.002); end
  def test_electricity_j66; assert_in_epsilon(1.4, worksheet.electricity_j66, 0.002); end
  def test_electricity_k66; assert_in_epsilon(1.4, worksheet.electricity_k66, 0.002); end
  def test_electricity_l66; assert_in_epsilon(1.4, worksheet.electricity_l66, 0.002); end
  def test_electricity_m66; assert_in_epsilon(1.4, worksheet.electricity_m66, 0.002); end
  def test_electricity_d67; assert_equal("Self Generation ", worksheet.electricity_d67); end
  def test_electricity_e67; assert_in_epsilon(26.42279885102571, worksheet.electricity_e67, 0.002); end
  def test_electricity_f67; assert_in_epsilon(31.12469483366499, worksheet.electricity_f67, 0.002); end
  def test_electricity_g67; assert_in_epsilon(41.903011579354704, worksheet.electricity_g67, 0.002); end
  def test_electricity_h67; assert_in_epsilon(59.92529338337988, worksheet.electricity_h67, 0.002); end
  def test_electricity_i67; assert_in_epsilon(80.49534823382962, worksheet.electricity_i67, 0.002); end
  def test_electricity_j67; assert_in_epsilon(101.38680317207442, worksheet.electricity_j67, 0.002); end
  def test_electricity_k67; assert_in_epsilon(125.76610266515979, worksheet.electricity_k67, 0.002); end
  def test_electricity_l67; assert_in_epsilon(147.3680146743518, worksheet.electricity_l67, 0.002); end
  def test_electricity_m67; assert_in_epsilon(173.5570104807672, worksheet.electricity_m67, 0.002); end
  def test_electricity_d68; assert_equal("Nuclear power", worksheet.electricity_d68); end
  def test_electricity_e68; assert_in_delta(0.0, (worksheet.electricity_e68||0), 0.002); end
  def test_electricity_f68; assert_in_delta(0.0, (worksheet.electricity_f68||0), 0.002); end
  def test_electricity_g68; assert_in_delta(0.0, (worksheet.electricity_g68||0), 0.002); end
  def test_electricity_h68; assert_in_delta(0.0, (worksheet.electricity_h68||0), 0.002); end
  def test_electricity_i68; assert_in_delta(0.0, (worksheet.electricity_i68||0), 0.002); end
  def test_electricity_j68; assert_in_delta(0.0, (worksheet.electricity_j68||0), 0.002); end
  def test_electricity_k68; assert_in_delta(0.0, (worksheet.electricity_k68||0), 0.002); end
  def test_electricity_l68; assert_in_delta(0.0, (worksheet.electricity_l68||0), 0.002); end
  def test_electricity_m68; assert_in_delta(0.0, (worksheet.electricity_m68||0), 0.002); end
  def test_electricity_d69; assert_equal("Wind ", worksheet.electricity_d69); end
  def test_electricity_e69; assert_in_delta(0.0, (worksheet.electricity_e69||0), 0.002); end
  def test_electricity_f69; assert_in_delta(0.0, (worksheet.electricity_f69||0), 0.002); end
  def test_electricity_g69; assert_in_delta(0.01, worksheet.electricity_g69, 0.002); end
  def test_electricity_h69; assert_in_delta(0.01, worksheet.electricity_h69, 0.002); end
  def test_electricity_i69; assert_in_delta(0.01, worksheet.electricity_i69, 0.002); end
  def test_electricity_j69; assert_in_delta(0.01, worksheet.electricity_j69, 0.002); end
  def test_electricity_k69; assert_in_delta(0.01, worksheet.electricity_k69, 0.002); end
  def test_electricity_l69; assert_in_delta(0.01, worksheet.electricity_l69, 0.002); end
  def test_electricity_m69; assert_in_delta(0.01, worksheet.electricity_m69, 0.002); end
  def test_electricity_d70; assert_equal("Hydroelectric power stations", worksheet.electricity_d70); end
  def test_electricity_e70; assert_in_epsilon(1.9, worksheet.electricity_e70, 0.002); end
  def test_electricity_f70; assert_in_epsilon(1.9, worksheet.electricity_f70, 0.002); end
  def test_electricity_g70; assert_in_epsilon(1.9, worksheet.electricity_g70, 0.002); end
  def test_electricity_h70; assert_in_epsilon(1.9, worksheet.electricity_h70, 0.002); end
  def test_electricity_i70; assert_in_epsilon(1.9, worksheet.electricity_i70, 0.002); end
  def test_electricity_j70; assert_in_epsilon(1.9, worksheet.electricity_j70, 0.002); end
  def test_electricity_k70; assert_in_epsilon(1.9, worksheet.electricity_k70, 0.002); end
  def test_electricity_l70; assert_in_epsilon(1.9, worksheet.electricity_l70, 0.002); end
  def test_electricity_m70; assert_in_epsilon(1.9, worksheet.electricity_m70, 0.002); end
  def test_electricity_d71; assert_equal("Small Hydroelectric power stations", worksheet.electricity_d71); end
  def test_electricity_e71; assert_in_delta(0.064, worksheet.electricity_e71, 0.002); end
  def test_electricity_f71; assert_in_delta(0.064, worksheet.electricity_f71, 0.002); end
  def test_electricity_g71; assert_in_delta(0.064, worksheet.electricity_g71, 0.002); end
  def test_electricity_h71; assert_in_delta(0.064, worksheet.electricity_h71, 0.002); end
  def test_electricity_i71; assert_in_delta(0.064, worksheet.electricity_i71, 0.002); end
  def test_electricity_j71; assert_in_delta(0.064, worksheet.electricity_j71, 0.002); end
  def test_electricity_k71; assert_in_delta(0.064, worksheet.electricity_k71, 0.002); end
  def test_electricity_l71; assert_in_delta(0.064, worksheet.electricity_l71, 0.002); end
  def test_electricity_m71; assert_in_delta(0.064, worksheet.electricity_m71, 0.002); end
  def test_electricity_d72; assert_equal("Grid Connected Solar PV", worksheet.electricity_d72); end
  def test_electricity_e72; assert_in_delta(0.0, (worksheet.electricity_e72||0), 0.002); end
  def test_electricity_f72; assert_in_delta(0.0, (worksheet.electricity_f72||0), 0.002); end
  def test_electricity_g72; assert_in_delta(0.1, worksheet.electricity_g72, 0.002); end
  def test_electricity_h72; assert_in_delta(0.2, worksheet.electricity_h72, 0.002); end
  def test_electricity_i72; assert_in_delta(0.3, worksheet.electricity_i72, 0.002); end
  def test_electricity_j72; assert_in_delta(0.4, worksheet.electricity_j72, 0.002); end
  def test_electricity_k72; assert_in_delta(0.5, worksheet.electricity_k72, 0.002); end
  def test_electricity_l72; assert_in_delta(0.6, worksheet.electricity_l72, 0.002); end
  def test_electricity_m72; assert_in_delta(0.7, worksheet.electricity_m72, 0.002); end
  def test_electricity_d73; assert_equal("Concentrated Solar Power", worksheet.electricity_d73); end
  def test_electricity_e73; assert_in_delta(0.0, (worksheet.electricity_e73||0), 0.002); end
  def test_electricity_f73; assert_in_delta(0.0, (worksheet.electricity_f73||0), 0.002); end
  def test_electricity_g73; assert_in_delta(0.0, (worksheet.electricity_g73||0), 0.002); end
  def test_electricity_h73; assert_in_delta(0.0, (worksheet.electricity_h73||0), 0.002); end
  def test_electricity_i73; assert_in_delta(0.0, (worksheet.electricity_i73||0), 0.002); end
  def test_electricity_j73; assert_in_delta(0.0, (worksheet.electricity_j73||0), 0.002); end
  def test_electricity_k73; assert_in_delta(0.0, (worksheet.electricity_k73||0), 0.002); end
  def test_electricity_l73; assert_in_delta(0.0, (worksheet.electricity_l73||0), 0.002); end
  def test_electricity_m73; assert_in_delta(0.0, (worksheet.electricity_m73||0), 0.002); end
  def test_electricity_d74; assert_equal("Stand-Alone Solar PV", worksheet.electricity_d74); end
  def test_electricity_e74; assert_in_delta(0.015, worksheet.electricity_e74, 0.002); end
  def test_electricity_f74; assert_in_delta(0.5, worksheet.electricity_f74, 0.002); end
  def test_electricity_g74; assert_in_delta(1.0, worksheet.electricity_g74, 0.002); end
  def test_electricity_h74; assert_in_epsilon(1.5, worksheet.electricity_h74, 0.002); end
  def test_electricity_i74; assert_in_epsilon(2.0, worksheet.electricity_i74, 0.002); end
  def test_electricity_j74; assert_in_epsilon(2.5, worksheet.electricity_j74, 0.002); end
  def test_electricity_k74; assert_in_epsilon(3.0, worksheet.electricity_k74, 0.002); end
  def test_electricity_l74; assert_in_epsilon(3.5, worksheet.electricity_l74, 0.002); end
  def test_electricity_m74; assert_in_epsilon(4.0, worksheet.electricity_m74, 0.002); end
  def test_electricity_d75; assert_equal("Types of fuel from Biomass", worksheet.electricity_d75); end
  def test_electricity_e75; assert_in_delta(0.0, (worksheet.electricity_e75||0), 0.002); end
  def test_electricity_f75; assert_in_delta(0.0, (worksheet.electricity_f75||0), 0.002); end
  def test_electricity_g75; assert_in_delta(0.0, (worksheet.electricity_g75||0), 0.002); end
  def test_electricity_h75; assert_in_delta(0.0, (worksheet.electricity_h75||0), 0.002); end
  def test_electricity_i75; assert_in_delta(0.0, (worksheet.electricity_i75||0), 0.002); end
  def test_electricity_j75; assert_in_delta(0.0, (worksheet.electricity_j75||0), 0.002); end
  def test_electricity_k75; assert_in_delta(0.0, (worksheet.electricity_k75||0), 0.002); end
  def test_electricity_l75; assert_in_delta(0.0, (worksheet.electricity_l75||0), 0.002); end
  def test_electricity_m75; assert_in_delta(0.0, (worksheet.electricity_m75||0), 0.002); end
  def test_electricity_d76; assert_equal("Bioenergy imports", worksheet.electricity_d76); end
  def test_electricity_e76; assert_in_delta(0.0, (worksheet.electricity_e76||0), 0.002); end
  def test_electricity_f76; assert_in_delta(0.0, (worksheet.electricity_f76||0), 0.002); end
  def test_electricity_g76; assert_in_delta(0.0, (worksheet.electricity_g76||0), 0.002); end
  def test_electricity_h76; assert_in_delta(0.0, (worksheet.electricity_h76||0), 0.002); end
  def test_electricity_i76; assert_in_delta(0.0, (worksheet.electricity_i76||0), 0.002); end
  def test_electricity_j76; assert_in_delta(0.0, (worksheet.electricity_j76||0), 0.002); end
  def test_electricity_k76; assert_in_delta(0.0, (worksheet.electricity_k76||0), 0.002); end
  def test_electricity_l76; assert_in_delta(0.0, (worksheet.electricity_l76||0), 0.002); end
  def test_electricity_m76; assert_in_delta(0.0, (worksheet.electricity_m76||0), 0.002); end
  def test_electricity_d77; assert_equal("Agriculture and land use", worksheet.electricity_d77); end
  def test_electricity_e77; assert_in_delta(0.0, (worksheet.electricity_e77||0), 0.002); end
  def test_electricity_f77; assert_in_delta(0.0, (worksheet.electricity_f77||0), 0.002); end
  def test_electricity_g77; assert_in_delta(0.0, (worksheet.electricity_g77||0), 0.002); end
  def test_electricity_h77; assert_in_delta(0.0, (worksheet.electricity_h77||0), 0.002); end
  def test_electricity_i77; assert_in_delta(0.0, (worksheet.electricity_i77||0), 0.002); end
  def test_electricity_j77; assert_in_delta(0.0, (worksheet.electricity_j77||0), 0.002); end
  def test_electricity_k77; assert_in_delta(0.0, (worksheet.electricity_k77||0), 0.002); end
  def test_electricity_l77; assert_in_delta(0.0, (worksheet.electricity_l77||0), 0.002); end
  def test_electricity_m77; assert_in_delta(0.0, (worksheet.electricity_m77||0), 0.002); end
  def test_electricity_d78; assert_equal("Volume of Waste & Recycling", worksheet.electricity_d78); end
  def test_electricity_e78; assert_in_delta(0.0, (worksheet.electricity_e78||0), 0.002); end
  def test_electricity_f78; assert_in_delta(0.0, (worksheet.electricity_f78||0), 0.002); end
  def test_electricity_g78; assert_in_delta(0.0, (worksheet.electricity_g78||0), 0.002); end
  def test_electricity_h78; assert_in_delta(0.0, (worksheet.electricity_h78||0), 0.002); end
  def test_electricity_i78; assert_in_delta(0.0, (worksheet.electricity_i78||0), 0.002); end
  def test_electricity_j78; assert_in_delta(0.0, (worksheet.electricity_j78||0), 0.002); end
  def test_electricity_k78; assert_in_delta(0.0, (worksheet.electricity_k78||0), 0.002); end
  def test_electricity_l78; assert_in_delta(0.0, (worksheet.electricity_l78||0), 0.002); end
  def test_electricity_m78; assert_in_delta(0.0, (worksheet.electricity_m78||0), 0.002); end
  def test_electricity_d79; assert_equal("Electricity imports", worksheet.electricity_d79); end
  def test_electricity_e79; assert_in_delta(0.0, (worksheet.electricity_e79||0), 0.002); end
  def test_electricity_f79; assert_in_delta(0.0, (worksheet.electricity_f79||0), 0.002); end
  def test_electricity_g79; assert_in_delta(0.0, (worksheet.electricity_g79||0), 0.002); end
  def test_electricity_h79; assert_in_delta(0.0, (worksheet.electricity_h79||0), 0.002); end
  def test_electricity_i79; assert_in_delta(0.0, (worksheet.electricity_i79||0), 0.002); end
  def test_electricity_j79; assert_in_delta(0.0, (worksheet.electricity_j79||0), 0.002); end
  def test_electricity_k79; assert_in_delta(0.0, (worksheet.electricity_k79||0), 0.002); end
  def test_electricity_l79; assert_in_delta(0.0, (worksheet.electricity_l79||0), 0.002); end
  def test_electricity_m79; assert_in_delta(0.0, (worksheet.electricity_m79||0), 0.002); end
  def test_electricity_d80; assert_equal("Total generation", worksheet.electricity_d80); end
  def test_electricity_e80; assert_in_epsilon(31.40179885102571, worksheet.electricity_e80, 0.002); end
  def test_electricity_f80; assert_in_epsilon(37.028694833664986, worksheet.electricity_f80, 0.002); end
  def test_electricity_g80; assert_in_epsilon(48.8620115793547, worksheet.electricity_g80, 0.002); end
  def test_electricity_h80; assert_in_epsilon(69.31429338337989, worksheet.electricity_h80, 0.002); end
  def test_electricity_i80; assert_in_epsilon(90.92434823382962, worksheet.electricity_i80, 0.002); end
  def test_electricity_j80; assert_in_epsilon(112.85580317207443, worksheet.electricity_j80, 0.002); end
  def test_electricity_k80; assert_in_epsilon(138.27510266515978, worksheet.electricity_k80, 0.002); end
  def test_electricity_l80; assert_in_epsilon(160.8970146743518, worksheet.electricity_l80, 0.002); end
  def test_electricity_m80; assert_in_epsilon(188.13601048076717, worksheet.electricity_m80, 0.002); end
  def test_electricity_d21; assert_equal("Sector", worksheet.electricity_d21); end
  def test_electricity_e21; assert_in_epsilon(2010.0, worksheet.electricity_e21, 0.002); end
  def test_electricity_f21; assert_in_epsilon(2015.0, worksheet.electricity_f21, 0.002); end
  def test_electricity_g21; assert_in_epsilon(2020.0, worksheet.electricity_g21, 0.002); end
  def test_electricity_h21; assert_in_epsilon(2025.0, worksheet.electricity_h21, 0.002); end
  def test_electricity_i21; assert_in_epsilon(2030.0, worksheet.electricity_i21, 0.002); end
  def test_electricity_j21; assert_in_epsilon(2035.0, worksheet.electricity_j21, 0.002); end
  def test_electricity_k21; assert_in_epsilon(2040.0, worksheet.electricity_k21, 0.002); end
  def test_electricity_l21; assert_in_epsilon(2045.0, worksheet.electricity_l21, 0.002); end
  def test_electricity_m21; assert_in_epsilon(2050.0, worksheet.electricity_m21, 0.002); end
  def test_electricity_d22; assert_equal("Transport", worksheet.electricity_d22); end
  def test_electricity_e22; assert_in_epsilon(1.0449356110119832, worksheet.electricity_e22, 0.002); end
  def test_electricity_f22; assert_in_epsilon(4.033678296166547, worksheet.electricity_f22, 0.002); end
  def test_electricity_g22; assert_in_epsilon(13.868213851961716, worksheet.electricity_g22, 0.002); end
  def test_electricity_h22; assert_in_epsilon(28.11643214025897, worksheet.electricity_h22, 0.002); end
  def test_electricity_i22; assert_in_epsilon(46.860931928448146, worksheet.electricity_i22, 0.002); end
  def test_electricity_j22; assert_in_epsilon(70.53312477778746, worksheet.electricity_j22, 0.002); end
  def test_electricity_k22; assert_in_epsilon(97.63490167077863, worksheet.electricity_k22, 0.002); end
  def test_electricity_l22; assert_in_epsilon(129.49896654871404, worksheet.electricity_l22, 0.002); end
  def test_electricity_m22; assert_in_epsilon(166.4603561362769, worksheet.electricity_m22, 0.002); end
  def test_electricity_d23; assert_equal("Industry", worksheet.electricity_d23); end
  def test_electricity_e23; assert_in_epsilon(31.199245539469562, worksheet.electricity_e23, 0.002); end
  def test_electricity_f23; assert_in_epsilon(31.75480958313562, worksheet.electricity_f23, 0.002); end
  def test_electricity_g23; assert_in_epsilon(31.389950197470064, worksheet.electricity_g23, 0.002); end
  def test_electricity_h23; assert_in_epsilon(31.131839080525193, worksheet.electricity_h23, 0.002); end
  def test_electricity_i23; assert_in_epsilon(28.94068340687412, worksheet.electricity_i23, 0.002); end
  def test_electricity_j23; assert_in_epsilon(34.454313757564705, worksheet.electricity_j23, 0.002); end
  def test_electricity_k23; assert_in_epsilon(40.88271025704022, worksheet.electricity_k23, 0.002); end
  def test_electricity_l23; assert_in_epsilon(47.61134092066317, worksheet.electricity_l23, 0.002); end
  def test_electricity_m23; assert_in_epsilon(55.26565219715517, worksheet.electricity_m23, 0.002); end
  def test_electricity_d24; assert_equal("Cooling", worksheet.electricity_d24); end
  def test_electricity_e24; assert_in_epsilon(45.23241057567228, worksheet.electricity_e24, 0.002); end
  def test_electricity_f24; assert_in_epsilon(51.703504111940035, worksheet.electricity_f24, 0.002); end
  def test_electricity_g24; assert_in_epsilon(57.87457835156304, worksheet.electricity_g24, 0.002); end
  def test_electricity_h24; assert_in_epsilon(63.727201941623775, worksheet.electricity_h24, 0.002); end
  def test_electricity_i24; assert_in_epsilon(69.24053615847055, worksheet.electricity_i24, 0.002); end
  def test_electricity_j24; assert_in_epsilon(74.3911100028562, worksheet.electricity_j24, 0.002); end
  def test_electricity_k24; assert_in_epsilon(79.15257722359095, worksheet.electricity_k24, 0.002); end
  def test_electricity_l24; assert_in_epsilon(83.49545394031607, worksheet.electricity_l24, 0.002); end
  def test_electricity_m24; assert_in_epsilon(87.38683544379465, worksheet.electricity_m24, 0.002); end
  def test_electricity_d25; assert_equal("Lighting, appliances & cooking", worksheet.electricity_d25); end
  def test_electricity_e25; assert_in_epsilon(37.949814397167586, worksheet.electricity_e25, 0.002); end
  def test_electricity_f25; assert_in_epsilon(47.293501435989036, worksheet.electricity_f25, 0.002); end
  def test_electricity_g25; assert_in_epsilon(76.62923161764176, worksheet.electricity_g25, 0.002); end
  def test_electricity_h25; assert_in_epsilon(132.07754234078973, worksheet.electricity_h25, 0.002); end
  def test_electricity_i25; assert_in_epsilon(186.61835530651518, worksheet.electricity_i25, 0.002); end
  def test_electricity_j25; assert_in_epsilon(244.48581011895777, worksheet.electricity_j25, 0.002); end
  def test_electricity_k25; assert_in_epsilon(299.5726546780213, worksheet.electricity_k25, 0.002); end
  def test_electricity_l25; assert_in_epsilon(353.2931241427792, worksheet.electricity_l25, 0.002); end
  def test_electricity_m25; assert_in_epsilon(407.176925241001, worksheet.electricity_m25, 0.002); end
  def test_electricity_d26; assert_equal("Total", worksheet.electricity_d26); end
  def test_electricity_e26; assert_in_epsilon(115.42640612332141, worksheet.electricity_e26, 0.002); end
  def test_electricity_f26; assert_in_epsilon(134.78549342723124, worksheet.electricity_f26, 0.002); end
  def test_electricity_g26; assert_in_epsilon(179.76197401863658, worksheet.electricity_g26, 0.002); end
  def test_electricity_h26; assert_in_epsilon(255.05301550319768, worksheet.electricity_h26, 0.002); end
  def test_electricity_i26; assert_in_epsilon(331.660506800308, worksheet.electricity_i26, 0.002); end
  def test_electricity_j26; assert_in_epsilon(423.8643586571661, worksheet.electricity_j26, 0.002); end
  def test_electricity_k26; assert_in_epsilon(517.2428438294311, worksheet.electricity_k26, 0.002); end
  def test_electricity_l26; assert_in_epsilon(613.8988855524725, worksheet.electricity_l26, 0.002); end
  def test_electricity_m26; assert_in_epsilon(716.2897690182277, worksheet.electricity_m26, 0.002); end
  def test_electricity_d111; assert_equal("Source", worksheet.electricity_d111); end
  def test_electricity_e111; assert_in_epsilon(2010.0, worksheet.electricity_e111, 0.002); end
  def test_electricity_f111; assert_in_epsilon(2015.0, worksheet.electricity_f111, 0.002); end
  def test_electricity_g111; assert_in_epsilon(2020.0, worksheet.electricity_g111, 0.002); end
  def test_electricity_h111; assert_in_epsilon(2025.0, worksheet.electricity_h111, 0.002); end
  def test_electricity_i111; assert_in_epsilon(2030.0, worksheet.electricity_i111, 0.002); end
  def test_electricity_j111; assert_in_epsilon(2035.0, worksheet.electricity_j111, 0.002); end
  def test_electricity_k111; assert_in_epsilon(2040.0, worksheet.electricity_k111, 0.002); end
  def test_electricity_l111; assert_in_epsilon(2045.0, worksheet.electricity_l111, 0.002); end
  def test_electricity_m111; assert_in_epsilon(2050.0, worksheet.electricity_m111, 0.002); end
  def test_electricity_d112; assert_equal("Fuel combustion", worksheet.electricity_d112); end
  def test_electricity_e112; assert_in_epsilon(149.82544637164256, worksheet.electricity_e112, 0.002); end
  def test_electricity_f112; assert_in_epsilon(176.2632160347501, worksheet.electricity_f112, 0.002); end
  def test_electricity_g112; assert_in_epsilon(235.5504577440285, worksheet.electricity_g112, 0.002); end
  def test_electricity_h112; assert_in_epsilon(341.82007565998407, worksheet.electricity_h112, 0.002); end
  def test_electricity_i112; assert_in_epsilon(453.9456967479541, worksheet.electricity_i112, 0.002); end
  def test_electricity_j112; assert_in_epsilon(567.8068741282668, worksheet.electricity_j112, 0.002); end
  def test_electricity_k112; assert_in_epsilon(700.5023667242193, worksheet.electricity_k112, 0.002); end
  def test_electricity_l112; assert_in_epsilon(818.1523852014301, worksheet.electricity_l112, 0.002); end
  def test_electricity_m112; assert_in_epsilon(960.6440232645404, worksheet.electricity_m112, 0.002); end
  def test_electricity_d113; assert_equal("Bioenergy credit", worksheet.electricity_d113); end
  def test_electricity_e113; assert_in_delta(-0.7834524693673984, worksheet.electricity_e113, 0.002); end
  def test_electricity_f113; assert_in_delta(-0.8908681725838754, worksheet.electricity_f113, 0.002); end
  def test_electricity_g113; assert_in_epsilon(-1.2879242097397023, worksheet.electricity_g113, 0.002); end
  def test_electricity_h113; assert_in_epsilon(-9.499868903626385, worksheet.electricity_h113, 0.002); end
  def test_electricity_i113; assert_in_epsilon(-9.72834315533802, worksheet.electricity_i113, 0.002); end
  def test_electricity_j113; assert_in_epsilon(-9.98161905608653, worksheet.electricity_j113, 0.002); end
  def test_electricity_k113; assert_in_epsilon(-10.274004682505284, worksheet.electricity_k113, 0.002); end
  def test_electricity_l113; assert_in_epsilon(-10.606200827129298, worksheet.electricity_l113, 0.002); end
  def test_electricity_m113; assert_in_epsilon(-11.005841369980928, worksheet.electricity_m113, 0.002); end
  def test_electricity_d114; assert_equal("Total", worksheet.electricity_d114); end
  def test_electricity_e114; assert_in_epsilon(149.04199390227515, worksheet.electricity_e114, 0.002); end
  def test_electricity_f114; assert_in_epsilon(175.3723478621662, worksheet.electricity_f114, 0.002); end
  def test_electricity_g114; assert_in_epsilon(234.2625335342888, worksheet.electricity_g114, 0.002); end
  def test_electricity_h114; assert_in_epsilon(332.32020675635766, worksheet.electricity_h114, 0.002); end
  def test_electricity_i114; assert_in_epsilon(444.2173535926161, worksheet.electricity_i114, 0.002); end
  def test_electricity_j114; assert_in_epsilon(557.8252550721803, worksheet.electricity_j114, 0.002); end
  def test_electricity_k114; assert_in_epsilon(690.228362041714, worksheet.electricity_k114, 0.002); end
  def test_electricity_l114; assert_in_epsilon(807.5461843743008, worksheet.electricity_l114, 0.002); end
  def test_electricity_m114; assert_in_epsilon(949.6381818945595, worksheet.electricity_m114, 0.002); end
  def test_electricity_d41; assert_equal("Sector", worksheet.electricity_d41); end
  def test_electricity_e41; assert_in_epsilon(2010.0, worksheet.electricity_e41, 0.002); end
  def test_electricity_f41; assert_in_epsilon(2015.0, worksheet.electricity_f41, 0.002); end
  def test_electricity_g41; assert_in_epsilon(2020.0, worksheet.electricity_g41, 0.002); end
  def test_electricity_h41; assert_in_epsilon(2025.0, worksheet.electricity_h41, 0.002); end
  def test_electricity_i41; assert_in_epsilon(2030.0, worksheet.electricity_i41, 0.002); end
  def test_electricity_j41; assert_in_epsilon(2035.0, worksheet.electricity_j41, 0.002); end
  def test_electricity_k41; assert_in_epsilon(2040.0, worksheet.electricity_k41, 0.002); end
  def test_electricity_l41; assert_in_epsilon(2045.0, worksheet.electricity_l41, 0.002); end
  def test_electricity_m41; assert_in_epsilon(2050.0, worksheet.electricity_m41, 0.002); end
  def test_electricity_d42; assert_equal("Conventional", worksheet.electricity_d42); end
  def test_electricity_e42; assert_in_epsilon(129.2915942847246, worksheet.electricity_e42, 0.002); end
  def test_electricity_f42; assert_in_epsilon(151.72297875570032, worksheet.electricity_f42, 0.002); end
  def test_electricity_g42; assert_in_epsilon(199.6539983160431, worksheet.electricity_g42, 0.002); end
  def test_electricity_h42; assert_in_epsilon(287.1271781802326, worksheet.electricity_h42, 0.002); end
  def test_electricity_i42; assert_in_epsilon(376.14912252977416, worksheet.electricity_i42, 0.002); end
  def test_electricity_j42; assert_in_epsilon(466.5198189285979, worksheet.electricity_j42, 0.002); end
  def test_electricity_k42; assert_in_epsilon(571.5272178970807, worksheet.electricity_k42, 0.002); end
  def test_electricity_l42; assert_in_epsilon(664.7566158360804, worksheet.electricity_l42, 0.002); end
  def test_electricity_m42; assert_in_epsilon(777.4197481313641, worksheet.electricity_m42, 0.002); end
  def test_electricity_d43; assert_equal("Biomass power station", worksheet.electricity_d43); end
  def test_electricity_e43; assert_in_delta(0.0, (worksheet.electricity_e43||0), 0.002); end
  def test_electricity_f43; assert_in_delta(0.0, (worksheet.electricity_f43||0), 0.002); end
  def test_electricity_g43; assert_in_delta(0.039447, worksheet.electricity_g43, 0.002); end
  def test_electricity_h43; assert_in_delta(0.039447, worksheet.electricity_h43, 0.002); end
  def test_electricity_i43; assert_in_delta(0.039447, worksheet.electricity_i43, 0.002); end
  def test_electricity_j43; assert_in_delta(0.039447, worksheet.electricity_j43, 0.002); end
  def test_electricity_k43; assert_in_delta(0.039447, worksheet.electricity_k43, 0.002); end
  def test_electricity_l43; assert_in_delta(0.039447, worksheet.electricity_l43, 0.002); end
  def test_electricity_m43; assert_in_delta(0.039447, worksheet.electricity_m43, 0.002); end
  def test_electricity_d44; assert_equal("Nuclear power", worksheet.electricity_d44); end
  def test_electricity_e44; assert_in_delta(0.0, (worksheet.electricity_e44||0), 0.002); end
  def test_electricity_f44; assert_in_delta(0.0, (worksheet.electricity_f44||0), 0.002); end
  def test_electricity_g44; assert_in_delta(0.0, (worksheet.electricity_g44||0), 0.002); end
  def test_electricity_h44; assert_in_delta(0.0, (worksheet.electricity_h44||0), 0.002); end
  def test_electricity_i44; assert_in_delta(0.0, (worksheet.electricity_i44||0), 0.002); end
  def test_electricity_j44; assert_in_delta(0.0, (worksheet.electricity_j44||0), 0.002); end
  def test_electricity_k44; assert_in_delta(0.0, (worksheet.electricity_k44||0), 0.002); end
  def test_electricity_l44; assert_in_delta(0.0, (worksheet.electricity_l44||0), 0.002); end
  def test_electricity_m44; assert_in_delta(0.0, (worksheet.electricity_m44||0), 0.002); end
  def test_electricity_d45; assert_equal("Wind ", worksheet.electricity_d45); end
  def test_electricity_e45; assert_in_delta(0.0, (worksheet.electricity_e45||0), 0.002); end
  def test_electricity_f45; assert_in_delta(0.0, (worksheet.electricity_f45||0), 0.002); end
  def test_electricity_g45; assert_in_delta(0.017532, worksheet.electricity_g45, 0.002); end
  def test_electricity_h45; assert_in_delta(0.017532, worksheet.electricity_h45, 0.002); end
  def test_electricity_i45; assert_in_delta(0.017532, worksheet.electricity_i45, 0.002); end
  def test_electricity_j45; assert_in_delta(0.017532, worksheet.electricity_j45, 0.002); end
  def test_electricity_k45; assert_in_delta(0.017532, worksheet.electricity_k45, 0.002); end
  def test_electricity_l45; assert_in_delta(0.017532, worksheet.electricity_l45, 0.002); end
  def test_electricity_m45; assert_in_delta(0.017532, worksheet.electricity_m45, 0.002); end
  def test_electricity_d46; assert_equal("Hydroelectric power stations", worksheet.electricity_d46); end
  def test_electricity_e46; assert_in_epsilon(9.993239999999998, worksheet.electricity_e46, 0.002); end
  def test_electricity_f46; assert_in_epsilon(9.993239999999998, worksheet.electricity_f46, 0.002); end
  def test_electricity_g46; assert_in_epsilon(9.993239999999998, worksheet.electricity_g46, 0.002); end
  def test_electricity_h46; assert_in_epsilon(9.993239999999998, worksheet.electricity_h46, 0.002); end
  def test_electricity_i46; assert_in_epsilon(9.993239999999998, worksheet.electricity_i46, 0.002); end
  def test_electricity_j46; assert_in_epsilon(9.993239999999998, worksheet.electricity_j46, 0.002); end
  def test_electricity_k46; assert_in_epsilon(9.993239999999998, worksheet.electricity_k46, 0.002); end
  def test_electricity_l46; assert_in_epsilon(9.993239999999998, worksheet.electricity_l46, 0.002); end
  def test_electricity_m46; assert_in_epsilon(9.993239999999998, worksheet.electricity_m46, 0.002); end
  def test_electricity_d47; assert_equal("Small Hydroelectric power stations", worksheet.electricity_d47); end
  def test_electricity_e47; assert_in_delta(0.280512, worksheet.electricity_e47, 0.002); end
  def test_electricity_f47; assert_in_delta(0.280512, worksheet.electricity_f47, 0.002); end
  def test_electricity_g47; assert_in_delta(0.280512, worksheet.electricity_g47, 0.002); end
  def test_electricity_h47; assert_in_delta(0.280512, worksheet.electricity_h47, 0.002); end
  def test_electricity_i47; assert_in_delta(0.280512, worksheet.electricity_i47, 0.002); end
  def test_electricity_j47; assert_in_delta(0.280512, worksheet.electricity_j47, 0.002); end
  def test_electricity_k47; assert_in_delta(0.280512, worksheet.electricity_k47, 0.002); end
  def test_electricity_l47; assert_in_delta(0.280512, worksheet.electricity_l47, 0.002); end
  def test_electricity_m47; assert_in_delta(0.280512, worksheet.electricity_m47, 0.002); end
  def test_electricity_d48; assert_equal("Grid Connected Solar PV", worksheet.electricity_d48); end
  def test_electricity_e48; assert_in_delta(0.0, (worksheet.electricity_e48||0), 0.002); end
  def test_electricity_f48; assert_in_delta(0.0, (worksheet.electricity_f48||0), 0.002); end
  def test_electricity_g48; assert_in_delta(0.18408600000000003, worksheet.electricity_g48, 0.002); end
  def test_electricity_h48; assert_in_delta(0.36817200000000005, worksheet.electricity_h48, 0.002); end
  def test_electricity_i48; assert_in_delta(0.552258, worksheet.electricity_i48, 0.002); end
  def test_electricity_j48; assert_in_delta(0.7363440000000001, worksheet.electricity_j48, 0.002); end
  def test_electricity_k48; assert_in_delta(0.92043, worksheet.electricity_k48, 0.002); end
  def test_electricity_l48; assert_in_epsilon(1.104516, worksheet.electricity_l48, 0.002); end
  def test_electricity_m48; assert_in_epsilon(1.2886019999999998, worksheet.electricity_m48, 0.002); end
  def test_electricity_d49; assert_equal("Concentrated Solar Power", worksheet.electricity_d49); end
  def test_electricity_e49; assert_in_delta(0.0, (worksheet.electricity_e49||0), 0.002); end
  def test_electricity_f49; assert_in_delta(0.0, (worksheet.electricity_f49||0), 0.002); end
  def test_electricity_g49; assert_in_delta(0.0, (worksheet.electricity_g49||0), 0.002); end
  def test_electricity_h49; assert_in_delta(0.0, (worksheet.electricity_h49||0), 0.002); end
  def test_electricity_i49; assert_in_delta(0.0, (worksheet.electricity_i49||0), 0.002); end
  def test_electricity_j49; assert_in_delta(0.0, (worksheet.electricity_j49||0), 0.002); end
  def test_electricity_k49; assert_in_delta(0.0, (worksheet.electricity_k49||0), 0.002); end
  def test_electricity_l49; assert_in_delta(0.0, (worksheet.electricity_l49||0), 0.002); end
  def test_electricity_m49; assert_in_delta(0.0, (worksheet.electricity_m49||0), 0.002); end
  def test_electricity_d50; assert_equal("Stand-Alone Solar PV", worksheet.electricity_d50); end
  def test_electricity_e50; assert_in_delta(0.027612899999999996, worksheet.electricity_e50, 0.002); end
  def test_electricity_f50; assert_in_delta(0.92043, worksheet.electricity_f50, 0.002); end
  def test_electricity_g50; assert_in_epsilon(1.84086, worksheet.electricity_g50, 0.002); end
  def test_electricity_h50; assert_in_epsilon(2.76129, worksheet.electricity_h50, 0.002); end
  def test_electricity_i50; assert_in_epsilon(3.68172, worksheet.electricity_i50, 0.002); end
  def test_electricity_j50; assert_in_epsilon(4.60215, worksheet.electricity_j50, 0.002); end
  def test_electricity_k50; assert_in_epsilon(5.52258, worksheet.electricity_k50, 0.002); end
  def test_electricity_l50; assert_in_epsilon(6.44301, worksheet.electricity_l50, 0.002); end
  def test_electricity_m50; assert_in_epsilon(7.36344, worksheet.electricity_m50, 0.002); end
  def test_electricity_d51; assert_equal("Types of fuel from Biomass", worksheet.electricity_d51); end
  def test_electricity_e51; assert_in_delta(0.0, (worksheet.electricity_e51||0), 0.002); end
  def test_electricity_f51; assert_in_delta(0.0, (worksheet.electricity_f51||0), 0.002); end
  def test_electricity_g51; assert_in_delta(0.0, (worksheet.electricity_g51||0), 0.002); end
  def test_electricity_h51; assert_in_delta(0.0, (worksheet.electricity_h51||0), 0.002); end
  def test_electricity_i51; assert_in_delta(0.0, (worksheet.electricity_i51||0), 0.002); end
  def test_electricity_j51; assert_in_delta(0.0, (worksheet.electricity_j51||0), 0.002); end
  def test_electricity_k51; assert_in_delta(0.0, (worksheet.electricity_k51||0), 0.002); end
  def test_electricity_l51; assert_in_delta(0.0, (worksheet.electricity_l51||0), 0.002); end
  def test_electricity_m51; assert_in_delta(0.0, (worksheet.electricity_m51||0), 0.002); end
  def test_electricity_d52; assert_equal("Bioenergy imports", worksheet.electricity_d52); end
  def test_electricity_e52; assert_in_delta(0.0, (worksheet.electricity_e52||0), 0.002); end
  def test_electricity_f52; assert_in_delta(0.0, (worksheet.electricity_f52||0), 0.002); end
  def test_electricity_g52; assert_in_delta(0.0, (worksheet.electricity_g52||0), 0.002); end
  def test_electricity_h52; assert_in_delta(0.0, (worksheet.electricity_h52||0), 0.002); end
  def test_electricity_i52; assert_in_delta(0.0, (worksheet.electricity_i52||0), 0.002); end
  def test_electricity_j52; assert_in_delta(0.0, (worksheet.electricity_j52||0), 0.002); end
  def test_electricity_k52; assert_in_delta(0.0, (worksheet.electricity_k52||0), 0.002); end
  def test_electricity_l52; assert_in_delta(0.0, (worksheet.electricity_l52||0), 0.002); end
  def test_electricity_m52; assert_in_delta(0.0, (worksheet.electricity_m52||0), 0.002); end
  def test_electricity_d53; assert_equal("Agriculture and land use", worksheet.electricity_d53); end
  def test_electricity_e53; assert_in_delta(0.0, (worksheet.electricity_e53||0), 0.002); end
  def test_electricity_f53; assert_in_delta(0.0, (worksheet.electricity_f53||0), 0.002); end
  def test_electricity_g53; assert_in_delta(0.0, (worksheet.electricity_g53||0), 0.002); end
  def test_electricity_h53; assert_in_delta(0.0, (worksheet.electricity_h53||0), 0.002); end
  def test_electricity_i53; assert_in_delta(0.0, (worksheet.electricity_i53||0), 0.002); end
  def test_electricity_j53; assert_in_delta(0.0, (worksheet.electricity_j53||0), 0.002); end
  def test_electricity_k53; assert_in_delta(0.0, (worksheet.electricity_k53||0), 0.002); end
  def test_electricity_l53; assert_in_delta(0.0, (worksheet.electricity_l53||0), 0.002); end
  def test_electricity_m53; assert_in_delta(0.0, (worksheet.electricity_m53||0), 0.002); end
  def test_electricity_d54; assert_equal("Volume of Waste & Recycling", worksheet.electricity_d54); end
  def test_electricity_e54; assert_in_delta(0.0, (worksheet.electricity_e54||0), 0.002); end
  def test_electricity_f54; assert_in_delta(0.0, (worksheet.electricity_f54||0), 0.002); end
  def test_electricity_g54; assert_in_delta(0.0, (worksheet.electricity_g54||0), 0.002); end
  def test_electricity_h54; assert_in_delta(0.0, (worksheet.electricity_h54||0), 0.002); end
  def test_electricity_i54; assert_in_delta(0.0, (worksheet.electricity_i54||0), 0.002); end
  def test_electricity_j54; assert_in_delta(0.0, (worksheet.electricity_j54||0), 0.002); end
  def test_electricity_k54; assert_in_delta(0.0, (worksheet.electricity_k54||0), 0.002); end
  def test_electricity_l54; assert_in_delta(0.0, (worksheet.electricity_l54||0), 0.002); end
  def test_electricity_m54; assert_in_delta(0.0, (worksheet.electricity_m54||0), 0.002); end
  def test_electricity_d55; assert_equal("Electricity imports", worksheet.electricity_d55); end
  def test_electricity_e55; assert_in_delta(-0.525, worksheet.electricity_e55, 0.002); end
  def test_electricity_f55; assert_in_delta(-0.525, worksheet.electricity_f55, 0.002); end
  def test_electricity_g55; assert_in_delta(-0.525, worksheet.electricity_g55, 0.002); end
  def test_electricity_h55; assert_in_delta(-0.525, worksheet.electricity_h55, 0.002); end
  def test_electricity_i55; assert_in_delta(-0.525, worksheet.electricity_i55, 0.002); end
  def test_electricity_j55; assert_in_delta(-0.525, worksheet.electricity_j55, 0.002); end
  def test_electricity_k55; assert_in_delta(-0.525, worksheet.electricity_k55, 0.002); end
  def test_electricity_l55; assert_in_delta(-0.525, worksheet.electricity_l55, 0.002); end
  def test_electricity_m55; assert_in_delta(-0.525, worksheet.electricity_m55, 0.002); end
  def test_electricity_d56; assert_equal("Total", worksheet.electricity_d56); end
  def test_electricity_e56; assert_in_epsilon(139.06795918472457, worksheet.electricity_e56, 0.002); end
  def test_electricity_f56; assert_in_epsilon(162.3921607557003, worksheet.electricity_f56, 0.002); end
  def test_electricity_g56; assert_in_epsilon(211.48467531604305, worksheet.electricity_g56, 0.002); end
  def test_electricity_h56; assert_in_epsilon(300.0623711802326, worksheet.electricity_h56, 0.002); end
  def test_electricity_i56; assert_in_epsilon(390.1888315297742, worksheet.electricity_i56, 0.002); end
  def test_electricity_j56; assert_in_epsilon(481.6640439285979, worksheet.electricity_j56, 0.002); end
  def test_electricity_k56; assert_in_epsilon(587.7759588970807, worksheet.electricity_k56, 0.002); end
  def test_electricity_l56; assert_in_epsilon(682.1098728360804, worksheet.electricity_l56, 0.002); end
  def test_electricity_m56; assert_in_epsilon(795.8775211313641, worksheet.electricity_m56, 0.002); end
  def test_energy_d17; assert_equal("Transport", worksheet.energy_d17); end
  def test_energy_e17; assert_in_epsilon(199.91851557151367, worksheet.energy_e17, 0.002); end
  def test_energy_f17; assert_in_epsilon(303.4932735414058, worksheet.energy_f17, 0.002); end
  def test_energy_g17; assert_in_epsilon(371.6202648672837, worksheet.energy_g17, 0.002); end
  def test_energy_h17; assert_in_epsilon(424.7081640298286, worksheet.energy_h17, 0.002); end
  def test_energy_i17; assert_in_epsilon(468.04789390876846, worksheet.energy_i17, 0.002); end
  def test_energy_j17; assert_in_epsilon(516.6215228667696, worksheet.energy_j17, 0.002); end
  def test_energy_k17; assert_in_epsilon(548.4601921954501, worksheet.energy_k17, 0.002); end
  def test_energy_l17; assert_in_epsilon(576.9071859889108, worksheet.energy_l17, 0.002); end
  def test_energy_m17; assert_in_epsilon(602.4820527459256, worksheet.energy_m17, 0.002); end
  def test_energy_d18; assert_equal("Industry", worksheet.energy_d18); end
  def test_energy_e18; assert_in_epsilon(419.3452816939454, worksheet.energy_e18, 0.002); end
  def test_energy_f18; assert_in_epsilon(394.6885535040981, worksheet.energy_f18, 0.002); end
  def test_energy_g18; assert_in_epsilon(376.1831408693938, worksheet.energy_g18, 0.002); end
  def test_energy_h18; assert_in_epsilon(360.7418114001044, worksheet.energy_h18, 0.002); end
  def test_energy_i18; assert_in_epsilon(343.6240030035792, worksheet.energy_i18, 0.002); end
  def test_energy_j18; assert_in_epsilon(327.78034461950114, worksheet.energy_j18, 0.002); end
  def test_energy_k18; assert_in_epsilon(313.57916869654946, worksheet.energy_k18, 0.002); end
  def test_energy_l18; assert_in_epsilon(301.44872220378954, worksheet.energy_l18, 0.002); end
  def test_energy_m18; assert_in_epsilon(291.886937781592, worksheet.energy_m18, 0.002); end
  def test_energy_d19; assert_equal("Cooling", worksheet.energy_d19); end
  def test_energy_e19; assert_in_epsilon(45.23241057567228, worksheet.energy_e19, 0.002); end
  def test_energy_f19; assert_in_epsilon(51.703504111940035, worksheet.energy_f19, 0.002); end
  def test_energy_g19; assert_in_epsilon(57.87457835156304, worksheet.energy_g19, 0.002); end
  def test_energy_h19; assert_in_epsilon(63.727201941623775, worksheet.energy_h19, 0.002); end
  def test_energy_i19; assert_in_epsilon(69.24053615847055, worksheet.energy_i19, 0.002); end
  def test_energy_j19; assert_in_epsilon(74.3911100028562, worksheet.energy_j19, 0.002); end
  def test_energy_k19; assert_in_epsilon(79.15257722359095, worksheet.energy_k19, 0.002); end
  def test_energy_l19; assert_in_epsilon(83.49545394031607, worksheet.energy_l19, 0.002); end
  def test_energy_m19; assert_in_epsilon(87.38683544379465, worksheet.energy_m19, 0.002); end
  def test_energy_d20; assert_equal("Lighting & appliances", worksheet.energy_d20); end
  def test_energy_e20; assert_in_epsilon(30.768996771009306, worksheet.energy_e20, 0.002); end
  def test_energy_f20; assert_in_epsilon(35.57650882321771, worksheet.energy_f20, 0.002); end
  def test_energy_g20; assert_in_epsilon(60.916030212058686, worksheet.energy_g20, 0.002); end
  def test_energy_h20; assert_in_epsilon(113.04038720981688, worksheet.energy_h20, 0.002); end
  def test_energy_i20; assert_in_epsilon(165.11175352816792, worksheet.energy_i20, 0.002); end
  def test_energy_j20; assert_in_epsilon(221.25866219560046, worksheet.energy_j20, 0.002); end
  def test_energy_k20; assert_in_epsilon(275.69550670830967, worksheet.energy_k20, 0.002); end
  def test_energy_l20; assert_in_epsilon(330.0191898252094, worksheet.energy_l20, 0.002); end
  def test_energy_m20; assert_in_epsilon(385.960842955381, worksheet.energy_m20, 0.002); end
  def test_energy_d21; assert_equal("Cooking", worksheet.energy_d21); end
  def test_energy_e21; assert_in_epsilon(239.36058753860928, worksheet.energy_e21, 0.002); end
  def test_energy_f21; assert_in_epsilon(228.6242461028551, worksheet.energy_f21, 0.002); end
  def test_energy_g21; assert_in_epsilon(216.73381249080103, worksheet.energy_g21, 0.002); end
  def test_energy_h21; assert_in_epsilon(203.06298806371035, worksheet.energy_h21, 0.002); end
  def test_energy_i21; assert_in_epsilon(187.01392850736747, worksheet.energy_i21, 0.002); end
  def test_energy_j21; assert_in_epsilon(170.47448017142992, worksheet.energy_j21, 0.002); end
  def test_energy_k21; assert_in_epsilon(151.60093949023258, worksheet.energy_k21, 0.002); end
  def test_energy_l21; assert_in_epsilon(130.2038283500409, worksheet.energy_l21, 0.002); end
  def test_energy_m21; assert_in_epsilon(106.08041142810023, worksheet.energy_m21, 0.002); end
  def test_energy_d22; assert_equal("Total", worksheet.energy_d22); end
  def test_energy_e22; assert_in_epsilon(934.6257921507498, worksheet.energy_e22, 0.002); end
  def test_energy_f22; assert_in_epsilon(1014.0860860835168, worksheet.energy_f22, 0.002); end
  def test_energy_g22; assert_in_epsilon(1083.3278267911003, worksheet.energy_g22, 0.002); end
  def test_energy_h22; assert_in_epsilon(1165.2805526450838, worksheet.energy_h22, 0.002); end
  def test_energy_i22; assert_in_epsilon(1233.0381151063534, worksheet.energy_i22, 0.002); end
  def test_energy_j22; assert_in_epsilon(1310.5261198561573, worksheet.energy_j22, 0.002); end
  def test_energy_k22; assert_in_epsilon(1368.4883843141326, worksheet.energy_k22, 0.002); end
  def test_energy_l22; assert_in_epsilon(1422.0743803082669, worksheet.energy_l22, 0.002); end
  def test_energy_m22; assert_in_epsilon(1473.7970803547935, worksheet.energy_m22, 0.002); end
  def test_energy_d16; assert_equal("Vector", worksheet.energy_d16); end
  def test_energy_e16; assert_in_epsilon(2010.0, worksheet.energy_e16, 0.002); end
  def test_energy_f16; assert_in_epsilon(2015.0, worksheet.energy_f16, 0.002); end
  def test_energy_g16; assert_in_epsilon(2020.0, worksheet.energy_g16, 0.002); end
  def test_energy_h16; assert_in_epsilon(2025.0, worksheet.energy_h16, 0.002); end
  def test_energy_i16; assert_in_epsilon(2030.0, worksheet.energy_i16, 0.002); end
  def test_energy_j16; assert_in_epsilon(2035.0, worksheet.energy_j16, 0.002); end
  def test_energy_k16; assert_in_epsilon(2040.0, worksheet.energy_k16, 0.002); end
  def test_energy_l16; assert_in_epsilon(2045.0, worksheet.energy_l16, 0.002); end
  def test_energy_m16; assert_in_epsilon(2050.0, worksheet.energy_m16, 0.002); end
  def test_energy_d47; assert_equal("Vector", worksheet.energy_d47); end
  def test_energy_e47; assert_in_epsilon(2010.0, worksheet.energy_e47, 0.002); end
  def test_energy_f47; assert_in_epsilon(2015.0, worksheet.energy_f47, 0.002); end
  def test_energy_g47; assert_in_epsilon(2020.0, worksheet.energy_g47, 0.002); end
  def test_energy_h47; assert_in_epsilon(2025.0, worksheet.energy_h47, 0.002); end
  def test_energy_i47; assert_in_epsilon(2030.0, worksheet.energy_i47, 0.002); end
  def test_energy_j47; assert_in_epsilon(2035.0, worksheet.energy_j47, 0.002); end
  def test_energy_k47; assert_in_epsilon(2040.0, worksheet.energy_k47, 0.002); end
  def test_energy_l47; assert_in_epsilon(2045.0, worksheet.energy_l47, 0.002); end
  def test_energy_m47; assert_in_epsilon(2050.0, worksheet.energy_m47, 0.002); end
  def test_energy_d48; assert_equal("Nuclear fission", worksheet.energy_d48); end
  def test_energy_e48; assert_in_delta(0.0, (worksheet.energy_e48||0), 0.002); end
  def test_energy_f48; assert_in_delta(0.0, (worksheet.energy_f48||0), 0.002); end
  def test_energy_g48; assert_in_delta(0.0, (worksheet.energy_g48||0), 0.002); end
  def test_energy_h48; assert_in_delta(0.0, (worksheet.energy_h48||0), 0.002); end
  def test_energy_i48; assert_in_delta(0.0, (worksheet.energy_i48||0), 0.002); end
  def test_energy_j48; assert_in_delta(0.0, (worksheet.energy_j48||0), 0.002); end
  def test_energy_k48; assert_in_delta(0.0, (worksheet.energy_k48||0), 0.002); end
  def test_energy_l48; assert_in_delta(0.0, (worksheet.energy_l48||0), 0.002); end
  def test_energy_m48; assert_in_delta(0.0, (worksheet.energy_m48||0), 0.002); end
  def test_energy_d49; assert_equal("Solar", worksheet.energy_d49); end
  def test_energy_e49; assert_in_delta(0.027612899999999996, worksheet.energy_e49, 0.002); end
  def test_energy_f49; assert_in_delta(0.92043, worksheet.energy_f49, 0.002); end
  def test_energy_g49; assert_in_epsilon(2.024946, worksheet.energy_g49, 0.002); end
  def test_energy_h49; assert_in_epsilon(3.1294619999999997, worksheet.energy_h49, 0.002); end
  def test_energy_i49; assert_in_epsilon(4.233978, worksheet.energy_i49, 0.002); end
  def test_energy_j49; assert_in_epsilon(5.338494, worksheet.energy_j49, 0.002); end
  def test_energy_k49; assert_in_epsilon(6.443009999999999, worksheet.energy_k49, 0.002); end
  def test_energy_l49; assert_in_epsilon(7.547526, worksheet.energy_l49, 0.002); end
  def test_energy_m49; assert_in_epsilon(8.652042, worksheet.energy_m49, 0.002); end
  def test_energy_d50; assert_equal("Wind", worksheet.energy_d50); end
  def test_energy_e50; assert_in_delta(0.0, (worksheet.energy_e50||0), 0.002); end
  def test_energy_f50; assert_in_delta(0.0, (worksheet.energy_f50||0), 0.002); end
  def test_energy_g50; assert_in_delta(0.017532, worksheet.energy_g50, 0.002); end
  def test_energy_h50; assert_in_delta(0.017532, worksheet.energy_h50, 0.002); end
  def test_energy_i50; assert_in_delta(0.017532, worksheet.energy_i50, 0.002); end
  def test_energy_j50; assert_in_delta(0.017532, worksheet.energy_j50, 0.002); end
  def test_energy_k50; assert_in_delta(0.017532, worksheet.energy_k50, 0.002); end
  def test_energy_l50; assert_in_delta(0.017532, worksheet.energy_l50, 0.002); end
  def test_energy_m50; assert_in_delta(0.017532, worksheet.energy_m50, 0.002); end
  def test_energy_d51; assert_equal("Hydro", worksheet.energy_d51); end
  def test_energy_e51; assert_in_epsilon(10.273751999999998, worksheet.energy_e51, 0.002); end
  def test_energy_f51; assert_in_epsilon(10.273751999999998, worksheet.energy_f51, 0.002); end
  def test_energy_g51; assert_in_epsilon(10.273751999999998, worksheet.energy_g51, 0.002); end
  def test_energy_h51; assert_in_epsilon(10.273751999999998, worksheet.energy_h51, 0.002); end
  def test_energy_i51; assert_in_epsilon(10.273751999999998, worksheet.energy_i51, 0.002); end
  def test_energy_j51; assert_in_epsilon(10.273751999999998, worksheet.energy_j51, 0.002); end
  def test_energy_k51; assert_in_epsilon(10.273751999999998, worksheet.energy_k51, 0.002); end
  def test_energy_l51; assert_in_epsilon(10.273751999999998, worksheet.energy_l51, 0.002); end
  def test_energy_m51; assert_in_epsilon(10.273751999999998, worksheet.energy_m51, 0.002); end
  def test_energy_d52; assert_equal("Electricity oversupply (imports)", worksheet.energy_d52); end
  def test_energy_e52; assert_in_delta(-0.525, worksheet.energy_e52, 0.002); end
  def test_energy_f52; assert_in_delta(-0.525, worksheet.energy_f52, 0.002); end
  def test_energy_g52; assert_in_delta(-0.5250000000000284, worksheet.energy_g52, 0.002); end
  def test_energy_h52; assert_in_delta(-0.5249999999999716, worksheet.energy_h52, 0.002); end
  def test_energy_i52; assert_in_delta(-0.5250000000000569, worksheet.energy_i52, 0.002); end
  def test_energy_j52; assert_in_delta(-0.525, worksheet.energy_j52, 0.002); end
  def test_energy_k52; assert_in_delta(-0.525, worksheet.energy_k52, 0.002); end
  def test_energy_l52; assert_in_delta(-0.5249999999998863, worksheet.energy_l52, 0.002); end
  def test_energy_m52; assert_in_delta(-0.525, worksheet.energy_m52, 0.002); end
  def test_energy_d53; assert_equal("Bioenergy", worksheet.energy_d53); end
  def test_energy_e53; assert_in_epsilon(1775.43418782733, worksheet.energy_e53, 0.002); end
  def test_energy_f53; assert_in_epsilon(1777.5409535560138, worksheet.energy_f53, 0.002); end
  def test_energy_g53; assert_in_epsilon(1792.8691142678465, worksheet.energy_g53, 0.002); end
  def test_energy_h53; assert_in_epsilon(1818.149655638295, worksheet.energy_h53, 0.002); end
  def test_energy_i53; assert_in_epsilon(1822.954882937613, worksheet.energy_i53, 0.002); end
  def test_energy_j53; assert_in_epsilon(1829.4554905016487, worksheet.energy_j53, 0.002); end
  def test_energy_k53; assert_in_epsilon(1838.1020409144148, worksheet.energy_k53, 0.002); end
  def test_energy_l53; assert_in_epsilon(1850.4394416902317, worksheet.energy_l53, 0.002); end
  def test_energy_m53; assert_in_epsilon(1866.152294795299, worksheet.energy_m53, 0.002); end
  def test_energy_d54; assert_equal("Coal", worksheet.energy_d54); end
  def test_energy_e54; assert_in_epsilon(-3.923588666666668, worksheet.energy_e54, 0.002); end
  def test_energy_f54; assert_in_epsilon(-4.780809996250002, worksheet.energy_f54, 0.002); end
  def test_energy_g54; assert_in_epsilon(-5.838653768333336, worksheet.energy_g54, 0.002); end
  def test_energy_h54; assert_in_epsilon(-6.81266013791668, worksheet.energy_h54, 0.002); end
  def test_energy_i54; assert_in_epsilon(-8.135788666666656, worksheet.energy_i54, 0.002); end
  def test_energy_j54; assert_in_epsilon(-9.513491039999963, worksheet.energy_j54, 0.002); end
  def test_energy_k54; assert_in_epsilon(-10.761552026666664, worksheet.energy_k54, 0.002); end
  def test_energy_l54; assert_in_epsilon(-12.110384960000033, worksheet.energy_l54, 0.002); end
  def test_energy_m54; assert_in_epsilon(-13.458389840000109, worksheet.energy_m54, 0.002); end
  def test_energy_d55; assert_equal("Oil", worksheet.energy_d55); end
  def test_energy_e55; assert_in_epsilon(789.5130298683872, worksheet.energy_e55, 0.002); end
  def test_energy_f55; assert_in_epsilon(992.591480421974, worksheet.energy_f55, 0.002); end
  def test_energy_g55; assert_in_epsilon(1282.503457983557, worksheet.energy_g55, 0.002); end
  def test_energy_h55; assert_in_epsilon(1706.9076290322487, worksheet.energy_h55, 0.002); end
  def test_energy_i55; assert_in_epsilon(2171.0390498998863, worksheet.energy_i55, 0.002); end
  def test_energy_j55; assert_in_epsilon(2636.9768947006924, worksheet.energy_j55, 0.002); end
  def test_energy_k55; assert_in_epsilon(3155.944106509667, worksheet.energy_k55, 0.002); end
  def test_energy_l55; assert_in_epsilon(3608.2308026483847, worksheet.energy_l55, 0.002); end
  def test_energy_m55; assert_in_epsilon(4149.065954043985, worksheet.energy_m55, 0.002); end
  def test_energy_d56; assert_equal("Gas", worksheet.energy_d56); end
  def test_energy_e56; assert_in_epsilon(412.6102834436577, worksheet.energy_e56, 0.002); end
  def test_energy_f56; assert_in_epsilon(397.5484142647076, worksheet.energy_f56, 0.002); end
  def test_energy_g56; assert_in_epsilon(378.82667006285135, worksheet.energy_g56, 0.002); end
  def test_energy_h56; assert_in_epsilon(366.77985016294065, worksheet.energy_h56, 0.002); end
  def test_energy_i56; assert_in_epsilon(355.752245754045, worksheet.energy_i56, 0.002); end
  def test_energy_j56; assert_in_epsilon(342.9663615777174, worksheet.energy_j56, 0.002); end
  def test_energy_k56; assert_in_epsilon(328.60388672990007, worksheet.energy_k56, 0.002); end
  def test_energy_l56; assert_in_epsilon(311.1199085061853, worksheet.energy_l56, 0.002); end
  def test_energy_m56; assert_in_epsilon(292.0798884013054, worksheet.energy_m56, 0.002); end
  def test_energy_d57; assert_equal("Total", worksheet.energy_d57); end
  def test_energy_e57; assert_in_epsilon(2983.4102773727086, worksheet.energy_e57, 0.002); end
  def test_energy_f57; assert_in_epsilon(3173.569220246445, worksheet.energy_f57, 0.002); end
  def test_energy_g57; assert_in_epsilon(3460.1518185459213, worksheet.energy_g57, 0.002); end
  def test_energy_h57; assert_in_epsilon(3897.920220695567, worksheet.energy_h57, 0.002); end
  def test_energy_i57; assert_in_epsilon(4355.610651924878, worksheet.energy_i57, 0.002); end
  def test_energy_j57; assert_in_epsilon(4814.990033740058, worksheet.energy_j57, 0.002); end
  def test_energy_k57; assert_in_epsilon(5328.097776127316, worksheet.energy_k57, 0.002); end
  def test_energy_l57; assert_in_epsilon(5774.993577884801, worksheet.energy_l57, 0.002); end
  def test_energy_m57; assert_in_epsilon(6312.25807340059, worksheet.energy_m57, 0.002); end
  def test_ghg_d13; assert_equal("Mt CO2e", worksheet.ghg_d13); end
  def test_ghg_e13; assert_in_epsilon(2010.0, worksheet.ghg_e13, 0.002); end
  def test_ghg_f13; assert_in_epsilon(2015.0, worksheet.ghg_f13, 0.002); end
  def test_ghg_g13; assert_in_epsilon(2020.0, worksheet.ghg_g13, 0.002); end
  def test_ghg_h13; assert_in_epsilon(2025.0, worksheet.ghg_h13, 0.002); end
  def test_ghg_i13; assert_in_epsilon(2030.0, worksheet.ghg_i13, 0.002); end
  def test_ghg_j13; assert_in_epsilon(2035.0, worksheet.ghg_j13, 0.002); end
  def test_ghg_k13; assert_in_epsilon(2040.0, worksheet.ghg_k13, 0.002); end
  def test_ghg_l13; assert_in_epsilon(2045.0, worksheet.ghg_l13, 0.002); end
  def test_ghg_m13; assert_in_epsilon(2050.0, worksheet.ghg_m13, 0.002); end
  def test_ghg_d14; assert_equal("Fuel Combustion", worksheet.ghg_d14); end
  def test_ghg_e14; assert_in_epsilon(309.0873721033104, worksheet.ghg_e14, 0.002); end
  def test_ghg_f14; assert_in_epsilon(362.24351236433534, worksheet.ghg_f14, 0.002); end
  def test_ghg_g14; assert_in_epsilon(437.6741793123761, worksheet.ghg_g14, 0.002); end
  def test_ghg_h14; assert_in_epsilon(554.5601530674035, worksheet.ghg_h14, 0.002); end
  def test_ghg_i14; assert_in_epsilon(672.1794566582895, worksheet.ghg_i14, 0.002); end
  def test_ghg_j14; assert_in_epsilon(788.7527004602538, worksheet.ghg_j14, 0.002); end
  def test_ghg_k14; assert_in_epsilon(917.2008060328471, worksheet.ghg_k14, 0.002); end
  def test_ghg_l14; assert_in_epsilon(1026.4852582817168, worksheet.ghg_l14, 0.002); end
  def test_ghg_m14; assert_in_epsilon(1156.2406841529983, worksheet.ghg_m14, 0.002); end
  def test_ghg_d15; assert_equal("Industrial Processes", worksheet.ghg_d15); end
  def test_ghg_e15; assert_in_epsilon(27.891312059948405, worksheet.ghg_e15, 0.002); end
  def test_ghg_f15; assert_in_epsilon(27.858091129429077, worksheet.ghg_f15, 0.002); end
  def test_ghg_g15; assert_in_epsilon(27.86547682600942, worksheet.ghg_g15, 0.002); end
  def test_ghg_h15; assert_in_epsilon(27.914626100053326, worksheet.ghg_h15, 0.002); end
  def test_ghg_i15; assert_in_epsilon(27.542607500392428, worksheet.ghg_i15, 0.002); end
  def test_ghg_j15; assert_in_epsilon(27.19371178333455, worksheet.ghg_j15, 0.002); end
  def test_ghg_k15; assert_in_epsilon(26.867422835474294, worksheet.ghg_k15, 0.002); end
  def test_ghg_l15; assert_in_epsilon(26.563252748959535, worksheet.ghg_l15, 0.002); end
  def test_ghg_m15; assert_in_epsilon(27.891312059948405, worksheet.ghg_m15, 0.002); end
  def test_ghg_d16; assert_equal("Solvent and Other Product Use", worksheet.ghg_d16); end
  def test_ghg_e16; assert_in_delta(0.0, (worksheet.ghg_e16||0), 0.002); end
  def test_ghg_f16; assert_in_delta(0.0, (worksheet.ghg_f16||0), 0.002); end
  def test_ghg_g16; assert_in_delta(0.0, (worksheet.ghg_g16||0), 0.002); end
  def test_ghg_h16; assert_in_delta(0.0, (worksheet.ghg_h16||0), 0.002); end
  def test_ghg_i16; assert_in_delta(0.0, (worksheet.ghg_i16||0), 0.002); end
  def test_ghg_j16; assert_in_delta(0.0, (worksheet.ghg_j16||0), 0.002); end
  def test_ghg_k16; assert_in_delta(0.0, (worksheet.ghg_k16||0), 0.002); end
  def test_ghg_l16; assert_in_delta(0.0, (worksheet.ghg_l16||0), 0.002); end
  def test_ghg_m16; assert_in_delta(0.0, (worksheet.ghg_m16||0), 0.002); end
  def test_ghg_d17; assert_equal("Agriculture", worksheet.ghg_d17); end
  def test_ghg_e17; assert_in_epsilon(23.28, worksheet.ghg_e17, 0.002); end
  def test_ghg_f17; assert_in_epsilon(22.545258398704277, worksheet.ghg_f17, 0.002); end
  def test_ghg_g17; assert_in_epsilon(21.83370602510076, worksheet.ghg_g17, 0.002); end
  def test_ghg_h17; assert_in_epsilon(21.83370602510076, worksheet.ghg_h17, 0.002); end
  def test_ghg_i17; assert_in_epsilon(21.83370602510076, worksheet.ghg_i17, 0.002); end
  def test_ghg_j17; assert_in_epsilon(21.83370602510076, worksheet.ghg_j17, 0.002); end
  def test_ghg_k17; assert_in_epsilon(21.83370602510076, worksheet.ghg_k17, 0.002); end
  def test_ghg_l17; assert_in_epsilon(21.83370602510076, worksheet.ghg_l17, 0.002); end
  def test_ghg_m17; assert_in_epsilon(21.83370602510076, worksheet.ghg_m17, 0.002); end
  def test_ghg_d18; assert_equal("LULUCF", worksheet.ghg_d18); end
  def test_ghg_e18; assert_in_epsilon(1.7217577099999988, worksheet.ghg_e18, 0.002); end
  def test_ghg_f18; assert_in_epsilon(5.066771169999999, worksheet.ghg_f18, 0.002); end
  def test_ghg_g18; assert_in_epsilon(8.31095673, worksheet.ghg_g18, 0.002); end
  def test_ghg_h18; assert_in_epsilon(11.30662978, worksheet.ghg_h18, 0.002); end
  def test_ghg_i18; assert_in_epsilon(12.974674579999999, worksheet.ghg_i18, 0.002); end
  def test_ghg_j18; assert_in_epsilon(13.239221689999997, worksheet.ghg_j18, 0.002); end
  def test_ghg_k18; assert_in_epsilon(12.214846649999998, worksheet.ghg_k18, 0.002); end
  def test_ghg_l18; assert_in_epsilon(10.93357277, worksheet.ghg_l18, 0.002); end
  def test_ghg_m18; assert_in_epsilon(10.422221529999998, worksheet.ghg_m18, 0.002); end
  def test_ghg_d19; assert_equal("Waste", worksheet.ghg_d19); end
  def test_ghg_e19; assert_in_epsilon(13.121211328991082, worksheet.ghg_e19, 0.002); end
  def test_ghg_f19; assert_in_epsilon(11.24090084717184, worksheet.ghg_f19, 0.002); end
  def test_ghg_g19; assert_in_epsilon(9.360590365352598, worksheet.ghg_g19, 0.002); end
  def test_ghg_h19; assert_in_epsilon(9.10021737458659, worksheet.ghg_h19, 0.002); end
  def test_ghg_i19; assert_in_epsilon(8.729292840263563, worksheet.ghg_i19, 0.002); end
  def test_ghg_j19; assert_in_epsilon(8.704299789925228, worksheet.ghg_j19, 0.002); end
  def test_ghg_k19; assert_in_epsilon(8.619475532423394, worksheet.ghg_k19, 0.002); end
  def test_ghg_l19; assert_in_epsilon(8.47482006775806, worksheet.ghg_l19, 0.002); end
  def test_ghg_m19; assert_in_epsilon(8.270333395929237, worksheet.ghg_m19, 0.002); end
  def test_ghg_d20; assert_equal("Other", worksheet.ghg_d20); end
  def test_ghg_e20; assert_in_delta(0.0, (worksheet.ghg_e20||0), 0.002); end
  def test_ghg_f20; assert_in_delta(0.0, (worksheet.ghg_f20||0), 0.002); end
  def test_ghg_g20; assert_in_delta(0.0, (worksheet.ghg_g20||0), 0.002); end
  def test_ghg_h20; assert_in_delta(0.0, (worksheet.ghg_h20||0), 0.002); end
  def test_ghg_i20; assert_in_delta(0.0, (worksheet.ghg_i20||0), 0.002); end
  def test_ghg_j20; assert_in_delta(0.0, (worksheet.ghg_j20||0), 0.002); end
  def test_ghg_k20; assert_in_delta(0.0, (worksheet.ghg_k20||0), 0.002); end
  def test_ghg_l20; assert_in_delta(0.0, (worksheet.ghg_l20||0), 0.002); end
  def test_ghg_m20; assert_in_delta(0.0, (worksheet.ghg_m20||0), 0.002); end
  def test_ghg_d21; assert_equal("Bioenergy credit", worksheet.ghg_d21); end
  def test_ghg_e21; assert_in_epsilon(-4.488785452273249, worksheet.ghg_e21, 0.002); end
  def test_ghg_f21; assert_in_epsilon(-5.084675017973435, worksheet.ghg_f21, 0.002); end
  def test_ghg_g21; assert_in_epsilon(-7.2455881984895445, worksheet.ghg_g21, 0.002); end
  def test_ghg_h21; assert_in_epsilon(-15.978802480508723, worksheet.ghg_h21, 0.002); end
  def test_ghg_i21; assert_in_epsilon(-16.33478379812423, worksheet.ghg_i21, 0.002); end
  def test_ghg_j21; assert_in_epsilon(-16.800308276293695, worksheet.ghg_j21, 0.002); end
  def test_ghg_k21; assert_in_epsilon(-17.336300090706736, worksheet.ghg_k21, 0.002); end
  def test_ghg_l21; assert_in_epsilon(-17.95545821299916, worksheet.ghg_l21, 0.002); end
  def test_ghg_m21; assert_in_epsilon(-18.659202655072882, worksheet.ghg_m21, 0.002); end
  def test_ghg_d22; assert_equal("Carbon capture", worksheet.ghg_d22); end
  def test_ghg_e22; assert_in_delta(0.0, (worksheet.ghg_e22||0), 0.002); end
  def test_ghg_f22; assert_in_delta(0.0, (worksheet.ghg_f22||0), 0.002); end
  def test_ghg_g22; assert_in_delta(0.0, (worksheet.ghg_g22||0), 0.002); end
  def test_ghg_h22; assert_in_delta(0.0, (worksheet.ghg_h22||0), 0.002); end
  def test_ghg_i22; assert_in_delta(0.0, (worksheet.ghg_i22||0), 0.002); end
  def test_ghg_j22; assert_in_delta(0.0, (worksheet.ghg_j22||0), 0.002); end
  def test_ghg_k22; assert_in_delta(0.0, (worksheet.ghg_k22||0), 0.002); end
  def test_ghg_l22; assert_in_delta(0.0, (worksheet.ghg_l22||0), 0.002); end
  def test_ghg_m22; assert_in_delta(0.0, (worksheet.ghg_m22||0), 0.002); end
  def test_ghg_d23; assert_equal("Total", worksheet.ghg_d23); end
  def test_ghg_e23; assert_in_epsilon(370.6128677499766, worksheet.ghg_e23, 0.002); end
  def test_ghg_f23; assert_in_epsilon(423.86985889166704, worksheet.ghg_f23, 0.002); end
  def test_ghg_g23; assert_in_epsilon(497.7993210603493, worksheet.ghg_g23, 0.002); end
  def test_ghg_h23; assert_in_epsilon(608.7365298666354, worksheet.ghg_h23, 0.002); end
  def test_ghg_i23; assert_in_epsilon(726.9249538059221, worksheet.ghg_i23, 0.002); end
  def test_ghg_j23; assert_in_epsilon(842.9233314723208, worksheet.ghg_j23, 0.002); end
  def test_ghg_k23; assert_in_epsilon(969.3999569851389, worksheet.ghg_k23, 0.002); end
  def test_ghg_l23; assert_in_epsilon(1076.3351516805358, worksheet.ghg_l23, 0.002); end
  def test_ghg_m23; assert_in_epsilon(1205.9990545089036, worksheet.ghg_m23, 0.002); end
  def test_ghg_d24; assert_equal("Targets", worksheet.ghg_d24); end
  def test_ghg_e24; assert_in_epsilon(603.6, worksheet.ghg_e24, 0.002); end
  def test_ghg_f24; assert_in_epsilon(556.4, worksheet.ghg_f24, 0.002); end
  def test_ghg_g24; assert_in_epsilon(508.8, worksheet.ghg_g24, 0.002); end
  def test_ghg_h24; assert_in_epsilon(390.0, worksheet.ghg_h24, 0.002); end
  def test_ghg_m24; assert_in_epsilon(159.917234, worksheet.ghg_m24, 0.002); end
  def test_ghg_e42; assert_in_epsilon(-1.7714580636271187, worksheet.ghg_e42, 0.002); end
  def test_intermediate_output_b2; assert_equal("Energy source / use charts", worksheet.intermediate_output_b2); end
  def test_intermediate_output_ax3; assert_equal("2050 Calculator calculations", worksheet.intermediate_output_ax3); end
  def test_intermediate_output_d4; assert_equal("TWh / year", worksheet.intermediate_output_d4); end
  def test_intermediate_output_ax4; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax4, 0.002); end
  def test_intermediate_output_ay4; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay4, 0.002); end
  def test_intermediate_output_az4; assert_in_epsilon(2020.0, worksheet.intermediate_output_az4, 0.002); end
  def test_intermediate_output_ba4; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba4, 0.002); end
  def test_intermediate_output_bb4; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb4, 0.002); end
  def test_intermediate_output_bc4; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc4, 0.002); end
  def test_intermediate_output_bd4; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd4, 0.002); end
  def test_intermediate_output_be4; assert_in_epsilon(2045.0, worksheet.intermediate_output_be4, 0.002); end
  def test_intermediate_output_bf4; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf4, 0.002); end
  def test_intermediate_output_c6; assert_equal("Use", worksheet.intermediate_output_c6); end
  def test_intermediate_output_c7; assert_equal("T.01", worksheet.intermediate_output_c7); end
  def test_intermediate_output_d7; assert_equal("Road transport", worksheet.intermediate_output_d7); end
  def test_intermediate_output_ax7; assert_in_epsilon(104.0354388403685, worksheet.intermediate_output_ax7, 0.002); end
  def test_intermediate_output_ay7; assert_in_epsilon(103.66662385576298, worksheet.intermediate_output_ay7, 0.002); end
  def test_intermediate_output_az7; assert_in_epsilon(102.59073877835738, worksheet.intermediate_output_az7, 0.002); end
  def test_intermediate_output_ba7; assert_in_epsilon(101.46682965910142, worksheet.intermediate_output_ba7, 0.002); end
  def test_intermediate_output_bb7; assert_in_epsilon(100.03560820191448, worksheet.intermediate_output_bb7, 0.002); end
  def test_intermediate_output_bc7; assert_in_epsilon(110.85189979453413, worksheet.intermediate_output_bc7, 0.002); end
  def test_intermediate_output_bd7; assert_in_epsilon(120.90937312505679, worksheet.intermediate_output_bd7, 0.002); end
  def test_intermediate_output_be7; assert_in_epsilon(133.65080985812898, worksheet.intermediate_output_be7, 0.002); end
  def test_intermediate_output_bf7; assert_in_epsilon(148.6867959401971, worksheet.intermediate_output_bf7, 0.002); end
  def test_intermediate_output_c8; assert_equal("T.02", worksheet.intermediate_output_c8); end
  def test_intermediate_output_d8; assert_equal("Rail transport", worksheet.intermediate_output_d8); end
  def test_intermediate_output_ax8; assert_in_epsilon(50.90122628744819, worksheet.intermediate_output_ax8, 0.002); end
  def test_intermediate_output_ay8; assert_in_epsilon(144.42263753318363, worksheet.intermediate_output_ay8, 0.002); end
  def test_intermediate_output_az8; assert_in_epsilon(202.96052033675065, worksheet.intermediate_output_az8, 0.002); end
  def test_intermediate_output_ba8; assert_in_epsilon(245.44809122706482, worksheet.intermediate_output_ba8, 0.002); end
  def test_intermediate_output_bb8; assert_in_epsilon(277.32225113869475, worksheet.intermediate_output_bb8, 0.002); end
  def test_intermediate_output_bc8; assert_in_epsilon(300.88709198015454, worksheet.intermediate_output_bc8, 0.002); end
  def test_intermediate_output_bd8; assert_in_epsilon(309.7609886574612, worksheet.intermediate_output_bd8, 0.002); end
  def test_intermediate_output_be8; assert_in_epsilon(311.68231045656387, worksheet.intermediate_output_be8, 0.002); end
  def test_intermediate_output_bf8; assert_in_epsilon(307.49721989900314, worksheet.intermediate_output_bf8, 0.002); end
  def test_intermediate_output_c9; assert_equal("T.03", worksheet.intermediate_output_c9); end
  def test_intermediate_output_d9; assert_equal("Domestic aviation", worksheet.intermediate_output_d9); end
  def test_intermediate_output_ax9; assert_in_epsilon(43.93691483268497, worksheet.intermediate_output_ax9, 0.002); end
  def test_intermediate_output_ay9; assert_in_epsilon(53.18352397905861, worksheet.intermediate_output_ay9, 0.002); end
  def test_intermediate_output_az9; assert_in_epsilon(62.6729650163865, worksheet.intermediate_output_az9, 0.002); end
  def test_intermediate_output_ba9; assert_in_epsilon(73.2216498454846, worksheet.intermediate_output_ba9, 0.002); end
  def test_intermediate_output_bb9; assert_in_epsilon(84.94288870759283, worksheet.intermediate_output_bb9, 0.002); end
  def test_intermediate_output_bc9; assert_in_epsilon(97.95983266912596, worksheet.intermediate_output_bc9, 0.002); end
  def test_intermediate_output_bd9; assert_in_epsilon(109.69157942758852, worksheet.intermediate_output_bd9, 0.002); end
  def test_intermediate_output_be9; assert_in_epsilon(122.30026212648575, worksheet.intermediate_output_be9, 0.002); end
  def test_intermediate_output_bf9; assert_in_epsilon(135.84868079660447, worksheet.intermediate_output_bf9, 0.002); end
  def test_intermediate_output_c10; assert_equal("T.04", worksheet.intermediate_output_c10); end
  def test_intermediate_output_d10; assert_equal("Berge", worksheet.intermediate_output_d10); end
  def test_intermediate_output_ax10; assert_in_delta(0.0, (worksheet.intermediate_output_ax10||0), 0.002); end
  def test_intermediate_output_ay10; assert_in_delta(1.2059144801278183e-13, worksheet.intermediate_output_ay10, 0.002); end
  def test_intermediate_output_az10; assert_in_delta(2.4118289602556366e-13, worksheet.intermediate_output_az10, 0.002); end
  def test_intermediate_output_ba10; assert_in_delta(3.6177434403834546e-13, worksheet.intermediate_output_ba10, 0.002); end
  def test_intermediate_output_bb10; assert_in_delta(4.823657920511273e-13, worksheet.intermediate_output_bb10, 0.002); end
  def test_intermediate_output_bc10; assert_in_delta(6.029572400639091e-13, worksheet.intermediate_output_bc10, 0.002); end
  def test_intermediate_output_bd10; assert_in_delta(7.23548688076691e-13, worksheet.intermediate_output_bd10, 0.002); end
  def test_intermediate_output_be10; assert_in_delta(8.441401360894729e-13, worksheet.intermediate_output_be10, 0.002); end
  def test_intermediate_output_bf10; assert_in_delta(9.647315841022546e-13, worksheet.intermediate_output_bf10, 0.002); end
  def test_intermediate_output_c11; assert_equal("T.07", worksheet.intermediate_output_c11); end
  def test_intermediate_output_d11; assert_equal("Pipeline", worksheet.intermediate_output_d11); end
  def test_intermediate_output_ax11; assert_in_epsilon(1.0449356110119832, worksheet.intermediate_output_ax11, 0.002); end
  def test_intermediate_output_ay11; assert_in_epsilon(2.2204881734004642, worksheet.intermediate_output_ay11, 0.002); end
  def test_intermediate_output_az11; assert_in_epsilon(3.3960407357889455, worksheet.intermediate_output_az11, 0.002); end
  def test_intermediate_output_ba11; assert_in_epsilon(4.571593298177427, worksheet.intermediate_output_ba11, 0.002); end
  def test_intermediate_output_bb11; assert_in_epsilon(5.747145860565908, worksheet.intermediate_output_bb11, 0.002); end
  def test_intermediate_output_bc11; assert_in_epsilon(6.922698422954389, worksheet.intermediate_output_bc11, 0.002); end
  def test_intermediate_output_bd11; assert_in_epsilon(8.09825098534287, worksheet.intermediate_output_bd11, 0.002); end
  def test_intermediate_output_be11; assert_in_epsilon(9.273803547731351, worksheet.intermediate_output_be11, 0.002); end
  def test_intermediate_output_bf11; assert_in_epsilon(10.449356110119831, worksheet.intermediate_output_bf11, 0.002); end
  def test_intermediate_output_d12; assert_equal("Transport", worksheet.intermediate_output_d12); end
  def test_intermediate_output_ax12; assert_in_epsilon(199.91851557151367, worksheet.intermediate_output_ax12, 0.002); end
  def test_intermediate_output_ay12; assert_in_epsilon(303.4932735414058, worksheet.intermediate_output_ay12, 0.002); end
  def test_intermediate_output_az12; assert_in_epsilon(371.6202648672837, worksheet.intermediate_output_az12, 0.002); end
  def test_intermediate_output_ba12; assert_in_epsilon(424.7081640298286, worksheet.intermediate_output_ba12, 0.002); end
  def test_intermediate_output_bb12; assert_in_epsilon(468.04789390876846, worksheet.intermediate_output_bb12, 0.002); end
  def test_intermediate_output_bc12; assert_in_epsilon(516.6215228667696, worksheet.intermediate_output_bc12, 0.002); end
  def test_intermediate_output_bd12; assert_in_epsilon(548.4601921954501, worksheet.intermediate_output_bd12, 0.002); end
  def test_intermediate_output_be12; assert_in_epsilon(576.9071859889108, worksheet.intermediate_output_be12, 0.002); end
  def test_intermediate_output_bf12; assert_in_epsilon(602.4820527459256, worksheet.intermediate_output_bf12, 0.002); end
  def test_intermediate_output_c13; assert_equal("I.01", worksheet.intermediate_output_c13); end
  def test_intermediate_output_d13; assert_equal("Industry", worksheet.intermediate_output_d13); end
  def test_intermediate_output_ax13; assert_in_epsilon(419.3452816939454, worksheet.intermediate_output_ax13, 0.002); end
  def test_intermediate_output_ay13; assert_in_epsilon(394.6885535040981, worksheet.intermediate_output_ay13, 0.002); end
  def test_intermediate_output_az13; assert_in_epsilon(376.1831408693938, worksheet.intermediate_output_az13, 0.002); end
  def test_intermediate_output_ba13; assert_in_epsilon(360.7418114001044, worksheet.intermediate_output_ba13, 0.002); end
  def test_intermediate_output_bb13; assert_in_epsilon(343.6240030035792, worksheet.intermediate_output_bb13, 0.002); end
  def test_intermediate_output_bc13; assert_in_epsilon(327.78034461950114, worksheet.intermediate_output_bc13, 0.002); end
  def test_intermediate_output_bd13; assert_in_epsilon(313.57916869654946, worksheet.intermediate_output_bd13, 0.002); end
  def test_intermediate_output_be13; assert_in_epsilon(301.44872220378954, worksheet.intermediate_output_be13, 0.002); end
  def test_intermediate_output_bf13; assert_in_epsilon(291.886937781592, worksheet.intermediate_output_bf13, 0.002); end
  def test_intermediate_output_c14; assert_equal("H.01", worksheet.intermediate_output_c14); end
  def test_intermediate_output_d14; assert_equal("Cooling", worksheet.intermediate_output_d14); end
  def test_intermediate_output_ax14; assert_in_epsilon(45.23241057567228, worksheet.intermediate_output_ax14, 0.002); end
  def test_intermediate_output_ay14; assert_in_epsilon(51.703504111940035, worksheet.intermediate_output_ay14, 0.002); end
  def test_intermediate_output_az14; assert_in_epsilon(57.87457835156304, worksheet.intermediate_output_az14, 0.002); end
  def test_intermediate_output_ba14; assert_in_epsilon(63.727201941623775, worksheet.intermediate_output_ba14, 0.002); end
  def test_intermediate_output_bb14; assert_in_epsilon(69.24053615847055, worksheet.intermediate_output_bb14, 0.002); end
  def test_intermediate_output_bc14; assert_in_epsilon(74.3911100028562, worksheet.intermediate_output_bc14, 0.002); end
  def test_intermediate_output_bd14; assert_in_epsilon(79.15257722359095, worksheet.intermediate_output_bd14, 0.002); end
  def test_intermediate_output_be14; assert_in_epsilon(83.49545394031607, worksheet.intermediate_output_be14, 0.002); end
  def test_intermediate_output_bf14; assert_in_epsilon(87.38683544379465, worksheet.intermediate_output_bf14, 0.002); end
  def test_intermediate_output_c15; assert_equal("L.01", worksheet.intermediate_output_c15); end
  def test_intermediate_output_d15; assert_equal("Lighting & appliances", worksheet.intermediate_output_d15); end
  def test_intermediate_output_ax15; assert_in_epsilon(30.768996771009306, worksheet.intermediate_output_ax15, 0.002); end
  def test_intermediate_output_ay15; assert_in_epsilon(35.57650882321771, worksheet.intermediate_output_ay15, 0.002); end
  def test_intermediate_output_az15; assert_in_epsilon(60.916030212058686, worksheet.intermediate_output_az15, 0.002); end
  def test_intermediate_output_ba15; assert_in_epsilon(113.04038720981688, worksheet.intermediate_output_ba15, 0.002); end
  def test_intermediate_output_bb15; assert_in_epsilon(165.11175352816792, worksheet.intermediate_output_bb15, 0.002); end
  def test_intermediate_output_bc15; assert_in_epsilon(221.25866219560046, worksheet.intermediate_output_bc15, 0.002); end
  def test_intermediate_output_bd15; assert_in_epsilon(275.69550670830967, worksheet.intermediate_output_bd15, 0.002); end
  def test_intermediate_output_be15; assert_in_epsilon(330.0191898252094, worksheet.intermediate_output_be15, 0.002); end
  def test_intermediate_output_bf15; assert_in_epsilon(385.960842955381, worksheet.intermediate_output_bf15, 0.002); end
  def test_intermediate_output_c16; assert_equal("L.02", worksheet.intermediate_output_c16); end
  def test_intermediate_output_d16; assert_equal("Cooking", worksheet.intermediate_output_d16); end
  def test_intermediate_output_ax16; assert_in_epsilon(239.36058753860928, worksheet.intermediate_output_ax16, 0.002); end
  def test_intermediate_output_ay16; assert_in_epsilon(228.6242461028551, worksheet.intermediate_output_ay16, 0.002); end
  def test_intermediate_output_az16; assert_in_epsilon(216.73381249080103, worksheet.intermediate_output_az16, 0.002); end
  def test_intermediate_output_ba16; assert_in_epsilon(203.06298806371035, worksheet.intermediate_output_ba16, 0.002); end
  def test_intermediate_output_bb16; assert_in_epsilon(187.01392850736747, worksheet.intermediate_output_bb16, 0.002); end
  def test_intermediate_output_bc16; assert_in_epsilon(170.47448017142992, worksheet.intermediate_output_bc16, 0.002); end
  def test_intermediate_output_bd16; assert_in_epsilon(151.60093949023258, worksheet.intermediate_output_bd16, 0.002); end
  def test_intermediate_output_be16; assert_in_epsilon(130.2038283500409, worksheet.intermediate_output_be16, 0.002); end
  def test_intermediate_output_bf16; assert_in_epsilon(106.08041142810023, worksheet.intermediate_output_bf16, 0.002); end
  def test_intermediate_output_d17; assert_equal("Total", worksheet.intermediate_output_d17); end
  def test_intermediate_output_ax17; assert_in_epsilon(934.6257921507498, worksheet.intermediate_output_ax17, 0.002); end
  def test_intermediate_output_ay17; assert_in_epsilon(1014.0860860835168, worksheet.intermediate_output_ay17, 0.002); end
  def test_intermediate_output_az17; assert_in_epsilon(1083.3278267911003, worksheet.intermediate_output_az17, 0.002); end
  def test_intermediate_output_ba17; assert_in_epsilon(1165.2805526450838, worksheet.intermediate_output_ba17, 0.002); end
  def test_intermediate_output_bb17; assert_in_epsilon(1233.0381151063534, worksheet.intermediate_output_bb17, 0.002); end
  def test_intermediate_output_bc17; assert_in_epsilon(1310.5261198561573, worksheet.intermediate_output_bc17, 0.002); end
  def test_intermediate_output_bd17; assert_in_epsilon(1368.4883843141326, worksheet.intermediate_output_bd17, 0.002); end
  def test_intermediate_output_be17; assert_in_epsilon(1422.0743803082669, worksheet.intermediate_output_be17, 0.002); end
  def test_intermediate_output_bf17; assert_in_epsilon(1473.7970803547935, worksheet.intermediate_output_bf17, 0.002); end
  def test_intermediate_output_d19; assert_equal("Dummy for charting uses", worksheet.intermediate_output_d19); end
  def test_intermediate_output_ax19; assert_in_epsilon(2048.7844852219587, worksheet.intermediate_output_ax19, 0.002); end
  def test_intermediate_output_ay19; assert_in_epsilon(2159.4831341629283, worksheet.intermediate_output_ay19, 0.002); end
  def test_intermediate_output_az19; assert_in_epsilon(2376.823991754821, worksheet.intermediate_output_az19, 0.002); end
  def test_intermediate_output_ba19; assert_in_epsilon(2732.639668050483, worksheet.intermediate_output_ba19, 0.002); end
  def test_intermediate_output_bb19; assert_in_epsilon(3122.5725368185244, worksheet.intermediate_output_bb19, 0.002); end
  def test_intermediate_output_bc19; assert_in_epsilon(3504.4639138839, worksheet.intermediate_output_bc19, 0.002); end
  def test_intermediate_output_bd19; assert_in_epsilon(3959.6093918131837, worksheet.intermediate_output_bd19, 0.002); end
  def test_intermediate_output_be19; assert_in_epsilon(4352.919197576534, worksheet.intermediate_output_be19, 0.002); end
  def test_intermediate_output_bf19; assert_in_epsilon(4838.460993045796, worksheet.intermediate_output_bf19, 0.002); end
  def test_intermediate_output_c21; assert_equal("Source", worksheet.intermediate_output_c21); end
  def test_intermediate_output_c22; assert_equal("N.01", worksheet.intermediate_output_c22); end
  def test_intermediate_output_d22; assert_equal("Nuclear fission", worksheet.intermediate_output_d22); end
  def test_intermediate_output_ax22; assert_in_delta(0.0, (worksheet.intermediate_output_ax22||0), 0.002); end
  def test_intermediate_output_ay22; assert_in_delta(0.0, (worksheet.intermediate_output_ay22||0), 0.002); end
  def test_intermediate_output_az22; assert_in_delta(0.0, (worksheet.intermediate_output_az22||0), 0.002); end
  def test_intermediate_output_ba22; assert_in_delta(0.0, (worksheet.intermediate_output_ba22||0), 0.002); end
  def test_intermediate_output_bb22; assert_in_delta(0.0, (worksheet.intermediate_output_bb22||0), 0.002); end
  def test_intermediate_output_bc22; assert_in_delta(0.0, (worksheet.intermediate_output_bc22||0), 0.002); end
  def test_intermediate_output_bd22; assert_in_delta(0.0, (worksheet.intermediate_output_bd22||0), 0.002); end
  def test_intermediate_output_be22; assert_in_delta(0.0, (worksheet.intermediate_output_be22||0), 0.002); end
  def test_intermediate_output_bf22; assert_in_delta(0.0, (worksheet.intermediate_output_bf22||0), 0.002); end
  def test_intermediate_output_c23; assert_equal("R.01", worksheet.intermediate_output_c23); end
  def test_intermediate_output_d23; assert_equal("Solar", worksheet.intermediate_output_d23); end
  def test_intermediate_output_ax23; assert_in_delta(0.027612899999999996, worksheet.intermediate_output_ax23, 0.002); end
  def test_intermediate_output_ay23; assert_in_delta(0.92043, worksheet.intermediate_output_ay23, 0.002); end
  def test_intermediate_output_az23; assert_in_epsilon(2.024946, worksheet.intermediate_output_az23, 0.002); end
  def test_intermediate_output_ba23; assert_in_epsilon(3.1294619999999997, worksheet.intermediate_output_ba23, 0.002); end
  def test_intermediate_output_bb23; assert_in_epsilon(4.233978, worksheet.intermediate_output_bb23, 0.002); end
  def test_intermediate_output_bc23; assert_in_epsilon(5.338494, worksheet.intermediate_output_bc23, 0.002); end
  def test_intermediate_output_bd23; assert_in_epsilon(6.443009999999999, worksheet.intermediate_output_bd23, 0.002); end
  def test_intermediate_output_be23; assert_in_epsilon(7.547526, worksheet.intermediate_output_be23, 0.002); end
  def test_intermediate_output_bf23; assert_in_epsilon(8.652042, worksheet.intermediate_output_bf23, 0.002); end
  def test_intermediate_output_c24; assert_equal("R.02", worksheet.intermediate_output_c24); end
  def test_intermediate_output_d24; assert_equal("Wind", worksheet.intermediate_output_d24); end
  def test_intermediate_output_ax24; assert_in_delta(0.0, (worksheet.intermediate_output_ax24||0), 0.002); end
  def test_intermediate_output_ay24; assert_in_delta(0.0, (worksheet.intermediate_output_ay24||0), 0.002); end
  def test_intermediate_output_az24; assert_in_delta(0.017532, worksheet.intermediate_output_az24, 0.002); end
  def test_intermediate_output_ba24; assert_in_delta(0.017532, worksheet.intermediate_output_ba24, 0.002); end
  def test_intermediate_output_bb24; assert_in_delta(0.017532, worksheet.intermediate_output_bb24, 0.002); end
  def test_intermediate_output_bc24; assert_in_delta(0.017532, worksheet.intermediate_output_bc24, 0.002); end
  def test_intermediate_output_bd24; assert_in_delta(0.017532, worksheet.intermediate_output_bd24, 0.002); end
  def test_intermediate_output_be24; assert_in_delta(0.017532, worksheet.intermediate_output_be24, 0.002); end
  def test_intermediate_output_bf24; assert_in_delta(0.017532, worksheet.intermediate_output_bf24, 0.002); end
  def test_intermediate_output_c25; assert_equal("R.06", worksheet.intermediate_output_c25); end
  def test_intermediate_output_d25; assert_equal("Hydro", worksheet.intermediate_output_d25); end
  def test_intermediate_output_ax25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_ax25, 0.002); end
  def test_intermediate_output_ay25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_ay25, 0.002); end
  def test_intermediate_output_az25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_az25, 0.002); end
  def test_intermediate_output_ba25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_ba25, 0.002); end
  def test_intermediate_output_bb25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_bb25, 0.002); end
  def test_intermediate_output_bc25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_bc25, 0.002); end
  def test_intermediate_output_bd25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_bd25, 0.002); end
  def test_intermediate_output_be25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_be25, 0.002); end
  def test_intermediate_output_bf25; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_bf25, 0.002); end
  def test_intermediate_output_c26; assert_equal("Y.02", worksheet.intermediate_output_c26); end
  def test_intermediate_output_d26; assert_equal("Electricity oversupply (imports)", worksheet.intermediate_output_d26); end
  def test_intermediate_output_ax26; assert_in_delta(-0.525, worksheet.intermediate_output_ax26, 0.002); end
  def test_intermediate_output_ay26; assert_in_delta(-0.525, worksheet.intermediate_output_ay26, 0.002); end
  def test_intermediate_output_az26; assert_in_delta(-0.5250000000000284, worksheet.intermediate_output_az26, 0.002); end
  def test_intermediate_output_ba26; assert_in_delta(-0.5249999999999716, worksheet.intermediate_output_ba26, 0.002); end
  def test_intermediate_output_bb26; assert_in_delta(-0.5250000000000569, worksheet.intermediate_output_bb26, 0.002); end
  def test_intermediate_output_bc26; assert_in_delta(-0.525, worksheet.intermediate_output_bc26, 0.002); end
  def test_intermediate_output_bd26; assert_in_delta(-0.525, worksheet.intermediate_output_bd26, 0.002); end
  def test_intermediate_output_be26; assert_in_delta(-0.5249999999998863, worksheet.intermediate_output_be26, 0.002); end
  def test_intermediate_output_bf26; assert_in_delta(-0.525, worksheet.intermediate_output_bf26, 0.002); end
  def test_intermediate_output_d27; assert_equal("Primary electricity, solar, marine, and net imports", worksheet.intermediate_output_d27); end
  def test_intermediate_output_ax27; assert_in_epsilon(9.776364899999997, worksheet.intermediate_output_ax27, 0.002); end
  def test_intermediate_output_ay27; assert_in_epsilon(10.669181999999998, worksheet.intermediate_output_ay27, 0.002); end
  def test_intermediate_output_az27; assert_in_epsilon(11.791229999999969, worksheet.intermediate_output_az27, 0.002); end
  def test_intermediate_output_ba27; assert_in_epsilon(12.895746000000026, worksheet.intermediate_output_ba27, 0.002); end
  def test_intermediate_output_bb27; assert_in_epsilon(14.00026199999994, worksheet.intermediate_output_bb27, 0.002); end
  def test_intermediate_output_bc27; assert_in_epsilon(15.104777999999998, worksheet.intermediate_output_bc27, 0.002); end
  def test_intermediate_output_bd27; assert_in_epsilon(16.209294, worksheet.intermediate_output_bd27, 0.002); end
  def test_intermediate_output_be27; assert_in_epsilon(17.313810000000114, worksheet.intermediate_output_be27, 0.002); end
  def test_intermediate_output_bf27; assert_in_epsilon(18.418326, worksheet.intermediate_output_bf27, 0.002); end
  def test_intermediate_output_c28; assert_equal("W.01", worksheet.intermediate_output_c28); end
  def test_intermediate_output_d28; assert_equal("Waste", worksheet.intermediate_output_d28); end
  def test_intermediate_output_ax28; assert_in_epsilon(145.41413414177472, worksheet.intermediate_output_ax28, 0.002); end
  def test_intermediate_output_ay28; assert_in_epsilon(156.81570752508804, worksheet.intermediate_output_ay28, 0.002); end
  def test_intermediate_output_az28; assert_in_epsilon(180.11491586581025, worksheet.intermediate_output_az28, 0.002); end
  def test_intermediate_output_ba28; assert_in_epsilon(189.35865450777544, worksheet.intermediate_output_ba28, 0.002); end
  def test_intermediate_output_bb28; assert_in_epsilon(200.00050542033634, worksheet.intermediate_output_bb28, 0.002); end
  def test_intermediate_output_bc28; assert_in_epsilon(211.16847271821533, worksheet.intermediate_output_bc28, 0.002); end
  def test_intermediate_output_bd28; assert_in_epsilon(222.56390255411034, worksheet.intermediate_output_bd28, 0.002); end
  def test_intermediate_output_be28; assert_in_epsilon(234.8137433236491, worksheet.intermediate_output_be28, 0.002); end
  def test_intermediate_output_bf28; assert_in_epsilon(247.37415359400322, worksheet.intermediate_output_bf28, 0.002); end
  def test_intermediate_output_c29; assert_equal("A.01", worksheet.intermediate_output_c29); end
  def test_intermediate_output_d29; assert_equal("Agriculture", worksheet.intermediate_output_d29); end
  def test_intermediate_output_ax29; assert_in_epsilon(1673.2261104444444, worksheet.intermediate_output_ax29, 0.002); end
  def test_intermediate_output_ay29; assert_in_epsilon(1694.9297948543515, worksheet.intermediate_output_ay29, 0.002); end
  def test_intermediate_output_az29; assert_in_epsilon(1716.9580723344359, worksheet.intermediate_output_az29, 0.002); end
  def test_intermediate_output_ba29; assert_in_epsilon(1739.3189670718818, worksheet.intermediate_output_ba29, 0.002); end
  def test_intermediate_output_bb29; assert_in_epsilon(1762.020903928343, worksheet.intermediate_output_bb29, 0.002); end
  def test_intermediate_output_bc29; assert_in_epsilon(1785.0727362590028, worksheet.intermediate_output_bc29, 0.002); end
  def test_intermediate_output_bd29; assert_in_epsilon(1808.4837758124831, worksheet.intermediate_output_bd29, 0.002); end
  def test_intermediate_output_be29; assert_in_epsilon(1832.263824869275, worksheet.intermediate_output_be29, 0.002); end
  def test_intermediate_output_bf29; assert_in_epsilon(1856.4232107883859, worksheet.intermediate_output_bf29, 0.002); end
  def test_intermediate_output_c30; assert_equal("Y.01", worksheet.intermediate_output_c30); end
  def test_intermediate_output_d30; assert_equal("Biomass oversupply (imports)", worksheet.intermediate_output_d30); end
  def test_intermediate_output_ax30; assert_in_epsilon(-43.20605675888887, worksheet.intermediate_output_ax30, 0.002); end
  def test_intermediate_output_ay30; assert_in_epsilon(-74.20454882342571, worksheet.intermediate_output_ay30, 0.002); end
  def test_intermediate_output_az30; assert_in_epsilon(-104.2038739323995, worksheet.intermediate_output_az30, 0.002); end
  def test_intermediate_output_ba30; assert_in_epsilon(-110.52796594136234, worksheet.intermediate_output_ba30, 0.002); end
  def test_intermediate_output_bb30; assert_in_epsilon(-139.06652641106615, worksheet.intermediate_output_bb30, 0.002); end
  def test_intermediate_output_bc30; assert_in_epsilon(-166.7857184755695, worksheet.intermediate_output_bc30, 0.002); end
  def test_intermediate_output_bd30; assert_in_epsilon(-192.94563745217883, worksheet.intermediate_output_bd30, 0.002); end
  def test_intermediate_output_be30; assert_in_epsilon(-216.6381265026923, worksheet.intermediate_output_be30, 0.002); end
  def test_intermediate_output_bf30; assert_in_epsilon(-237.64506958709, worksheet.intermediate_output_bf30, 0.002); end
  def test_intermediate_output_d31; assert_equal("Agriculture, waste, and biomatter imports", worksheet.intermediate_output_d31); end
  def test_intermediate_output_ax31; assert_in_epsilon(1775.43418782733, worksheet.intermediate_output_ax31, 0.002); end
  def test_intermediate_output_ay31; assert_in_epsilon(1777.5409535560138, worksheet.intermediate_output_ay31, 0.002); end
  def test_intermediate_output_az31; assert_in_epsilon(1792.8691142678465, worksheet.intermediate_output_az31, 0.002); end
  def test_intermediate_output_ba31; assert_in_epsilon(1818.149655638295, worksheet.intermediate_output_ba31, 0.002); end
  def test_intermediate_output_bb31; assert_in_epsilon(1822.954882937613, worksheet.intermediate_output_bb31, 0.002); end
  def test_intermediate_output_bc31; assert_in_epsilon(1829.4554905016487, worksheet.intermediate_output_bc31, 0.002); end
  def test_intermediate_output_bd31; assert_in_epsilon(1838.1020409144148, worksheet.intermediate_output_bd31, 0.002); end
  def test_intermediate_output_be31; assert_in_epsilon(1850.4394416902317, worksheet.intermediate_output_be31, 0.002); end
  def test_intermediate_output_bf31; assert_in_epsilon(1866.152294795299, worksheet.intermediate_output_bf31, 0.002); end
  def test_intermediate_output_c32; assert_equal("Y.04", worksheet.intermediate_output_c32); end
  def test_intermediate_output_d32; assert_equal("Coal oversupply (imports)", worksheet.intermediate_output_d32); end
  def test_intermediate_output_ax32; assert_in_epsilon(-10.095739339406668, worksheet.intermediate_output_ax32, 0.002); end
  def test_intermediate_output_ay32; assert_in_epsilon(-10.952960668990002, worksheet.intermediate_output_ay32, 0.002); end
  def test_intermediate_output_az32; assert_in_epsilon(-13.010804441073336, worksheet.intermediate_output_az32, 0.002); end
  def test_intermediate_output_ba32; assert_in_epsilon(-190.97932680458368, worksheet.intermediate_output_ba32, 0.002); end
  def test_intermediate_output_bb32; assert_in_epsilon(-375.46912199999963, worksheet.intermediate_output_bb32, 0.002); end
  def test_intermediate_output_bc32; assert_in_epsilon(-560.01349104, worksheet.intermediate_output_bc32, 0.002); end
  def test_intermediate_output_bd32; assert_in_epsilon(-744.4282186933336, worksheet.intermediate_output_bd32, 0.002); end
  def test_intermediate_output_be32; assert_in_epsilon(-928.9437182933331, worksheet.intermediate_output_be32, 0.002); end
  def test_intermediate_output_bf32; assert_in_epsilon(-1113.45838984, worksheet.intermediate_output_bf32, 0.002); end
  def test_intermediate_output_c33; assert_equal("Q.01", worksheet.intermediate_output_c33); end
  def test_intermediate_output_d33; assert_equal("Coal reserves", worksheet.intermediate_output_d33); end
  def test_intermediate_output_ax33; assert_in_epsilon(6.17215067274, worksheet.intermediate_output_ax33, 0.002); end
  def test_intermediate_output_ay33; assert_in_epsilon(6.17215067274, worksheet.intermediate_output_ay33, 0.002); end
  def test_intermediate_output_az33; assert_in_epsilon(7.17215067274, worksheet.intermediate_output_az33, 0.002); end
  def test_intermediate_output_ba33; assert_in_epsilon(184.166666666667, worksheet.intermediate_output_ba33, 0.002); end
  def test_intermediate_output_bb33; assert_in_epsilon(367.333333333333, worksheet.intermediate_output_bb33, 0.002); end
  def test_intermediate_output_bc33; assert_in_epsilon(550.5, worksheet.intermediate_output_bc33, 0.002); end
  def test_intermediate_output_bd33; assert_in_epsilon(733.666666666667, worksheet.intermediate_output_bd33, 0.002); end
  def test_intermediate_output_be33; assert_in_epsilon(916.833333333333, worksheet.intermediate_output_be33, 0.002); end
  def test_intermediate_output_bf33; assert_in_epsilon(1100.0, worksheet.intermediate_output_bf33, 0.002); end
  def test_intermediate_output_d34; assert_equal("Coal", worksheet.intermediate_output_d34); end
  def test_intermediate_output_ax34; assert_in_epsilon(-3.923588666666668, worksheet.intermediate_output_ax34, 0.002); end
  def test_intermediate_output_ay34; assert_in_epsilon(-4.780809996250002, worksheet.intermediate_output_ay34, 0.002); end
  def test_intermediate_output_az34; assert_in_epsilon(-5.838653768333336, worksheet.intermediate_output_az34, 0.002); end
  def test_intermediate_output_ba34; assert_in_epsilon(-6.81266013791668, worksheet.intermediate_output_ba34, 0.002); end
  def test_intermediate_output_bb34; assert_in_epsilon(-8.135788666666656, worksheet.intermediate_output_bb34, 0.002); end
  def test_intermediate_output_bc34; assert_in_epsilon(-9.513491039999963, worksheet.intermediate_output_bc34, 0.002); end
  def test_intermediate_output_bd34; assert_in_epsilon(-10.761552026666664, worksheet.intermediate_output_bd34, 0.002); end
  def test_intermediate_output_be34; assert_in_epsilon(-12.110384960000033, worksheet.intermediate_output_be34, 0.002); end
  def test_intermediate_output_bf34; assert_in_epsilon(-13.458389840000109, worksheet.intermediate_output_bf34, 0.002); end
  def test_intermediate_output_c35; assert_equal("Q.02", worksheet.intermediate_output_c35); end
  def test_intermediate_output_d35; assert_equal("Oil reserves", worksheet.intermediate_output_d35); end
  def test_intermediate_output_ax35; assert_in_epsilon(1458.9378638800001, worksheet.intermediate_output_ax35, 0.002); end
  def test_intermediate_output_ay35; assert_in_epsilon(1458.9378638800001, worksheet.intermediate_output_ay35, 0.002); end
  def test_intermediate_output_az35; assert_in_epsilon(1479.779833364, worksheet.intermediate_output_az35, 0.002); end
  def test_intermediate_output_ba35; assert_in_epsilon(1500.621802848, worksheet.intermediate_output_ba35, 0.002); end
  def test_intermediate_output_bb35; assert_in_epsilon(1521.463772332, worksheet.intermediate_output_bb35, 0.002); end
  def test_intermediate_output_bc35; assert_in_epsilon(1542.3057418160001, worksheet.intermediate_output_bc35, 0.002); end
  def test_intermediate_output_bd35; assert_in_epsilon(1563.1477113, worksheet.intermediate_output_bd35, 0.002); end
  def test_intermediate_output_be35; assert_in_epsilon(1583.989680784, worksheet.intermediate_output_be35, 0.002); end
  def test_intermediate_output_bf35; assert_in_epsilon(1604.831650268, worksheet.intermediate_output_bf35, 0.002); end
  def test_intermediate_output_c36; assert_equal("Y.05", worksheet.intermediate_output_c36); end
  def test_intermediate_output_d36; assert_equal("Oil and petroleum products oversupply (imports)", worksheet.intermediate_output_d36); end
  def test_intermediate_output_ax36; assert_in_epsilon(-669.4248340116129, worksheet.intermediate_output_ax36, 0.002); end
  def test_intermediate_output_ay36; assert_in_epsilon(-466.34638345802614, worksheet.intermediate_output_ay36, 0.002); end
  def test_intermediate_output_az36; assert_in_epsilon(-197.27637538044314, worksheet.intermediate_output_az36, 0.002); end
  def test_intermediate_output_ba36; assert_in_epsilon(206.28582618424866, worksheet.intermediate_output_ba36, 0.002); end
  def test_intermediate_output_bb36; assert_in_epsilon(649.5752775678864, worksheet.intermediate_output_bb36, 0.002); end
  def test_intermediate_output_bc36; assert_in_epsilon(1094.6711528846922, worksheet.intermediate_output_bc36, 0.002); end
  def test_intermediate_output_bd36; assert_in_epsilon(1592.796395209667, worksheet.intermediate_output_bd36, 0.002); end
  def test_intermediate_output_be36; assert_in_epsilon(2024.2411218643847, worksheet.intermediate_output_be36, 0.002); end
  def test_intermediate_output_bf36; assert_in_epsilon(2544.2343037759847, worksheet.intermediate_output_bf36, 0.002); end
  def test_intermediate_output_c37; assert_equal("Y.03", worksheet.intermediate_output_c37); end
  def test_intermediate_output_d37; assert_equal("Petroleum products oversupply", worksheet.intermediate_output_d37); end
  def test_intermediate_output_ax37; assert_in_delta(0.0, (worksheet.intermediate_output_ax37||0), 0.002); end
  def test_intermediate_output_ay37; assert_in_delta(0.0, (worksheet.intermediate_output_ay37||0), 0.002); end
  def test_intermediate_output_az37; assert_in_delta(0.0, (worksheet.intermediate_output_az37||0), 0.002); end
  def test_intermediate_output_ba37; assert_in_delta(0.0, (worksheet.intermediate_output_ba37||0), 0.002); end
  def test_intermediate_output_bb37; assert_in_delta(0.0, (worksheet.intermediate_output_bb37||0), 0.002); end
  def test_intermediate_output_bc37; assert_in_delta(0.0, (worksheet.intermediate_output_bc37||0), 0.002); end
  def test_intermediate_output_bd37; assert_in_delta(0.0, (worksheet.intermediate_output_bd37||0), 0.002); end
  def test_intermediate_output_be37; assert_in_delta(0.0, (worksheet.intermediate_output_be37||0), 0.002); end
  def test_intermediate_output_bf37; assert_in_delta(0.0, (worksheet.intermediate_output_bf37||0), 0.002); end
  def test_intermediate_output_d38; assert_equal("Oil and petroleum products", worksheet.intermediate_output_d38); end
  def test_intermediate_output_ax38; assert_in_epsilon(789.5130298683872, worksheet.intermediate_output_ax38, 0.002); end
  def test_intermediate_output_ay38; assert_in_epsilon(992.591480421974, worksheet.intermediate_output_ay38, 0.002); end
  def test_intermediate_output_az38; assert_in_epsilon(1282.503457983557, worksheet.intermediate_output_az38, 0.002); end
  def test_intermediate_output_ba38; assert_in_epsilon(1706.9076290322487, worksheet.intermediate_output_ba38, 0.002); end
  def test_intermediate_output_bb38; assert_in_epsilon(2171.0390498998863, worksheet.intermediate_output_bb38, 0.002); end
  def test_intermediate_output_bc38; assert_in_epsilon(2636.9768947006924, worksheet.intermediate_output_bc38, 0.002); end
  def test_intermediate_output_bd38; assert_in_epsilon(3155.944106509667, worksheet.intermediate_output_bd38, 0.002); end
  def test_intermediate_output_be38; assert_in_epsilon(3608.2308026483847, worksheet.intermediate_output_be38, 0.002); end
  def test_intermediate_output_bf38; assert_in_epsilon(4149.065954043985, worksheet.intermediate_output_bf38, 0.002); end
  def test_intermediate_output_c39; assert_equal("Y.06", worksheet.intermediate_output_c39); end
  def test_intermediate_output_d39; assert_equal("Gas oversupply (imports)", worksheet.intermediate_output_d39); end
  def test_intermediate_output_ax39; assert_in_epsilon(-348.8218276674533, worksheet.intermediate_output_ax39, 0.002); end
  def test_intermediate_output_ay39; assert_in_epsilon(-447.37191906862574, worksheet.intermediate_output_ay39, 0.002); end
  def test_intermediate_output_az39; assert_in_epsilon(-572.7717108895299, worksheet.intermediate_output_az39, 0.002); end
  def test_intermediate_output_ba39; assert_in_epsilon(-691.4965784084875, worksheet.intermediate_output_ba39, 0.002); end
  def test_intermediate_output_bb39; assert_in_epsilon(-809.2022304364342, worksheet.intermediate_output_bb39, 0.002); end
  def test_intermediate_output_bc39; assert_in_epsilon(-928.6661622318034, worksheet.intermediate_output_bc39, 0.002); end
  def test_intermediate_output_bd39; assert_in_epsilon(-1049.706684698673, worksheet.intermediate_output_bd39, 0.002); end
  def test_intermediate_output_be39; assert_in_epsilon(-1173.868710541429, worksheet.intermediate_output_be39, 0.002); end
  def test_intermediate_output_bf39; assert_in_epsilon(-1299.586778265361, worksheet.intermediate_output_bf39, 0.002); end
  def test_intermediate_output_c40; assert_equal("Q.03", worksheet.intermediate_output_c40); end
  def test_intermediate_output_d40; assert_equal("Gas reserves", worksheet.intermediate_output_d40); end
  def test_intermediate_output_ax40; assert_in_epsilon(761.432111111111, worksheet.intermediate_output_ax40, 0.002); end
  def test_intermediate_output_ay40; assert_in_epsilon(844.9203333333334, worksheet.intermediate_output_ay40, 0.002); end
  def test_intermediate_output_az40; assert_in_epsilon(951.5983809523813, worksheet.intermediate_output_az40, 0.002); end
  def test_intermediate_output_ba40; assert_in_epsilon(1058.2764285714281, worksheet.intermediate_output_ba40, 0.002); end
  def test_intermediate_output_bb40; assert_in_epsilon(1164.9544761904792, worksheet.intermediate_output_bb40, 0.002); end
  def test_intermediate_output_bc40; assert_in_epsilon(1271.6325238095208, worksheet.intermediate_output_bc40, 0.002); end
  def test_intermediate_output_bd40; assert_in_epsilon(1378.310571428573, worksheet.intermediate_output_bd40, 0.002); end
  def test_intermediate_output_be40; assert_in_epsilon(1484.9886190476143, worksheet.intermediate_output_be40, 0.002); end
  def test_intermediate_output_bf40; assert_in_epsilon(1591.6666666666665, worksheet.intermediate_output_bf40, 0.002); end
  def test_intermediate_output_d41; assert_equal("Natural gas", worksheet.intermediate_output_d41); end
  def test_intermediate_output_ax41; assert_in_epsilon(412.6102834436577, worksheet.intermediate_output_ax41, 0.002); end
  def test_intermediate_output_ay41; assert_in_epsilon(397.5484142647076, worksheet.intermediate_output_ay41, 0.002); end
  def test_intermediate_output_az41; assert_in_epsilon(378.82667006285135, worksheet.intermediate_output_az41, 0.002); end
  def test_intermediate_output_ba41; assert_in_epsilon(366.77985016294065, worksheet.intermediate_output_ba41, 0.002); end
  def test_intermediate_output_bb41; assert_in_epsilon(355.752245754045, worksheet.intermediate_output_bb41, 0.002); end
  def test_intermediate_output_bc41; assert_in_epsilon(342.9663615777174, worksheet.intermediate_output_bc41, 0.002); end
  def test_intermediate_output_bd41; assert_in_epsilon(328.60388672990007, worksheet.intermediate_output_bd41, 0.002); end
  def test_intermediate_output_be41; assert_in_epsilon(311.1199085061853, worksheet.intermediate_output_be41, 0.002); end
  def test_intermediate_output_bf41; assert_in_epsilon(292.0798884013054, worksheet.intermediate_output_bf41, 0.002); end
  def test_intermediate_output_d42; assert_equal("Total Primary Supply", worksheet.intermediate_output_d42); end
  def test_intermediate_output_ax42; assert_in_epsilon(2983.4102773727086, worksheet.intermediate_output_ax42, 0.002); end
  def test_intermediate_output_ay42; assert_in_epsilon(3173.569220246445, worksheet.intermediate_output_ay42, 0.002); end
  def test_intermediate_output_az42; assert_in_epsilon(3460.1518185459213, worksheet.intermediate_output_az42, 0.002); end
  def test_intermediate_output_ba42; assert_in_epsilon(3897.920220695567, worksheet.intermediate_output_ba42, 0.002); end
  def test_intermediate_output_bb42; assert_in_epsilon(4355.610651924878, worksheet.intermediate_output_bb42, 0.002); end
  def test_intermediate_output_bc42; assert_in_epsilon(4814.990033740058, worksheet.intermediate_output_bc42, 0.002); end
  def test_intermediate_output_bd42; assert_in_epsilon(5328.097776127316, worksheet.intermediate_output_bd42, 0.002); end
  def test_intermediate_output_be42; assert_in_epsilon(5774.993577884801, worksheet.intermediate_output_be42, 0.002); end
  def test_intermediate_output_bf42; assert_in_epsilon(6312.25807340059, worksheet.intermediate_output_bf42, 0.002); end
  def test_intermediate_output_d44; assert_equal("Dummy for charting supply", worksheet.intermediate_output_d44); end
  def test_intermediate_output_ax44; assert_in_delta(0.0, (worksheet.intermediate_output_ax44||0), 0.002); end
  def test_intermediate_output_ay44; assert_in_delta(0.0, (worksheet.intermediate_output_ay44||0), 0.002); end
  def test_intermediate_output_az44; assert_in_delta(0.0, (worksheet.intermediate_output_az44||0), 0.002); end
  def test_intermediate_output_ba44; assert_in_delta(0.0, (worksheet.intermediate_output_ba44||0), 0.002); end
  def test_intermediate_output_bb44; assert_in_delta(0.0, (worksheet.intermediate_output_bb44||0), 0.002); end
  def test_intermediate_output_bc44; assert_in_delta(0.0, (worksheet.intermediate_output_bc44||0), 0.002); end
  def test_intermediate_output_bd44; assert_in_delta(0.0, (worksheet.intermediate_output_bd44||0), 0.002); end
  def test_intermediate_output_be44; assert_in_delta(0.0, (worksheet.intermediate_output_be44||0), 0.002); end
  def test_intermediate_output_bf44; assert_in_delta(0.0, (worksheet.intermediate_output_bf44||0), 0.002); end
  def test_intermediate_output_c46; assert_equal("Conversion losses, distribution, and own use", worksheet.intermediate_output_c46); end
  def test_intermediate_output_c47; assert_equal("X.01", worksheet.intermediate_output_c47); end
  def test_intermediate_output_d47; assert_equal("Conversion losses", worksheet.intermediate_output_d47); end
  def test_intermediate_output_ax47; assert_in_epsilon(2012.9609230310703, worksheet.intermediate_output_ax47, 0.002); end
  def test_intermediate_output_ay47; assert_in_epsilon(2119.5407459795406, worksheet.intermediate_output_ay47, 0.002); end
  def test_intermediate_output_az47; assert_in_epsilon(2332.6839196398078, worksheet.intermediate_output_az47, 0.002); end
  def test_intermediate_output_ba47; assert_in_epsilon(2674.6297012355144, worksheet.intermediate_output_ba47, 0.002); end
  def test_intermediate_output_bb47; assert_in_epsilon(3050.663814660592, worksheet.intermediate_output_bb47, 0.002); end
  def test_intermediate_output_bc47; assert_in_epsilon(3432.5059887788134, worksheet.intermediate_output_bc47, 0.002); end
  def test_intermediate_output_bd47; assert_in_epsilon(3873.8805257515896, worksheet.intermediate_output_bd47, 0.002); end
  def test_intermediate_output_be47; assert_in_epsilon(4268.633304080153, worksheet.intermediate_output_be47, 0.002); end
  def test_intermediate_output_bf47; assert_in_epsilon(4741.735929806991, worksheet.intermediate_output_bf47, 0.002); end
  def test_intermediate_output_c48; assert_equal("X.02", worksheet.intermediate_output_c48); end
  def test_intermediate_output_d48; assert_equal("Distribution losses and own use", worksheet.intermediate_output_d48); end
  def test_intermediate_output_ax48; assert_in_epsilon(35.823562190888445, worksheet.intermediate_output_ax48, 0.002); end
  def test_intermediate_output_ay48; assert_in_epsilon(39.94238818338799, worksheet.intermediate_output_ay48, 0.002); end
  def test_intermediate_output_az48; assert_in_epsilon(44.14007211501328, worksheet.intermediate_output_az48, 0.002); end
  def test_intermediate_output_ba48; assert_in_epsilon(58.009966814969104, worksheet.intermediate_output_ba48, 0.002); end
  def test_intermediate_output_bb48; assert_in_epsilon(71.90872215793208, worksheet.intermediate_output_bb48, 0.002); end
  def test_intermediate_output_bc48; assert_in_epsilon(71.95792510508761, worksheet.intermediate_output_bc48, 0.002); end
  def test_intermediate_output_bd48; assert_in_epsilon(85.72886606159217, worksheet.intermediate_output_bd48, 0.002); end
  def test_intermediate_output_be48; assert_in_epsilon(84.28589349638149, worksheet.intermediate_output_be48, 0.002); end
  def test_intermediate_output_bf48; assert_in_epsilon(96.72506323880367, worksheet.intermediate_output_bf48, 0.002); end
  def test_intermediate_output_d49; assert_equal("Supply net of losses", worksheet.intermediate_output_d49); end
  def test_intermediate_output_ax49; assert_in_epsilon(934.6257921507499, worksheet.intermediate_output_ax49, 0.002); end
  def test_intermediate_output_ay49; assert_in_epsilon(1014.0860860835164, worksheet.intermediate_output_ay49, 0.002); end
  def test_intermediate_output_az49; assert_in_epsilon(1083.3278267911, worksheet.intermediate_output_az49, 0.002); end
  def test_intermediate_output_ba49; assert_in_epsilon(1165.2805526450834, worksheet.intermediate_output_ba49, 0.002); end
  def test_intermediate_output_bb49; assert_in_epsilon(1233.0381151063539, worksheet.intermediate_output_bb49, 0.002); end
  def test_intermediate_output_bc49; assert_in_epsilon(1310.5261198561566, worksheet.intermediate_output_bc49, 0.002); end
  def test_intermediate_output_bd49; assert_in_epsilon(1368.4883843141342, worksheet.intermediate_output_bd49, 0.002); end
  def test_intermediate_output_be49; assert_in_epsilon(1422.0743803082669, worksheet.intermediate_output_be49, 0.002); end
  def test_intermediate_output_bf49; assert_in_epsilon(1473.7970803547942, worksheet.intermediate_output_bf49, 0.002); end
  def test_intermediate_output_c51; assert_equal("Supply / demand not accounted for", worksheet.intermediate_output_c51); end
  def test_intermediate_output_c53; assert_equal("C.01", worksheet.intermediate_output_c53); end
  def test_intermediate_output_d53; assert_equal("Coal and fossil waste", worksheet.intermediate_output_d53); end
  def test_intermediate_output_ax53; assert_in_delta(0.0, (worksheet.intermediate_output_ax53||0), 0.002); end
  def test_intermediate_output_ay53; assert_in_delta(0.0, (worksheet.intermediate_output_ay53||0), 0.002); end
  def test_intermediate_output_az53; assert_in_delta(0.0, (worksheet.intermediate_output_az53||0), 0.002); end
  def test_intermediate_output_ba53; assert_in_delta(0.0, (worksheet.intermediate_output_ba53||0), 0.002); end
  def test_intermediate_output_bb53; assert_in_delta(0.0, (worksheet.intermediate_output_bb53||0), 0.002); end
  def test_intermediate_output_bc53; assert_in_delta(0.0, (worksheet.intermediate_output_bc53||0), 0.002); end
  def test_intermediate_output_bd53; assert_in_delta(0.0, (worksheet.intermediate_output_bd53||0), 0.002); end
  def test_intermediate_output_be53; assert_in_delta(0.0, (worksheet.intermediate_output_be53||0), 0.002); end
  def test_intermediate_output_bf53; assert_in_delta(0.0, (worksheet.intermediate_output_bf53||0), 0.002); end
  def test_intermediate_output_c54; assert_equal("C.02", worksheet.intermediate_output_c54); end
  def test_intermediate_output_d54; assert_equal("Oil and petroleum products", worksheet.intermediate_output_d54); end
  def test_intermediate_output_ax54; assert_in_delta(0.0, (worksheet.intermediate_output_ax54||0), 0.002); end
  def test_intermediate_output_ay54; assert_in_delta(0.0, (worksheet.intermediate_output_ay54||0), 0.002); end
  def test_intermediate_output_az54; assert_in_delta(0.0, (worksheet.intermediate_output_az54||0), 0.002); end
  def test_intermediate_output_ba54; assert_in_delta(0.0, (worksheet.intermediate_output_ba54||0), 0.002); end
  def test_intermediate_output_bb54; assert_in_delta(0.0, (worksheet.intermediate_output_bb54||0), 0.002); end
  def test_intermediate_output_bc54; assert_in_delta(0.0, (worksheet.intermediate_output_bc54||0), 0.002); end
  def test_intermediate_output_bd54; assert_in_delta(0.0, (worksheet.intermediate_output_bd54||0), 0.002); end
  def test_intermediate_output_be54; assert_in_delta(0.0, (worksheet.intermediate_output_be54||0), 0.002); end
  def test_intermediate_output_bf54; assert_in_delta(0.0, (worksheet.intermediate_output_bf54||0), 0.002); end
  def test_intermediate_output_c55; assert_equal("C.03", worksheet.intermediate_output_c55); end
  def test_intermediate_output_d55; assert_equal("Natural gas", worksheet.intermediate_output_d55); end
  def test_intermediate_output_ax55; assert_in_delta(0.0, (worksheet.intermediate_output_ax55||0), 0.002); end
  def test_intermediate_output_ay55; assert_in_delta(0.0, (worksheet.intermediate_output_ay55||0), 0.002); end
  def test_intermediate_output_az55; assert_in_delta(0.0, (worksheet.intermediate_output_az55||0), 0.002); end
  def test_intermediate_output_ba55; assert_in_delta(0.0, (worksheet.intermediate_output_ba55||0), 0.002); end
  def test_intermediate_output_bb55; assert_in_delta(0.0, (worksheet.intermediate_output_bb55||0), 0.002); end
  def test_intermediate_output_bc55; assert_in_delta(0.0, (worksheet.intermediate_output_bc55||0), 0.002); end
  def test_intermediate_output_bd55; assert_in_delta(0.0, (worksheet.intermediate_output_bd55||0), 0.002); end
  def test_intermediate_output_be55; assert_in_delta(0.0, (worksheet.intermediate_output_be55||0), 0.002); end
  def test_intermediate_output_bf55; assert_in_delta(0.0, (worksheet.intermediate_output_bf55||0), 0.002); end
  def test_intermediate_output_c56; assert_equal("V.03", worksheet.intermediate_output_c56); end
  def test_intermediate_output_d56; assert_equal("Solid hydrocarbons", worksheet.intermediate_output_d56); end
  def test_intermediate_output_ax56; assert_in_delta(0.0, (worksheet.intermediate_output_ax56||0), 0.002); end
  def test_intermediate_output_ay56; assert_in_delta(0.0, (worksheet.intermediate_output_ay56||0), 0.002); end
  def test_intermediate_output_az56; assert_in_delta(0.0, (worksheet.intermediate_output_az56||0), 0.002); end
  def test_intermediate_output_ba56; assert_in_delta(0.0, (worksheet.intermediate_output_ba56||0), 0.002); end
  def test_intermediate_output_bb56; assert_in_delta(0.0, (worksheet.intermediate_output_bb56||0), 0.002); end
  def test_intermediate_output_bc56; assert_in_delta(0.0, (worksheet.intermediate_output_bc56||0), 0.002); end
  def test_intermediate_output_bd56; assert_in_delta(0.0, (worksheet.intermediate_output_bd56||0), 0.002); end
  def test_intermediate_output_be56; assert_in_delta(0.0, (worksheet.intermediate_output_be56||0), 0.002); end
  def test_intermediate_output_bf56; assert_in_delta(0.0, (worksheet.intermediate_output_bf56||0), 0.002); end
  def test_intermediate_output_c57; assert_equal("V.04", worksheet.intermediate_output_c57); end
  def test_intermediate_output_d57; assert_equal("Liquid hydrocarbons", worksheet.intermediate_output_d57); end
  def test_intermediate_output_ax57; assert_in_delta(0.0, (worksheet.intermediate_output_ax57||0), 0.002); end
  def test_intermediate_output_ay57; assert_in_delta(0.0, (worksheet.intermediate_output_ay57||0), 0.002); end
  def test_intermediate_output_az57; assert_in_delta(0.0, (worksheet.intermediate_output_az57||0), 0.002); end
  def test_intermediate_output_ba57; assert_in_delta(0.0, (worksheet.intermediate_output_ba57||0), 0.002); end
  def test_intermediate_output_bb57; assert_in_delta(0.0, (worksheet.intermediate_output_bb57||0), 0.002); end
  def test_intermediate_output_bc57; assert_in_delta(0.0, (worksheet.intermediate_output_bc57||0), 0.002); end
  def test_intermediate_output_bd57; assert_in_delta(0.0, (worksheet.intermediate_output_bd57||0), 0.002); end
  def test_intermediate_output_be57; assert_in_delta(0.0, (worksheet.intermediate_output_be57||0), 0.002); end
  def test_intermediate_output_bf57; assert_in_delta(0.0, (worksheet.intermediate_output_bf57||0), 0.002); end
  def test_intermediate_output_c58; assert_equal("V.05", worksheet.intermediate_output_c58); end
  def test_intermediate_output_d58; assert_equal("Gaseous hydrocarbons", worksheet.intermediate_output_d58); end
  def test_intermediate_output_ax58; assert_in_delta(0.0, (worksheet.intermediate_output_ax58||0), 0.002); end
  def test_intermediate_output_ay58; assert_in_delta(0.0, (worksheet.intermediate_output_ay58||0), 0.002); end
  def test_intermediate_output_az58; assert_in_delta(0.0, (worksheet.intermediate_output_az58||0), 0.002); end
  def test_intermediate_output_ba58; assert_in_delta(0.0, (worksheet.intermediate_output_ba58||0), 0.002); end
  def test_intermediate_output_bb58; assert_in_delta(0.0, (worksheet.intermediate_output_bb58||0), 0.002); end
  def test_intermediate_output_bc58; assert_in_delta(0.0, (worksheet.intermediate_output_bc58||0), 0.002); end
  def test_intermediate_output_bd58; assert_in_delta(0.0, (worksheet.intermediate_output_bd58||0), 0.002); end
  def test_intermediate_output_be58; assert_in_delta(0.0, (worksheet.intermediate_output_be58||0), 0.002); end
  def test_intermediate_output_bf58; assert_in_delta(0.0, (worksheet.intermediate_output_bf58||0), 0.002); end
  def test_intermediate_output_c59; assert_equal("V.16", worksheet.intermediate_output_c59); end
  def test_intermediate_output_d59; assert_equal("Traditional Fuel", worksheet.intermediate_output_d59); end
  def test_intermediate_output_ax59; assert_in_delta(0.0, (worksheet.intermediate_output_ax59||0), 0.002); end
  def test_intermediate_output_ay59; assert_in_delta(0.0, (worksheet.intermediate_output_ay59||0), 0.002); end
  def test_intermediate_output_az59; assert_in_delta(0.0, (worksheet.intermediate_output_az59||0), 0.002); end
  def test_intermediate_output_ba59; assert_in_delta(0.0, (worksheet.intermediate_output_ba59||0), 0.002); end
  def test_intermediate_output_bb59; assert_in_delta(0.0, (worksheet.intermediate_output_bb59||0), 0.002); end
  def test_intermediate_output_bc59; assert_in_delta(0.0, (worksheet.intermediate_output_bc59||0), 0.002); end
  def test_intermediate_output_bd59; assert_in_delta(0.0, (worksheet.intermediate_output_bd59||0), 0.002); end
  def test_intermediate_output_be59; assert_in_delta(0.0, (worksheet.intermediate_output_be59||0), 0.002); end
  def test_intermediate_output_bf59; assert_in_delta(0.0, (worksheet.intermediate_output_bf59||0), 0.002); end
  def test_intermediate_output_c60; assert_equal("V.06", worksheet.intermediate_output_c60); end
  def test_intermediate_output_d60; assert_equal("Blast furnace gas", worksheet.intermediate_output_d60); end
  def test_intermediate_output_ax60; assert_in_delta(0.0, (worksheet.intermediate_output_ax60||0), 0.002); end
  def test_intermediate_output_ay60; assert_in_delta(0.0, (worksheet.intermediate_output_ay60||0), 0.002); end
  def test_intermediate_output_az60; assert_in_delta(0.0, (worksheet.intermediate_output_az60||0), 0.002); end
  def test_intermediate_output_ba60; assert_in_delta(0.0, (worksheet.intermediate_output_ba60||0), 0.002); end
  def test_intermediate_output_bb60; assert_in_delta(0.0, (worksheet.intermediate_output_bb60||0), 0.002); end
  def test_intermediate_output_bc60; assert_in_delta(0.0, (worksheet.intermediate_output_bc60||0), 0.002); end
  def test_intermediate_output_bd60; assert_in_delta(0.0, (worksheet.intermediate_output_bd60||0), 0.002); end
  def test_intermediate_output_be60; assert_in_delta(0.0, (worksheet.intermediate_output_be60||0), 0.002); end
  def test_intermediate_output_bf60; assert_in_delta(0.0, (worksheet.intermediate_output_bf60||0), 0.002); end
  def test_intermediate_output_c61; assert_equal("V.08", worksheet.intermediate_output_c61); end
  def test_intermediate_output_d61; assert_equal("Edible biomass", worksheet.intermediate_output_d61); end
  def test_intermediate_output_ax61; assert_in_delta(0.0, (worksheet.intermediate_output_ax61||0), 0.002); end
  def test_intermediate_output_ay61; assert_in_delta(0.0, (worksheet.intermediate_output_ay61||0), 0.002); end
  def test_intermediate_output_az61; assert_in_delta(0.0, (worksheet.intermediate_output_az61||0), 0.002); end
  def test_intermediate_output_ba61; assert_in_delta(0.0, (worksheet.intermediate_output_ba61||0), 0.002); end
  def test_intermediate_output_bb61; assert_in_delta(0.0, (worksheet.intermediate_output_bb61||0), 0.002); end
  def test_intermediate_output_bc61; assert_in_delta(0.0, (worksheet.intermediate_output_bc61||0), 0.002); end
  def test_intermediate_output_bd61; assert_in_delta(0.0, (worksheet.intermediate_output_bd61||0), 0.002); end
  def test_intermediate_output_be61; assert_in_delta(0.0, (worksheet.intermediate_output_be61||0), 0.002); end
  def test_intermediate_output_bf61; assert_in_delta(0.0, (worksheet.intermediate_output_bf61||0), 0.002); end
  def test_intermediate_output_c62; assert_equal("V.09", worksheet.intermediate_output_c62); end
  def test_intermediate_output_d62; assert_equal("Dry biomass and waste", worksheet.intermediate_output_d62); end
  def test_intermediate_output_ax62; assert_in_delta(0.0, (worksheet.intermediate_output_ax62||0), 0.002); end
  def test_intermediate_output_ay62; assert_in_delta(0.0, (worksheet.intermediate_output_ay62||0), 0.002); end
  def test_intermediate_output_az62; assert_in_delta(0.0, (worksheet.intermediate_output_az62||0), 0.002); end
  def test_intermediate_output_ba62; assert_in_delta(0.0, (worksheet.intermediate_output_ba62||0), 0.002); end
  def test_intermediate_output_bb62; assert_in_delta(0.0, (worksheet.intermediate_output_bb62||0), 0.002); end
  def test_intermediate_output_bc62; assert_in_delta(0.0, (worksheet.intermediate_output_bc62||0), 0.002); end
  def test_intermediate_output_bd62; assert_in_delta(0.0, (worksheet.intermediate_output_bd62||0), 0.002); end
  def test_intermediate_output_be62; assert_in_delta(0.0, (worksheet.intermediate_output_be62||0), 0.002); end
  def test_intermediate_output_bf62; assert_in_delta(0.0, (worksheet.intermediate_output_bf62||0), 0.002); end
  def test_intermediate_output_c63; assert_equal("V.10", worksheet.intermediate_output_c63); end
  def test_intermediate_output_d63; assert_equal("Wet biomass and waste", worksheet.intermediate_output_d63); end
  def test_intermediate_output_ax63; assert_in_delta(0.0, (worksheet.intermediate_output_ax63||0), 0.002); end
  def test_intermediate_output_ay63; assert_in_delta(0.0, (worksheet.intermediate_output_ay63||0), 0.002); end
  def test_intermediate_output_az63; assert_in_delta(0.0, (worksheet.intermediate_output_az63||0), 0.002); end
  def test_intermediate_output_ba63; assert_in_delta(0.0, (worksheet.intermediate_output_ba63||0), 0.002); end
  def test_intermediate_output_bb63; assert_in_delta(0.0, (worksheet.intermediate_output_bb63||0), 0.002); end
  def test_intermediate_output_bc63; assert_in_delta(0.0, (worksheet.intermediate_output_bc63||0), 0.002); end
  def test_intermediate_output_bd63; assert_in_delta(0.0, (worksheet.intermediate_output_bd63||0), 0.002); end
  def test_intermediate_output_be63; assert_in_delta(0.0, (worksheet.intermediate_output_be63||0), 0.002); end
  def test_intermediate_output_bf63; assert_in_delta(0.0, (worksheet.intermediate_output_bf63||0), 0.002); end
  def test_intermediate_output_c64; assert_equal("V.13", worksheet.intermediate_output_c64); end
  def test_intermediate_output_d64; assert_equal("Energy crops (second generation)", worksheet.intermediate_output_d64); end
  def test_intermediate_output_ax64; assert_in_delta(0.0, (worksheet.intermediate_output_ax64||0), 0.002); end
  def test_intermediate_output_ay64; assert_in_delta(0.0, (worksheet.intermediate_output_ay64||0), 0.002); end
  def test_intermediate_output_az64; assert_in_delta(0.0, (worksheet.intermediate_output_az64||0), 0.002); end
  def test_intermediate_output_ba64; assert_in_delta(0.0, (worksheet.intermediate_output_ba64||0), 0.002); end
  def test_intermediate_output_bb64; assert_in_delta(0.0, (worksheet.intermediate_output_bb64||0), 0.002); end
  def test_intermediate_output_bc64; assert_in_delta(0.0, (worksheet.intermediate_output_bc64||0), 0.002); end
  def test_intermediate_output_bd64; assert_in_delta(0.0, (worksheet.intermediate_output_bd64||0), 0.002); end
  def test_intermediate_output_be64; assert_in_delta(0.0, (worksheet.intermediate_output_be64||0), 0.002); end
  def test_intermediate_output_bf64; assert_in_delta(0.0, (worksheet.intermediate_output_bf64||0), 0.002); end
  def test_intermediate_output_d65; assert_equal("Total unnaccounted supply / demand", worksheet.intermediate_output_d65); end
  def test_intermediate_output_ax65; assert_in_delta(0.0, (worksheet.intermediate_output_ax65||0), 0.002); end
  def test_intermediate_output_ay65; assert_in_delta(0.0, (worksheet.intermediate_output_ay65||0), 0.002); end
  def test_intermediate_output_az65; assert_in_delta(0.0, (worksheet.intermediate_output_az65||0), 0.002); end
  def test_intermediate_output_ba65; assert_in_delta(0.0, (worksheet.intermediate_output_ba65||0), 0.002); end
  def test_intermediate_output_bb65; assert_in_delta(0.0, (worksheet.intermediate_output_bb65||0), 0.002); end
  def test_intermediate_output_bc65; assert_in_delta(0.0, (worksheet.intermediate_output_bc65||0), 0.002); end
  def test_intermediate_output_bd65; assert_in_delta(0.0, (worksheet.intermediate_output_bd65||0), 0.002); end
  def test_intermediate_output_be65; assert_in_delta(0.0, (worksheet.intermediate_output_be65||0), 0.002); end
  def test_intermediate_output_bf65; assert_in_delta(0.0, (worksheet.intermediate_output_bf65||0), 0.002); end
  def test_intermediate_output_d67; assert_equal("Supply, Demand, and Unaccounted supply", worksheet.intermediate_output_d67); end
  def test_intermediate_output_ax67; assert_in_delta(-1.1368683772161603e-13, worksheet.intermediate_output_ax67, 0.002); end
  def test_intermediate_output_ay67; assert_in_delta(3.410605131648481e-13, worksheet.intermediate_output_ay67, 0.002); end
  def test_intermediate_output_az67; assert_in_delta(2.2737367544323206e-13, worksheet.intermediate_output_az67, 0.002); end
  def test_intermediate_output_ba67; assert_in_delta(4.547473508864641e-13, worksheet.intermediate_output_ba67, 0.002); end
  def test_intermediate_output_bb67; assert_in_delta(-4.547473508864641e-13, worksheet.intermediate_output_bb67, 0.002); end
  def test_intermediate_output_bc67; assert_in_delta(6.821210263296962e-13, worksheet.intermediate_output_bc67, 0.002); end
  def test_intermediate_output_bd67; assert_in_delta(-1.5916157281026244e-12, worksheet.intermediate_output_bd67, 0.002); end
  def test_intermediate_output_be67; assert_in_delta(0.0, (worksheet.intermediate_output_be67||0), 0.002); end
  def test_intermediate_output_bf67; assert_in_delta(-6.821210263296962e-13, worksheet.intermediate_output_bf67, 0.002); end
  def test_intermediate_output_b71; assert_equal("Electricity grid (net of distribution losses)", worksheet.intermediate_output_b71); end
  def test_intermediate_output_c73; assert_equal("V.01", worksheet.intermediate_output_c73); end
  def test_intermediate_output_d73; assert_equal("Electricity (delivered to end user)", worksheet.intermediate_output_d73); end
  def test_intermediate_output_ax73; assert_in_epsilon(-115.42640612332141, worksheet.intermediate_output_ax73, 0.002); end
  def test_intermediate_output_ay73; assert_in_epsilon(-134.78549342723124, worksheet.intermediate_output_ay73, 0.002); end
  def test_intermediate_output_az73; assert_in_epsilon(-179.76197401863658, worksheet.intermediate_output_az73, 0.002); end
  def test_intermediate_output_ba73; assert_in_epsilon(-255.05301550319768, worksheet.intermediate_output_ba73, 0.002); end
  def test_intermediate_output_bb73; assert_in_epsilon(-331.660506800308, worksheet.intermediate_output_bb73, 0.002); end
  def test_intermediate_output_bc73; assert_in_epsilon(-423.8643586571661, worksheet.intermediate_output_bc73, 0.002); end
  def test_intermediate_output_bd73; assert_in_epsilon(-517.2428438294311, worksheet.intermediate_output_bd73, 0.002); end
  def test_intermediate_output_be73; assert_in_epsilon(-613.8988855524725, worksheet.intermediate_output_be73, 0.002); end
  def test_intermediate_output_bf73; assert_in_epsilon(-716.2897690182277, worksheet.intermediate_output_bf73, 0.002); end
  def test_intermediate_output_bg73; assert_equal("REFERENCED", worksheet.intermediate_output_bg73); end
  def test_intermediate_output_c74; assert_equal("V.02", worksheet.intermediate_output_c74); end
  def test_intermediate_output_d74; assert_equal("Electricity (supplied to grid)", worksheet.intermediate_output_d74); end
  def test_intermediate_output_ax74; assert_in_epsilon(115.42640612332141, worksheet.intermediate_output_ax74, 0.002); end
  def test_intermediate_output_ay74; assert_in_epsilon(134.78549342723124, worksheet.intermediate_output_ay74, 0.002); end
  def test_intermediate_output_az74; assert_in_epsilon(179.76197401863658, worksheet.intermediate_output_az74, 0.002); end
  def test_intermediate_output_ba74; assert_in_epsilon(255.05301550319768, worksheet.intermediate_output_ba74, 0.002); end
  def test_intermediate_output_bb74; assert_in_epsilon(331.660506800308, worksheet.intermediate_output_bb74, 0.002); end
  def test_intermediate_output_bc74; assert_in_epsilon(423.8643586571661, worksheet.intermediate_output_bc74, 0.002); end
  def test_intermediate_output_bd74; assert_in_epsilon(517.2428438294311, worksheet.intermediate_output_bd74, 0.002); end
  def test_intermediate_output_be74; assert_in_epsilon(613.8988855524725, worksheet.intermediate_output_be74, 0.002); end
  def test_intermediate_output_bf74; assert_in_epsilon(716.2897690182277, worksheet.intermediate_output_bf74, 0.002); end
  def test_intermediate_output_d75; assert_equal("Total electricity grid", worksheet.intermediate_output_d75); end
  def test_intermediate_output_ax75; assert_in_delta(0.0, (worksheet.intermediate_output_ax75||0), 0.002); end
  def test_intermediate_output_ay75; assert_in_delta(0.0, (worksheet.intermediate_output_ay75||0), 0.002); end
  def test_intermediate_output_az75; assert_in_delta(0.0, (worksheet.intermediate_output_az75||0), 0.002); end
  def test_intermediate_output_ba75; assert_in_delta(0.0, (worksheet.intermediate_output_ba75||0), 0.002); end
  def test_intermediate_output_bb75; assert_in_delta(0.0, (worksheet.intermediate_output_bb75||0), 0.002); end
  def test_intermediate_output_bc75; assert_in_delta(0.0, (worksheet.intermediate_output_bc75||0), 0.002); end
  def test_intermediate_output_bd75; assert_in_delta(0.0, (worksheet.intermediate_output_bd75||0), 0.002); end
  def test_intermediate_output_be75; assert_in_delta(0.0, (worksheet.intermediate_output_be75||0), 0.002); end
  def test_intermediate_output_bf75; assert_in_delta(0.0, (worksheet.intermediate_output_bf75||0), 0.002); end
  def test_intermediate_output_c77; assert_equal("V.02", worksheet.intermediate_output_c77); end
  def test_intermediate_output_d77; assert_equal("Losses", worksheet.intermediate_output_d77); end
  def test_intermediate_output_ax77; assert_in_epsilon(-23.641553061403187, worksheet.intermediate_output_ax77, 0.002); end
  def test_intermediate_output_ay77; assert_in_epsilon(-27.606667328469058, worksheet.intermediate_output_ay77, 0.002); end
  def test_intermediate_output_az77; assert_in_epsilon(-31.722701297406473, worksheet.intermediate_output_az77, 0.002); end
  def test_intermediate_output_ba77; assert_in_epsilon(-45.009355677034875, worksheet.intermediate_output_ba77, 0.002); end
  def test_intermediate_output_bb77; assert_in_epsilon(-58.528324729466135, worksheet.intermediate_output_bb77, 0.002); end
  def test_intermediate_output_bc77; assert_in_epsilon(-57.79968527143177, worksheet.intermediate_output_bc77, 0.002); end
  def test_intermediate_output_bd77; assert_in_epsilon(-70.53311506764965, worksheet.intermediate_output_bd77, 0.002); end
  def test_intermediate_output_be77; assert_in_epsilon(-68.210987283608, worksheet.intermediate_output_be77, 0.002); end
  def test_intermediate_output_bf77; assert_in_epsilon(-79.58775211313639, worksheet.intermediate_output_bf77, 0.002); end
  def test_intermediate_output_d78; assert_equal("Demand (for charting)", worksheet.intermediate_output_d78); end
  def test_intermediate_output_ax78; assert_in_epsilon(139.0679591847246, worksheet.intermediate_output_ax78, 0.002); end
  def test_intermediate_output_ay78; assert_in_epsilon(162.3921607557003, worksheet.intermediate_output_ay78, 0.002); end
  def test_intermediate_output_az78; assert_in_epsilon(211.48467531604305, worksheet.intermediate_output_az78, 0.002); end
  def test_intermediate_output_ba78; assert_in_epsilon(300.06237118023256, worksheet.intermediate_output_ba78, 0.002); end
  def test_intermediate_output_bb78; assert_in_epsilon(390.1888315297741, worksheet.intermediate_output_bb78, 0.002); end
  def test_intermediate_output_bc78; assert_in_epsilon(481.6640439285979, worksheet.intermediate_output_bc78, 0.002); end
  def test_intermediate_output_bd78; assert_in_epsilon(587.7759588970807, worksheet.intermediate_output_bd78, 0.002); end
  def test_intermediate_output_be78; assert_in_epsilon(682.1098728360805, worksheet.intermediate_output_be78, 0.002); end
  def test_intermediate_output_bf78; assert_in_epsilon(795.8775211313641, worksheet.intermediate_output_bf78, 0.002); end
  def test_intermediate_output_d79; assert_equal("Dummy for charting", worksheet.intermediate_output_d79); end
  def test_intermediate_output_ax79; assert_in_epsilon(139.0679591847246, worksheet.intermediate_output_ax79, 0.002); end
  def test_intermediate_output_ay79; assert_in_epsilon(162.39216075570033, worksheet.intermediate_output_ay79, 0.002); end
  def test_intermediate_output_az79; assert_in_epsilon(211.48467531604308, worksheet.intermediate_output_az79, 0.002); end
  def test_intermediate_output_ba79; assert_in_epsilon(300.06237118023256, worksheet.intermediate_output_ba79, 0.002); end
  def test_intermediate_output_bb79; assert_in_epsilon(390.1888315297742, worksheet.intermediate_output_bb79, 0.002); end
  def test_intermediate_output_bc79; assert_in_epsilon(481.6640439285979, worksheet.intermediate_output_bc79, 0.002); end
  def test_intermediate_output_bd79; assert_in_epsilon(587.7759588970807, worksheet.intermediate_output_bd79, 0.002); end
  def test_intermediate_output_be79; assert_in_epsilon(682.1098728360804, worksheet.intermediate_output_be79, 0.002); end
  def test_intermediate_output_bf79; assert_in_epsilon(795.8775211313641, worksheet.intermediate_output_bf79, 0.002); end
  def test_intermediate_output_c82; assert_equal("Z.01", worksheet.intermediate_output_c82); end
  def test_intermediate_output_d82; assert_equal("Unallocated", worksheet.intermediate_output_d82); end
  def test_intermediate_output_ax82; assert_in_delta(0.0, (worksheet.intermediate_output_ax82||0), 0.002); end
  def test_intermediate_output_ay82; assert_in_delta(0.0, (worksheet.intermediate_output_ay82||0), 0.002); end
  def test_intermediate_output_az82; assert_in_delta(0.0, (worksheet.intermediate_output_az82||0), 0.002); end
  def test_intermediate_output_ba82; assert_in_delta(0.0, (worksheet.intermediate_output_ba82||0), 0.002); end
  def test_intermediate_output_bb82; assert_in_delta(0.0, (worksheet.intermediate_output_bb82||0), 0.002); end
  def test_intermediate_output_bc82; assert_in_delta(0.0, (worksheet.intermediate_output_bc82||0), 0.002); end
  def test_intermediate_output_bd82; assert_in_delta(0.0, (worksheet.intermediate_output_bd82||0), 0.002); end
  def test_intermediate_output_be82; assert_in_delta(0.0, (worksheet.intermediate_output_be82||0), 0.002); end
  def test_intermediate_output_bf82; assert_in_delta(0.0, (worksheet.intermediate_output_bf82||0), 0.002); end
  def test_intermediate_output_d84; assert_equal("Net balance (should be zero!)", worksheet.intermediate_output_d84); end
  def test_intermediate_output_ax84; assert_in_delta(-1.1368683772161603e-13, worksheet.intermediate_output_ax84, 0.002); end
  def test_intermediate_output_ay84; assert_in_delta(3.410605131648481e-13, worksheet.intermediate_output_ay84, 0.002); end
  def test_intermediate_output_az84; assert_in_delta(2.2737367544323206e-13, worksheet.intermediate_output_az84, 0.002); end
  def test_intermediate_output_ba84; assert_in_delta(4.547473508864641e-13, worksheet.intermediate_output_ba84, 0.002); end
  def test_intermediate_output_bb84; assert_in_delta(-4.547473508864641e-13, worksheet.intermediate_output_bb84, 0.002); end
  def test_intermediate_output_bc84; assert_in_delta(6.821210263296962e-13, worksheet.intermediate_output_bc84, 0.002); end
  def test_intermediate_output_bd84; assert_in_delta(-1.5916157281026244e-12, worksheet.intermediate_output_bd84, 0.002); end
  def test_intermediate_output_be84; assert_in_delta(0.0, (worksheet.intermediate_output_be84||0), 0.002); end
  def test_intermediate_output_bf84; assert_in_delta(-6.821210263296962e-13, worksheet.intermediate_output_bf84, 0.002); end
  def test_intermediate_output_b86; assert_equal("Electricity Generation", worksheet.intermediate_output_b86); end
  def test_intermediate_output_c88; assert_equal("V.02", worksheet.intermediate_output_c88); end
  def test_intermediate_output_d88; assert_equal("TWh", worksheet.intermediate_output_d88); end
  def test_intermediate_output_ax88; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax88, 0.002); end
  def test_intermediate_output_ay88; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay88, 0.002); end
  def test_intermediate_output_az88; assert_in_epsilon(2020.0, worksheet.intermediate_output_az88, 0.002); end
  def test_intermediate_output_ba88; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba88, 0.002); end
  def test_intermediate_output_bb88; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb88, 0.002); end
  def test_intermediate_output_bc88; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc88, 0.002); end
  def test_intermediate_output_bd88; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd88, 0.002); end
  def test_intermediate_output_be88; assert_in_epsilon(2045.0, worksheet.intermediate_output_be88, 0.002); end
  def test_intermediate_output_bf88; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf88, 0.002); end
  def test_intermediate_output_c89; assert_equal("I.a", worksheet.intermediate_output_c89); end
  def test_intermediate_output_d89; assert_equal("Natural gas power stations", worksheet.intermediate_output_d89); end
  def test_intermediate_output_ax89; assert_in_epsilon(18.408599999999996, worksheet.intermediate_output_ax89, 0.002); end
  def test_intermediate_output_ay89; assert_in_epsilon(21.108528, worksheet.intermediate_output_ay89, 0.002); end
  def test_intermediate_output_az89; assert_in_epsilon(23.808456, worksheet.intermediate_output_az89, 0.002); end
  def test_intermediate_output_ba89; assert_in_epsilon(26.447021999999993, worksheet.intermediate_output_ba89, 0.002); end
  def test_intermediate_output_bb89; assert_in_epsilon(29.14695, worksheet.intermediate_output_bb89, 0.002); end
  def test_intermediate_output_bc89; assert_in_epsilon(31.846878, worksheet.intermediate_output_bc89, 0.002); end
  def test_intermediate_output_bd89; assert_in_epsilon(34.546806000000004, worksheet.intermediate_output_bd89, 0.002); end
  def test_intermediate_output_be89; assert_in_epsilon(37.12401, worksheet.intermediate_output_be89, 0.002); end
  def test_intermediate_output_bf89; assert_in_epsilon(39.885299999999994, worksheet.intermediate_output_bf89, 0.002); end
  def test_intermediate_output_c90; assert_equal("IX.a", worksheet.intermediate_output_c90); end
  def test_intermediate_output_d90; assert_equal("Residential Cooling", worksheet.intermediate_output_d90); end
  def test_intermediate_output_ax90; assert_in_delta(0.0, (worksheet.intermediate_output_ax90||0), 0.002); end
  def test_intermediate_output_ay90; assert_in_delta(0.0, (worksheet.intermediate_output_ay90||0), 0.002); end
  def test_intermediate_output_az90; assert_in_delta(0.0, (worksheet.intermediate_output_az90||0), 0.002); end
  def test_intermediate_output_ba90; assert_in_delta(0.0, (worksheet.intermediate_output_ba90||0), 0.002); end
  def test_intermediate_output_bb90; assert_in_delta(0.0, (worksheet.intermediate_output_bb90||0), 0.002); end
  def test_intermediate_output_bc90; assert_in_delta(0.0, (worksheet.intermediate_output_bc90||0), 0.002); end
  def test_intermediate_output_bd90; assert_in_delta(0.0, (worksheet.intermediate_output_bd90||0), 0.002); end
  def test_intermediate_output_be90; assert_in_delta(0.0, (worksheet.intermediate_output_be90||0), 0.002); end
  def test_intermediate_output_bf90; assert_in_delta(0.0, (worksheet.intermediate_output_bf90||0), 0.002); end
  def test_intermediate_output_c91; assert_equal("IX.c", worksheet.intermediate_output_c91); end
  def test_intermediate_output_d91; assert_equal("Service Sector Cooling", worksheet.intermediate_output_d91); end
  def test_intermediate_output_ax91; assert_in_delta(0.0, (worksheet.intermediate_output_ax91||0), 0.002); end
  def test_intermediate_output_ay91; assert_in_delta(0.0, (worksheet.intermediate_output_ay91||0), 0.002); end
  def test_intermediate_output_az91; assert_in_delta(0.0, (worksheet.intermediate_output_az91||0), 0.002); end
  def test_intermediate_output_ba91; assert_in_delta(0.0, (worksheet.intermediate_output_ba91||0), 0.002); end
  def test_intermediate_output_bb91; assert_in_delta(0.0, (worksheet.intermediate_output_bb91||0), 0.002); end
  def test_intermediate_output_bc91; assert_in_delta(0.0, (worksheet.intermediate_output_bc91||0), 0.002); end
  def test_intermediate_output_bd91; assert_in_delta(0.0, (worksheet.intermediate_output_bd91||0), 0.002); end
  def test_intermediate_output_be91; assert_in_delta(0.0, (worksheet.intermediate_output_be91||0), 0.002); end
  def test_intermediate_output_bf91; assert_in_delta(0.0, (worksheet.intermediate_output_bf91||0), 0.002); end
  def test_intermediate_output_d92; assert_equal("Conventional", worksheet.intermediate_output_d92); end
  def test_intermediate_output_ax92; assert_in_epsilon(18.408599999999996, worksheet.intermediate_output_ax92, 0.002); end
  def test_intermediate_output_ay92; assert_in_epsilon(21.108528, worksheet.intermediate_output_ay92, 0.002); end
  def test_intermediate_output_az92; assert_in_epsilon(23.808456, worksheet.intermediate_output_az92, 0.002); end
  def test_intermediate_output_ba92; assert_in_epsilon(35.65132199999999, worksheet.intermediate_output_ba92, 0.002); end
  def test_intermediate_output_bb92; assert_in_epsilon(38.35125, worksheet.intermediate_output_bb92, 0.002); end
  def test_intermediate_output_bc92; assert_in_epsilon(41.051178, worksheet.intermediate_output_bc92, 0.002); end
  def test_intermediate_output_bd92; assert_in_epsilon(43.751106, worksheet.intermediate_output_bd92, 0.002); end
  def test_intermediate_output_be92; assert_in_epsilon(46.328309999999995, worksheet.intermediate_output_be92, 0.002); end
  def test_intermediate_output_bf92; assert_in_epsilon(49.08959999999999, worksheet.intermediate_output_bf92, 0.002); end
  def test_intermediate_output_c93; assert_equal("I.b", worksheet.intermediate_output_c93); end
  def test_intermediate_output_d93; assert_equal("Biomass power station", worksheet.intermediate_output_d93); end
  def test_intermediate_output_ax93; assert_in_delta(0.0, (worksheet.intermediate_output_ax93||0), 0.002); end
  def test_intermediate_output_ay93; assert_in_delta(0.0, (worksheet.intermediate_output_ay93||0), 0.002); end
  def test_intermediate_output_az93; assert_in_delta(0.039447, worksheet.intermediate_output_az93, 0.002); end
  def test_intermediate_output_ba93; assert_in_delta(0.039447, worksheet.intermediate_output_ba93, 0.002); end
  def test_intermediate_output_bb93; assert_in_delta(0.039447, worksheet.intermediate_output_bb93, 0.002); end
  def test_intermediate_output_bc93; assert_in_delta(0.039447, worksheet.intermediate_output_bc93, 0.002); end
  def test_intermediate_output_bd93; assert_in_delta(0.039447, worksheet.intermediate_output_bd93, 0.002); end
  def test_intermediate_output_be93; assert_in_delta(0.039447, worksheet.intermediate_output_be93, 0.002); end
  def test_intermediate_output_bf93; assert_in_delta(0.039447, worksheet.intermediate_output_bf93, 0.002); end
  def test_intermediate_output_c94; assert_equal("I.c", worksheet.intermediate_output_c94); end
  def test_intermediate_output_d94; assert_equal("Coal power stations", worksheet.intermediate_output_d94); end
  def test_intermediate_output_ax94; assert_in_delta(0.0, (worksheet.intermediate_output_ax94||0), 0.002); end
  def test_intermediate_output_ay94; assert_in_delta(0.0, (worksheet.intermediate_output_ay94||0), 0.002); end
  def test_intermediate_output_az94; assert_in_delta(0.0, (worksheet.intermediate_output_az94||0), 0.002); end
  def test_intermediate_output_ba94; assert_in_epsilon(9.204299999999998, worksheet.intermediate_output_ba94, 0.002); end
  def test_intermediate_output_bb94; assert_in_epsilon(9.204299999999998, worksheet.intermediate_output_bb94, 0.002); end
  def test_intermediate_output_bc94; assert_in_epsilon(9.204299999999998, worksheet.intermediate_output_bc94, 0.002); end
  def test_intermediate_output_bd94; assert_in_epsilon(9.204299999999998, worksheet.intermediate_output_bd94, 0.002); end
  def test_intermediate_output_be94; assert_in_epsilon(9.204299999999998, worksheet.intermediate_output_be94, 0.002); end
  def test_intermediate_output_bf94; assert_in_epsilon(9.204299999999998, worksheet.intermediate_output_bf94, 0.002); end
  def test_intermediate_output_c95; assert_equal("I.d", worksheet.intermediate_output_c95); end
  def test_intermediate_output_d95; assert_equal("Self Generation ", worksheet.intermediate_output_d95); end
  def test_intermediate_output_ax95; assert_in_epsilon(110.8829942847246, worksheet.intermediate_output_ax95, 0.002); end
  def test_intermediate_output_ay95; assert_in_epsilon(130.61445075570032, worksheet.intermediate_output_ay95, 0.002); end
  def test_intermediate_output_az95; assert_in_epsilon(175.8455423160431, worksheet.intermediate_output_az95, 0.002); end
  def test_intermediate_output_ba95; assert_in_epsilon(251.47585618023257, worksheet.intermediate_output_ba95, 0.002); end
  def test_intermediate_output_bb95; assert_in_epsilon(337.79787252977417, worksheet.intermediate_output_bb95, 0.002); end
  def test_intermediate_output_bc95; assert_in_epsilon(425.4686409285979, worksheet.intermediate_output_bc95, 0.002); end
  def test_intermediate_output_bd95; assert_in_epsilon(527.7761118970807, worksheet.intermediate_output_bd95, 0.002); end
  def test_intermediate_output_be95; assert_in_epsilon(618.4283058360804, worksheet.intermediate_output_be95, 0.002); end
  def test_intermediate_output_bf95; assert_in_epsilon(728.3301481313641, worksheet.intermediate_output_bf95, 0.002); end
  def test_intermediate_output_c96; assert_equal("II.a", worksheet.intermediate_output_c96); end
  def test_intermediate_output_d96; assert_equal("Nuclear power", worksheet.intermediate_output_d96); end
  def test_intermediate_output_ax96; assert_in_delta(0.0, (worksheet.intermediate_output_ax96||0), 0.002); end
  def test_intermediate_output_ay96; assert_in_delta(0.0, (worksheet.intermediate_output_ay96||0), 0.002); end
  def test_intermediate_output_az96; assert_in_delta(0.0, (worksheet.intermediate_output_az96||0), 0.002); end
  def test_intermediate_output_ba96; assert_in_delta(0.0, (worksheet.intermediate_output_ba96||0), 0.002); end
  def test_intermediate_output_bb96; assert_in_delta(0.0, (worksheet.intermediate_output_bb96||0), 0.002); end
  def test_intermediate_output_bc96; assert_in_delta(0.0, (worksheet.intermediate_output_bc96||0), 0.002); end
  def test_intermediate_output_bd96; assert_in_delta(0.0, (worksheet.intermediate_output_bd96||0), 0.002); end
  def test_intermediate_output_be96; assert_in_delta(0.0, (worksheet.intermediate_output_be96||0), 0.002); end
  def test_intermediate_output_bf96; assert_in_delta(0.0, (worksheet.intermediate_output_bf96||0), 0.002); end
  def test_intermediate_output_c97; assert_equal("III.a.1", worksheet.intermediate_output_c97); end
  def test_intermediate_output_d97; assert_equal("Wind ", worksheet.intermediate_output_d97); end
  def test_intermediate_output_ax97; assert_in_delta(0.0, (worksheet.intermediate_output_ax97||0), 0.002); end
  def test_intermediate_output_ay97; assert_in_delta(0.0, (worksheet.intermediate_output_ay97||0), 0.002); end
  def test_intermediate_output_az97; assert_in_delta(0.017532, worksheet.intermediate_output_az97, 0.002); end
  def test_intermediate_output_ba97; assert_in_delta(0.017532, worksheet.intermediate_output_ba97, 0.002); end
  def test_intermediate_output_bb97; assert_in_delta(0.017532, worksheet.intermediate_output_bb97, 0.002); end
  def test_intermediate_output_bc97; assert_in_delta(0.017532, worksheet.intermediate_output_bc97, 0.002); end
  def test_intermediate_output_bd97; assert_in_delta(0.017532, worksheet.intermediate_output_bd97, 0.002); end
  def test_intermediate_output_be97; assert_in_delta(0.017532, worksheet.intermediate_output_be97, 0.002); end
  def test_intermediate_output_bf97; assert_in_delta(0.017532, worksheet.intermediate_output_bf97, 0.002); end
  def test_intermediate_output_c98; assert_equal("III.b.1", worksheet.intermediate_output_c98); end
  def test_intermediate_output_d98; assert_equal("Hydroelectric power stations", worksheet.intermediate_output_d98); end
  def test_intermediate_output_ax98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_ax98, 0.002); end
  def test_intermediate_output_ay98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_ay98, 0.002); end
  def test_intermediate_output_az98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_az98, 0.002); end
  def test_intermediate_output_ba98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_ba98, 0.002); end
  def test_intermediate_output_bb98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_bb98, 0.002); end
  def test_intermediate_output_bc98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_bc98, 0.002); end
  def test_intermediate_output_bd98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_bd98, 0.002); end
  def test_intermediate_output_be98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_be98, 0.002); end
  def test_intermediate_output_bf98; assert_in_epsilon(9.993239999999998, worksheet.intermediate_output_bf98, 0.002); end
  def test_intermediate_output_c99; assert_equal("III.b.2", worksheet.intermediate_output_c99); end
  def test_intermediate_output_d99; assert_equal("Small Hydroelectric power stations", worksheet.intermediate_output_d99); end
  def test_intermediate_output_ax99; assert_in_delta(0.280512, worksheet.intermediate_output_ax99, 0.002); end
  def test_intermediate_output_ay99; assert_in_delta(0.280512, worksheet.intermediate_output_ay99, 0.002); end
  def test_intermediate_output_az99; assert_in_delta(0.280512, worksheet.intermediate_output_az99, 0.002); end
  def test_intermediate_output_ba99; assert_in_delta(0.280512, worksheet.intermediate_output_ba99, 0.002); end
  def test_intermediate_output_bb99; assert_in_delta(0.280512, worksheet.intermediate_output_bb99, 0.002); end
  def test_intermediate_output_bc99; assert_in_delta(0.280512, worksheet.intermediate_output_bc99, 0.002); end
  def test_intermediate_output_bd99; assert_in_delta(0.280512, worksheet.intermediate_output_bd99, 0.002); end
  def test_intermediate_output_be99; assert_in_delta(0.280512, worksheet.intermediate_output_be99, 0.002); end
  def test_intermediate_output_bf99; assert_in_delta(0.280512, worksheet.intermediate_output_bf99, 0.002); end
  def test_intermediate_output_c100; assert_equal("III.f", worksheet.intermediate_output_c100); end
  def test_intermediate_output_d100; assert_equal("Grid Connected Solar PV", worksheet.intermediate_output_d100); end
  def test_intermediate_output_ax100; assert_in_delta(0.0, (worksheet.intermediate_output_ax100||0), 0.002); end
  def test_intermediate_output_ay100; assert_in_delta(0.0, (worksheet.intermediate_output_ay100||0), 0.002); end
  def test_intermediate_output_az100; assert_in_delta(0.18408600000000003, worksheet.intermediate_output_az100, 0.002); end
  def test_intermediate_output_ba100; assert_in_delta(0.36817200000000005, worksheet.intermediate_output_ba100, 0.002); end
  def test_intermediate_output_bb100; assert_in_delta(0.552258, worksheet.intermediate_output_bb100, 0.002); end
  def test_intermediate_output_bc100; assert_in_delta(0.7363440000000001, worksheet.intermediate_output_bc100, 0.002); end
  def test_intermediate_output_bd100; assert_in_delta(0.92043, worksheet.intermediate_output_bd100, 0.002); end
  def test_intermediate_output_be100; assert_in_epsilon(1.104516, worksheet.intermediate_output_be100, 0.002); end
  def test_intermediate_output_bf100; assert_in_epsilon(1.2886019999999998, worksheet.intermediate_output_bf100, 0.002); end
  def test_intermediate_output_c101; assert_equal("III.g", worksheet.intermediate_output_c101); end
  def test_intermediate_output_d101; assert_equal("Concentrated Solar Power", worksheet.intermediate_output_d101); end
  def test_intermediate_output_ax101; assert_in_delta(0.0, (worksheet.intermediate_output_ax101||0), 0.002); end
  def test_intermediate_output_ay101; assert_in_delta(0.0, (worksheet.intermediate_output_ay101||0), 0.002); end
  def test_intermediate_output_az101; assert_in_delta(0.0, (worksheet.intermediate_output_az101||0), 0.002); end
  def test_intermediate_output_ba101; assert_in_delta(0.0, (worksheet.intermediate_output_ba101||0), 0.002); end
  def test_intermediate_output_bb101; assert_in_delta(0.0, (worksheet.intermediate_output_bb101||0), 0.002); end
  def test_intermediate_output_bc101; assert_in_delta(0.0, (worksheet.intermediate_output_bc101||0), 0.002); end
  def test_intermediate_output_bd101; assert_in_delta(0.0, (worksheet.intermediate_output_bd101||0), 0.002); end
  def test_intermediate_output_be101; assert_in_delta(0.0, (worksheet.intermediate_output_be101||0), 0.002); end
  def test_intermediate_output_bf101; assert_in_delta(0.0, (worksheet.intermediate_output_bf101||0), 0.002); end
  def test_intermediate_output_c102; assert_equal("IV.a", worksheet.intermediate_output_c102); end
  def test_intermediate_output_d102; assert_equal("Stand-Alone Solar PV", worksheet.intermediate_output_d102); end
  def test_intermediate_output_ax102; assert_in_delta(0.027612899999999996, worksheet.intermediate_output_ax102, 0.002); end
  def test_intermediate_output_ay102; assert_in_delta(0.92043, worksheet.intermediate_output_ay102, 0.002); end
  def test_intermediate_output_az102; assert_in_epsilon(1.84086, worksheet.intermediate_output_az102, 0.002); end
  def test_intermediate_output_ba102; assert_in_epsilon(2.76129, worksheet.intermediate_output_ba102, 0.002); end
  def test_intermediate_output_bb102; assert_in_epsilon(3.68172, worksheet.intermediate_output_bb102, 0.002); end
  def test_intermediate_output_bc102; assert_in_epsilon(4.60215, worksheet.intermediate_output_bc102, 0.002); end
  def test_intermediate_output_bd102; assert_in_epsilon(5.52258, worksheet.intermediate_output_bd102, 0.002); end
  def test_intermediate_output_be102; assert_in_epsilon(6.44301, worksheet.intermediate_output_be102, 0.002); end
  def test_intermediate_output_bf102; assert_in_epsilon(7.36344, worksheet.intermediate_output_bf102, 0.002); end
  def test_intermediate_output_d103; assert_equal("Non-thermal renewable generation", worksheet.intermediate_output_d103); end
  def test_intermediate_output_ax103; assert_in_epsilon(10.301364899999998, worksheet.intermediate_output_ax103, 0.002); end
  def test_intermediate_output_ay103; assert_in_epsilon(11.194181999999998, worksheet.intermediate_output_ay103, 0.002); end
  def test_intermediate_output_az103; assert_in_epsilon(12.316229999999997, worksheet.intermediate_output_az103, 0.002); end
  def test_intermediate_output_ba103; assert_in_epsilon(13.420745999999998, worksheet.intermediate_output_ba103, 0.002); end
  def test_intermediate_output_bb103; assert_in_epsilon(14.525261999999998, worksheet.intermediate_output_bb103, 0.002); end
  def test_intermediate_output_bc103; assert_in_epsilon(15.629777999999998, worksheet.intermediate_output_bc103, 0.002); end
  def test_intermediate_output_bd103; assert_in_epsilon(16.734294, worksheet.intermediate_output_bd103, 0.002); end
  def test_intermediate_output_be103; assert_in_epsilon(17.83881, worksheet.intermediate_output_be103, 0.002); end
  def test_intermediate_output_bf103; assert_in_epsilon(18.943325999999995, worksheet.intermediate_output_bf103, 0.002); end
  def test_intermediate_output_c104; assert_equal("VII.a", worksheet.intermediate_output_c104); end
  def test_intermediate_output_d104; assert_equal("Electricity imports", worksheet.intermediate_output_d104); end
  def test_intermediate_output_ax104; assert_in_delta(-0.525, worksheet.intermediate_output_ax104, 0.002); end
  def test_intermediate_output_ay104; assert_in_delta(-0.525, worksheet.intermediate_output_ay104, 0.002); end
  def test_intermediate_output_az104; assert_in_delta(-0.525, worksheet.intermediate_output_az104, 0.002); end
  def test_intermediate_output_ba104; assert_in_delta(-0.525, worksheet.intermediate_output_ba104, 0.002); end
  def test_intermediate_output_bb104; assert_in_delta(-0.525, worksheet.intermediate_output_bb104, 0.002); end
  def test_intermediate_output_bc104; assert_in_delta(-0.525, worksheet.intermediate_output_bc104, 0.002); end
  def test_intermediate_output_bd104; assert_in_delta(-0.525, worksheet.intermediate_output_bd104, 0.002); end
  def test_intermediate_output_be104; assert_in_delta(-0.525, worksheet.intermediate_output_be104, 0.002); end
  def test_intermediate_output_bf104; assert_in_delta(-0.525, worksheet.intermediate_output_bf104, 0.002); end
  def test_intermediate_output_d105; assert_equal("Total", worksheet.intermediate_output_d105); end
  def test_intermediate_output_ax105; assert_in_epsilon(139.0679591847246, worksheet.intermediate_output_ax105, 0.002); end
  def test_intermediate_output_ay105; assert_in_epsilon(162.39216075570033, worksheet.intermediate_output_ay105, 0.002); end
  def test_intermediate_output_az105; assert_in_epsilon(211.48467531604308, worksheet.intermediate_output_az105, 0.002); end
  def test_intermediate_output_ba105; assert_in_epsilon(300.06237118023256, worksheet.intermediate_output_ba105, 0.002); end
  def test_intermediate_output_bb105; assert_in_epsilon(390.1888315297742, worksheet.intermediate_output_bb105, 0.002); end
  def test_intermediate_output_bc105; assert_in_epsilon(481.6640439285979, worksheet.intermediate_output_bc105, 0.002); end
  def test_intermediate_output_bd105; assert_in_epsilon(587.7759588970807, worksheet.intermediate_output_bd105, 0.002); end
  def test_intermediate_output_be105; assert_in_epsilon(682.1098728360804, worksheet.intermediate_output_be105, 0.002); end
  def test_intermediate_output_bf105; assert_in_epsilon(795.8775211313641, worksheet.intermediate_output_bf105, 0.002); end
  def test_intermediate_output_d107; assert_equal("Electricity exports", worksheet.intermediate_output_d107); end
  def test_intermediate_output_ax107; assert_in_delta(0.0, (worksheet.intermediate_output_ax107||0), 0.002); end
  def test_intermediate_output_ay107; assert_in_delta(0.0, (worksheet.intermediate_output_ay107||0), 0.002); end
  def test_intermediate_output_az107; assert_in_delta(-2.842170943040401e-14, worksheet.intermediate_output_az107, 0.002); end
  def test_intermediate_output_ba107; assert_in_delta(2.842170943040401e-14, worksheet.intermediate_output_ba107, 0.002); end
  def test_intermediate_output_bb107; assert_in_delta(-5.684341886080802e-14, worksheet.intermediate_output_bb107, 0.002); end
  def test_intermediate_output_bc107; assert_in_delta(0.0, (worksheet.intermediate_output_bc107||0), 0.002); end
  def test_intermediate_output_bd107; assert_in_delta(0.0, (worksheet.intermediate_output_bd107||0), 0.002); end
  def test_intermediate_output_be107; assert_in_delta(1.1368683772161603e-13, worksheet.intermediate_output_be107, 0.002); end
  def test_intermediate_output_bf107; assert_in_delta(0.0, (worksheet.intermediate_output_bf107||0), 0.002); end
  def test_intermediate_output_bg107; assert_equal("REFERENCED", worksheet.intermediate_output_bg107); end
  def test_intermediate_output_d108; assert_equal("Electricity used in Nigeria, before losses.", worksheet.intermediate_output_d108); end
  def test_intermediate_output_ax108; assert_in_epsilon(139.0679591847246, worksheet.intermediate_output_ax108, 0.002); end
  def test_intermediate_output_ay108; assert_in_epsilon(162.39216075570033, worksheet.intermediate_output_ay108, 0.002); end
  def test_intermediate_output_az108; assert_in_epsilon(211.48467531604305, worksheet.intermediate_output_az108, 0.002); end
  def test_intermediate_output_ba108; assert_in_epsilon(300.06237118023256, worksheet.intermediate_output_ba108, 0.002); end
  def test_intermediate_output_bb108; assert_in_epsilon(390.1888315297741, worksheet.intermediate_output_bb108, 0.002); end
  def test_intermediate_output_bc108; assert_in_epsilon(481.6640439285979, worksheet.intermediate_output_bc108, 0.002); end
  def test_intermediate_output_bd108; assert_in_epsilon(587.7759588970807, worksheet.intermediate_output_bd108, 0.002); end
  def test_intermediate_output_be108; assert_in_epsilon(682.1098728360804, worksheet.intermediate_output_be108, 0.002); end
  def test_intermediate_output_bf108; assert_in_epsilon(795.8775211313641, worksheet.intermediate_output_bf108, 0.002); end
  def test_intermediate_output_d110; assert_equal("GW installed capacity", worksheet.intermediate_output_d110); end
  def test_intermediate_output_ax110; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax110, 0.002); end
  def test_intermediate_output_ay110; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay110, 0.002); end
  def test_intermediate_output_az110; assert_in_epsilon(2020.0, worksheet.intermediate_output_az110, 0.002); end
  def test_intermediate_output_ba110; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba110, 0.002); end
  def test_intermediate_output_bb110; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb110, 0.002); end
  def test_intermediate_output_bc110; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc110, 0.002); end
  def test_intermediate_output_bd110; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd110, 0.002); end
  def test_intermediate_output_be110; assert_in_epsilon(2045.0, worksheet.intermediate_output_be110, 0.002); end
  def test_intermediate_output_bf110; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf110, 0.002); end
  def test_intermediate_output_c111; assert_equal("I.a", worksheet.intermediate_output_c111); end
  def test_intermediate_output_d111; assert_equal("Natural gas power stations", worksheet.intermediate_output_d111); end
  def test_intermediate_output_ax111; assert_in_epsilon(3.0, worksheet.intermediate_output_ax111, 0.002); end
  def test_intermediate_output_ay111; assert_in_epsilon(3.44, worksheet.intermediate_output_ay111, 0.002); end
  def test_intermediate_output_az111; assert_in_epsilon(3.88, worksheet.intermediate_output_az111, 0.002); end
  def test_intermediate_output_ba111; assert_in_epsilon(4.31, worksheet.intermediate_output_ba111, 0.002); end
  def test_intermediate_output_bb111; assert_in_epsilon(4.75, worksheet.intermediate_output_bb111, 0.002); end
  def test_intermediate_output_bc111; assert_in_epsilon(5.19, worksheet.intermediate_output_bc111, 0.002); end
  def test_intermediate_output_bd111; assert_in_epsilon(5.63, worksheet.intermediate_output_bd111, 0.002); end
  def test_intermediate_output_be111; assert_in_epsilon(6.05, worksheet.intermediate_output_be111, 0.002); end
  def test_intermediate_output_bf111; assert_in_epsilon(6.5, worksheet.intermediate_output_bf111, 0.002); end
  def test_intermediate_output_c112; assert_equal("I.b", worksheet.intermediate_output_c112); end
  def test_intermediate_output_d112; assert_equal("Biomass power station", worksheet.intermediate_output_d112); end
  def test_intermediate_output_ax112; assert_in_delta(0.0, (worksheet.intermediate_output_ax112||0), 0.002); end
  def test_intermediate_output_ay112; assert_in_delta(0.0, (worksheet.intermediate_output_ay112||0), 0.002); end
  def test_intermediate_output_az112; assert_in_delta(0.005, worksheet.intermediate_output_az112, 0.002); end
  def test_intermediate_output_ba112; assert_in_delta(0.005, worksheet.intermediate_output_ba112, 0.002); end
  def test_intermediate_output_bb112; assert_in_delta(0.005, worksheet.intermediate_output_bb112, 0.002); end
  def test_intermediate_output_bc112; assert_in_delta(0.005, worksheet.intermediate_output_bc112, 0.002); end
  def test_intermediate_output_bd112; assert_in_delta(0.005, worksheet.intermediate_output_bd112, 0.002); end
  def test_intermediate_output_be112; assert_in_delta(0.005, worksheet.intermediate_output_be112, 0.002); end
  def test_intermediate_output_bf112; assert_in_delta(0.005, worksheet.intermediate_output_bf112, 0.002); end
  def test_intermediate_output_c113; assert_equal("I.c", worksheet.intermediate_output_c113); end
  def test_intermediate_output_d113; assert_equal("Coal power stations", worksheet.intermediate_output_d113); end
  def test_intermediate_output_ax113; assert_in_delta(0.0, (worksheet.intermediate_output_ax113||0), 0.002); end
  def test_intermediate_output_ay113; assert_in_delta(0.0, (worksheet.intermediate_output_ay113||0), 0.002); end
  def test_intermediate_output_az113; assert_in_delta(0.0, (worksheet.intermediate_output_az113||0), 0.002); end
  def test_intermediate_output_ba113; assert_in_epsilon(1.4, worksheet.intermediate_output_ba113, 0.002); end
  def test_intermediate_output_bb113; assert_in_epsilon(1.4, worksheet.intermediate_output_bb113, 0.002); end
  def test_intermediate_output_bc113; assert_in_epsilon(1.4, worksheet.intermediate_output_bc113, 0.002); end
  def test_intermediate_output_bd113; assert_in_epsilon(1.4, worksheet.intermediate_output_bd113, 0.002); end
  def test_intermediate_output_be113; assert_in_epsilon(1.4, worksheet.intermediate_output_be113, 0.002); end
  def test_intermediate_output_bf113; assert_in_epsilon(1.4, worksheet.intermediate_output_bf113, 0.002); end
  def test_intermediate_output_c114; assert_equal("I.d", worksheet.intermediate_output_c114); end
  def test_intermediate_output_d114; assert_equal("Self Generation ", worksheet.intermediate_output_d114); end
  def test_intermediate_output_ax114; assert_in_epsilon(26.42279885102571, worksheet.intermediate_output_ax114, 0.002); end
  def test_intermediate_output_ay114; assert_in_epsilon(31.12469483366499, worksheet.intermediate_output_ay114, 0.002); end
  def test_intermediate_output_az114; assert_in_epsilon(41.903011579354704, worksheet.intermediate_output_az114, 0.002); end
  def test_intermediate_output_ba114; assert_in_epsilon(59.92529338337988, worksheet.intermediate_output_ba114, 0.002); end
  def test_intermediate_output_bb114; assert_in_epsilon(80.49534823382962, worksheet.intermediate_output_bb114, 0.002); end
  def test_intermediate_output_bc114; assert_in_epsilon(101.38680317207442, worksheet.intermediate_output_bc114, 0.002); end
  def test_intermediate_output_bd114; assert_in_epsilon(125.76610266515979, worksheet.intermediate_output_bd114, 0.002); end
  def test_intermediate_output_be114; assert_in_epsilon(147.3680146743518, worksheet.intermediate_output_be114, 0.002); end
  def test_intermediate_output_bf114; assert_in_epsilon(173.5570104807672, worksheet.intermediate_output_bf114, 0.002); end
  def test_intermediate_output_c115; assert_equal("II.a", worksheet.intermediate_output_c115); end
  def test_intermediate_output_d115; assert_equal("Nuclear power", worksheet.intermediate_output_d115); end
  def test_intermediate_output_ax115; assert_in_delta(0.0, (worksheet.intermediate_output_ax115||0), 0.002); end
  def test_intermediate_output_ay115; assert_in_delta(0.0, (worksheet.intermediate_output_ay115||0), 0.002); end
  def test_intermediate_output_az115; assert_in_delta(0.0, (worksheet.intermediate_output_az115||0), 0.002); end
  def test_intermediate_output_ba115; assert_in_delta(0.0, (worksheet.intermediate_output_ba115||0), 0.002); end
  def test_intermediate_output_bb115; assert_in_delta(0.0, (worksheet.intermediate_output_bb115||0), 0.002); end
  def test_intermediate_output_bc115; assert_in_delta(0.0, (worksheet.intermediate_output_bc115||0), 0.002); end
  def test_intermediate_output_bd115; assert_in_delta(0.0, (worksheet.intermediate_output_bd115||0), 0.002); end
  def test_intermediate_output_be115; assert_in_delta(0.0, (worksheet.intermediate_output_be115||0), 0.002); end
  def test_intermediate_output_bf115; assert_in_delta(0.0, (worksheet.intermediate_output_bf115||0), 0.002); end
  def test_intermediate_output_c116; assert_equal("III.a.1", worksheet.intermediate_output_c116); end
  def test_intermediate_output_d116; assert_equal("Wind ", worksheet.intermediate_output_d116); end
  def test_intermediate_output_ax116; assert_in_delta(0.0, (worksheet.intermediate_output_ax116||0), 0.002); end
  def test_intermediate_output_ay116; assert_in_delta(0.0, (worksheet.intermediate_output_ay116||0), 0.002); end
  def test_intermediate_output_az116; assert_in_delta(0.01, worksheet.intermediate_output_az116, 0.002); end
  def test_intermediate_output_ba116; assert_in_delta(0.01, worksheet.intermediate_output_ba116, 0.002); end
  def test_intermediate_output_bb116; assert_in_delta(0.01, worksheet.intermediate_output_bb116, 0.002); end
  def test_intermediate_output_bc116; assert_in_delta(0.01, worksheet.intermediate_output_bc116, 0.002); end
  def test_intermediate_output_bd116; assert_in_delta(0.01, worksheet.intermediate_output_bd116, 0.002); end
  def test_intermediate_output_be116; assert_in_delta(0.01, worksheet.intermediate_output_be116, 0.002); end
  def test_intermediate_output_bf116; assert_in_delta(0.01, worksheet.intermediate_output_bf116, 0.002); end
  def test_intermediate_output_c117; assert_equal("III.b.1", worksheet.intermediate_output_c117); end
  def test_intermediate_output_d117; assert_equal("Hydroelectric power stations", worksheet.intermediate_output_d117); end
  def test_intermediate_output_ax117; assert_in_epsilon(1.9, worksheet.intermediate_output_ax117, 0.002); end
  def test_intermediate_output_ay117; assert_in_epsilon(1.9, worksheet.intermediate_output_ay117, 0.002); end
  def test_intermediate_output_az117; assert_in_epsilon(1.9, worksheet.intermediate_output_az117, 0.002); end
  def test_intermediate_output_ba117; assert_in_epsilon(1.9, worksheet.intermediate_output_ba117, 0.002); end
  def test_intermediate_output_bb117; assert_in_epsilon(1.9, worksheet.intermediate_output_bb117, 0.002); end
  def test_intermediate_output_bc117; assert_in_epsilon(1.9, worksheet.intermediate_output_bc117, 0.002); end
  def test_intermediate_output_bd117; assert_in_epsilon(1.9, worksheet.intermediate_output_bd117, 0.002); end
  def test_intermediate_output_be117; assert_in_epsilon(1.9, worksheet.intermediate_output_be117, 0.002); end
  def test_intermediate_output_bf117; assert_in_epsilon(1.9, worksheet.intermediate_output_bf117, 0.002); end
  def test_intermediate_output_c118; assert_equal("III.b.2", worksheet.intermediate_output_c118); end
  def test_intermediate_output_d118; assert_equal("Small Hydroelectric power stations", worksheet.intermediate_output_d118); end
  def test_intermediate_output_ax118; assert_in_delta(0.064, worksheet.intermediate_output_ax118, 0.002); end
  def test_intermediate_output_ay118; assert_in_delta(0.064, worksheet.intermediate_output_ay118, 0.002); end
  def test_intermediate_output_az118; assert_in_delta(0.064, worksheet.intermediate_output_az118, 0.002); end
  def test_intermediate_output_ba118; assert_in_delta(0.064, worksheet.intermediate_output_ba118, 0.002); end
  def test_intermediate_output_bb118; assert_in_delta(0.064, worksheet.intermediate_output_bb118, 0.002); end
  def test_intermediate_output_bc118; assert_in_delta(0.064, worksheet.intermediate_output_bc118, 0.002); end
  def test_intermediate_output_bd118; assert_in_delta(0.064, worksheet.intermediate_output_bd118, 0.002); end
  def test_intermediate_output_be118; assert_in_delta(0.064, worksheet.intermediate_output_be118, 0.002); end
  def test_intermediate_output_bf118; assert_in_delta(0.064, worksheet.intermediate_output_bf118, 0.002); end
  def test_intermediate_output_c119; assert_equal("III.f", worksheet.intermediate_output_c119); end
  def test_intermediate_output_d119; assert_equal("Grid Connected Solar PV", worksheet.intermediate_output_d119); end
  def test_intermediate_output_ax119; assert_in_delta(0.0, (worksheet.intermediate_output_ax119||0), 0.002); end
  def test_intermediate_output_ay119; assert_in_delta(0.0, (worksheet.intermediate_output_ay119||0), 0.002); end
  def test_intermediate_output_az119; assert_in_delta(0.1, worksheet.intermediate_output_az119, 0.002); end
  def test_intermediate_output_ba119; assert_in_delta(0.2, worksheet.intermediate_output_ba119, 0.002); end
  def test_intermediate_output_bb119; assert_in_delta(0.3, worksheet.intermediate_output_bb119, 0.002); end
  def test_intermediate_output_bc119; assert_in_delta(0.4, worksheet.intermediate_output_bc119, 0.002); end
  def test_intermediate_output_bd119; assert_in_delta(0.5, worksheet.intermediate_output_bd119, 0.002); end
  def test_intermediate_output_be119; assert_in_delta(0.6, worksheet.intermediate_output_be119, 0.002); end
  def test_intermediate_output_bf119; assert_in_delta(0.7, worksheet.intermediate_output_bf119, 0.002); end
  def test_intermediate_output_c120; assert_equal("III.g", worksheet.intermediate_output_c120); end
  def test_intermediate_output_d120; assert_equal("Concentrated Solar Power", worksheet.intermediate_output_d120); end
  def test_intermediate_output_ax120; assert_in_delta(0.0, (worksheet.intermediate_output_ax120||0), 0.002); end
  def test_intermediate_output_ay120; assert_in_delta(0.0, (worksheet.intermediate_output_ay120||0), 0.002); end
  def test_intermediate_output_az120; assert_in_delta(0.0, (worksheet.intermediate_output_az120||0), 0.002); end
  def test_intermediate_output_ba120; assert_in_delta(0.0, (worksheet.intermediate_output_ba120||0), 0.002); end
  def test_intermediate_output_bb120; assert_in_delta(0.0, (worksheet.intermediate_output_bb120||0), 0.002); end
  def test_intermediate_output_bc120; assert_in_delta(0.0, (worksheet.intermediate_output_bc120||0), 0.002); end
  def test_intermediate_output_bd120; assert_in_delta(0.0, (worksheet.intermediate_output_bd120||0), 0.002); end
  def test_intermediate_output_be120; assert_in_delta(0.0, (worksheet.intermediate_output_be120||0), 0.002); end
  def test_intermediate_output_bf120; assert_in_delta(0.0, (worksheet.intermediate_output_bf120||0), 0.002); end
  def test_intermediate_output_c121; assert_equal("IV.a", worksheet.intermediate_output_c121); end
  def test_intermediate_output_d121; assert_equal("Stand-Alone Solar PV", worksheet.intermediate_output_d121); end
  def test_intermediate_output_ax121; assert_in_delta(0.015, worksheet.intermediate_output_ax121, 0.002); end
  def test_intermediate_output_ay121; assert_in_delta(0.5, worksheet.intermediate_output_ay121, 0.002); end
  def test_intermediate_output_az121; assert_in_delta(1.0, worksheet.intermediate_output_az121, 0.002); end
  def test_intermediate_output_ba121; assert_in_epsilon(1.5, worksheet.intermediate_output_ba121, 0.002); end
  def test_intermediate_output_bb121; assert_in_epsilon(2.0, worksheet.intermediate_output_bb121, 0.002); end
  def test_intermediate_output_bc121; assert_in_epsilon(2.5, worksheet.intermediate_output_bc121, 0.002); end
  def test_intermediate_output_bd121; assert_in_epsilon(3.0, worksheet.intermediate_output_bd121, 0.002); end
  def test_intermediate_output_be121; assert_in_epsilon(3.5, worksheet.intermediate_output_be121, 0.002); end
  def test_intermediate_output_bf121; assert_in_epsilon(4.0, worksheet.intermediate_output_bf121, 0.002); end
  def test_intermediate_output_d122; assert_equal("Total generation", worksheet.intermediate_output_d122); end
  def test_intermediate_output_ax122; assert_in_epsilon(31.40179885102571, worksheet.intermediate_output_ax122, 0.002); end
  def test_intermediate_output_ay122; assert_in_epsilon(37.028694833664986, worksheet.intermediate_output_ay122, 0.002); end
  def test_intermediate_output_az122; assert_in_epsilon(48.8620115793547, worksheet.intermediate_output_az122, 0.002); end
  def test_intermediate_output_ba122; assert_in_epsilon(69.31429338337989, worksheet.intermediate_output_ba122, 0.002); end
  def test_intermediate_output_bb122; assert_in_epsilon(90.92434823382962, worksheet.intermediate_output_bb122, 0.002); end
  def test_intermediate_output_bc122; assert_in_epsilon(112.85580317207443, worksheet.intermediate_output_bc122, 0.002); end
  def test_intermediate_output_bd122; assert_in_epsilon(138.27510266515978, worksheet.intermediate_output_bd122, 0.002); end
  def test_intermediate_output_be122; assert_in_epsilon(160.8970146743518, worksheet.intermediate_output_be122, 0.002); end
  def test_intermediate_output_bf122; assert_in_epsilon(188.13601048076717, worksheet.intermediate_output_bf122, 0.002); end
  def test_intermediate_output_b125; assert_equal("Emissions", worksheet.intermediate_output_b125); end
  def test_intermediate_output_c127; assert_equal("Emissions as % of base year", worksheet.intermediate_output_c127); end
  def test_intermediate_output_d128; assert_equal("IPCC Sector", worksheet.intermediate_output_d128); end
  def test_intermediate_output_ax128; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax128, 0.002); end
  def test_intermediate_output_ay128; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay128, 0.002); end
  def test_intermediate_output_az128; assert_in_epsilon(2020.0, worksheet.intermediate_output_az128, 0.002); end
  def test_intermediate_output_ba128; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba128, 0.002); end
  def test_intermediate_output_bb128; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb128, 0.002); end
  def test_intermediate_output_bc128; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc128, 0.002); end
  def test_intermediate_output_bd128; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd128, 0.002); end
  def test_intermediate_output_be128; assert_in_epsilon(2045.0, worksheet.intermediate_output_be128, 0.002); end
  def test_intermediate_output_bf128; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf128, 0.002); end
  def test_intermediate_output_c129; assert_equal("1A", worksheet.intermediate_output_c129); end
  def test_intermediate_output_d129; assert_equal("Fuel Combustion", worksheet.intermediate_output_d129); end
  def test_intermediate_output_c130; assert_equal("1B", worksheet.intermediate_output_c130); end
  def test_intermediate_output_d130; assert_equal("Fugitive Emissions from Fuels", worksheet.intermediate_output_d130); end
  def test_intermediate_output_c131; assert_in_delta(1.0, worksheet.intermediate_output_c131, 0.002); end
  def test_intermediate_output_d131; assert_equal("Fuel Combustion", worksheet.intermediate_output_d131); end
  def test_intermediate_output_ax131; assert_in_delta(0.3865591773595964, worksheet.intermediate_output_ax131, 0.002); end
  def test_intermediate_output_ay131; assert_in_delta(0.4530387417335337, worksheet.intermediate_output_ay131, 0.002); end
  def test_intermediate_output_az131; assert_in_delta(0.5473758748383256, worksheet.intermediate_output_az131, 0.002); end
  def test_intermediate_output_ba131; assert_in_delta(0.6935589607151453, worksheet.intermediate_output_ba131, 0.002); end
  def test_intermediate_output_bb131; assert_in_delta(0.8406591833101486, worksheet.intermediate_output_bb131, 0.002); end
  def test_intermediate_output_bc131; assert_in_delta(0.9864511544268629, worksheet.intermediate_output_bc131, 0.002); end
  def test_intermediate_output_bd131; assert_in_epsilon(1.147094385127806, worksheet.intermediate_output_bd131, 0.002); end
  def test_intermediate_output_be131; assert_in_epsilon(1.283770651362963, worksheet.intermediate_output_be131, 0.002); end
  def test_intermediate_output_bf131; assert_in_epsilon(1.44604887820033, worksheet.intermediate_output_bf131, 0.002); end
  def test_intermediate_output_c132; assert_in_epsilon(2.0, worksheet.intermediate_output_c132, 0.002); end
  def test_intermediate_output_d132; assert_equal("Industrial Processes", worksheet.intermediate_output_d132); end
  def test_intermediate_output_ax132; assert_in_delta(0.03488218419279114, worksheet.intermediate_output_ax132, 0.002); end
  def test_intermediate_output_ay132; assert_in_delta(0.03484063653755927, worksheet.intermediate_output_ay132, 0.002); end
  def test_intermediate_output_az132; assert_in_delta(0.03484987343641702, worksheet.intermediate_output_az132, 0.002); end
  def test_intermediate_output_ba132; assert_in_delta(0.03491134182580138, worksheet.intermediate_output_ba132, 0.002); end
  def test_intermediate_output_bb132; assert_in_delta(0.034446077901012756, worksheet.intermediate_output_bb132, 0.002); end
  def test_intermediate_output_bc132; assert_in_delta(0.034009732538688796, worksheet.intermediate_output_bc132, 0.002); end
  def test_intermediate_output_bd132; assert_in_delta(0.03360166026317626, worksheet.intermediate_output_bd132, 0.002); end
  def test_intermediate_output_be132; assert_in_delta(0.03322125087401091, worksheet.intermediate_output_be132, 0.002); end
  def test_intermediate_output_bf132; assert_in_delta(0.03488218419279114, worksheet.intermediate_output_bf132, 0.002); end
  def test_intermediate_output_c133; assert_in_epsilon(3.0, worksheet.intermediate_output_c133, 0.002); end
  def test_intermediate_output_d133; assert_equal("Solvent and Other Product Use", worksheet.intermediate_output_d133); end
  def test_intermediate_output_ax133; assert_in_delta(0.0, (worksheet.intermediate_output_ax133||0), 0.002); end
  def test_intermediate_output_ay133; assert_in_delta(0.0, (worksheet.intermediate_output_ay133||0), 0.002); end
  def test_intermediate_output_az133; assert_in_delta(0.0, (worksheet.intermediate_output_az133||0), 0.002); end
  def test_intermediate_output_ba133; assert_in_delta(0.0, (worksheet.intermediate_output_ba133||0), 0.002); end
  def test_intermediate_output_bb133; assert_in_delta(0.0, (worksheet.intermediate_output_bb133||0), 0.002); end
  def test_intermediate_output_bc133; assert_in_delta(0.0, (worksheet.intermediate_output_bc133||0), 0.002); end
  def test_intermediate_output_bd133; assert_in_delta(0.0, (worksheet.intermediate_output_bd133||0), 0.002); end
  def test_intermediate_output_be133; assert_in_delta(0.0, (worksheet.intermediate_output_be133||0), 0.002); end
  def test_intermediate_output_bf133; assert_in_delta(0.0, (worksheet.intermediate_output_bf133||0), 0.002); end
  def test_intermediate_output_c134; assert_in_epsilon(4.0, worksheet.intermediate_output_c134, 0.002); end
  def test_intermediate_output_d134; assert_equal("Agriculture", worksheet.intermediate_output_d134); end
  def test_intermediate_output_ax134; assert_in_delta(0.02911506085704309, worksheet.intermediate_output_ax134, 0.002); end
  def test_intermediate_output_ay134; assert_in_delta(0.028196158518730106, worksheet.intermediate_output_ay134, 0.002); end
  def test_intermediate_output_az134; assert_in_delta(0.02730625771716482, worksheet.intermediate_output_az134, 0.002); end
  def test_intermediate_output_ba134; assert_in_delta(0.02730625771716482, worksheet.intermediate_output_ba134, 0.002); end
  def test_intermediate_output_bb134; assert_in_delta(0.02730625771716482, worksheet.intermediate_output_bb134, 0.002); end
  def test_intermediate_output_bc134; assert_in_delta(0.02730625771716482, worksheet.intermediate_output_bc134, 0.002); end
  def test_intermediate_output_bd134; assert_in_delta(0.02730625771716482, worksheet.intermediate_output_bd134, 0.002); end
  def test_intermediate_output_be134; assert_in_delta(0.02730625771716482, worksheet.intermediate_output_be134, 0.002); end
  def test_intermediate_output_bf134; assert_in_delta(0.02730625771716482, worksheet.intermediate_output_bf134, 0.002); end
  def test_intermediate_output_c135; assert_in_epsilon(5.0, worksheet.intermediate_output_c135, 0.002); end
  def test_intermediate_output_d135; assert_equal("LULUCF", worksheet.intermediate_output_d135); end
  def test_intermediate_output_ax135; assert_in_delta(0.0021533110183734154, worksheet.intermediate_output_ax135, 0.002); end
  def test_intermediate_output_ay135; assert_in_delta(0.006336741879865181, worksheet.intermediate_output_ay135, 0.002); end
  def test_intermediate_output_az135; assert_in_delta(0.010394072636348875, worksheet.intermediate_output_az135, 0.002); end
  def test_intermediate_output_ba135; assert_in_delta(0.014140601981647582, worksheet.intermediate_output_ba135, 0.002); end
  def test_intermediate_output_bb135; assert_in_delta(0.01622673711327448, worksheet.intermediate_output_bb135, 0.002); end
  def test_intermediate_output_bc135; assert_in_delta(0.01655759214794823, worksheet.intermediate_output_bc135, 0.002); end
  def test_intermediate_output_bd135; assert_in_delta(0.015276460634630536, worksheet.intermediate_output_bd135, 0.002); end
  def test_intermediate_output_be135; assert_in_delta(0.013674039372141717, worksheet.intermediate_output_be135, 0.002); end
  def test_intermediate_output_bf135; assert_in_delta(0.013034519506509221, worksheet.intermediate_output_bf135, 0.002); end
  def test_intermediate_output_c136; assert_in_epsilon(6.0, worksheet.intermediate_output_c136, 0.002); end
  def test_intermediate_output_d136; assert_equal("Waste", worksheet.intermediate_output_d136); end
  def test_intermediate_output_ax136; assert_in_delta(0.01641000285058843, worksheet.intermediate_output_ax136, 0.002); end
  def test_intermediate_output_ay136; assert_in_delta(0.014058398292671621, worksheet.intermediate_output_ay136, 0.002); end
  def test_intermediate_output_az136; assert_in_delta(0.011706793734754816, worksheet.intermediate_output_az136, 0.002); end
  def test_intermediate_output_ba136; assert_in_delta(0.01138115904954508, worksheet.intermediate_output_ba136, 0.002); end
  def test_intermediate_output_bb136; assert_in_delta(0.010917263414227841, worksheet.intermediate_output_bb136, 0.002); end
  def test_intermediate_output_bc136; assert_in_delta(0.01088600593220019, worksheet.intermediate_output_bc136, 0.002); end
  def test_intermediate_output_bd136; assert_in_delta(0.010779920733775816, worksheet.intermediate_output_bd136, 0.002); end
  def test_intermediate_output_be136; assert_in_delta(0.010599007818954724, worksheet.intermediate_output_be136, 0.002); end
  def test_intermediate_output_bf136; assert_in_delta(0.010343267187736923, worksheet.intermediate_output_bf136, 0.002); end
  def test_intermediate_output_c137; assert_in_epsilon(7.0, worksheet.intermediate_output_c137, 0.002); end
  def test_intermediate_output_d137; assert_equal("Other", worksheet.intermediate_output_d137); end
  def test_intermediate_output_ax137; assert_in_delta(0.0, (worksheet.intermediate_output_ax137||0), 0.002); end
  def test_intermediate_output_ay137; assert_in_delta(0.0, (worksheet.intermediate_output_ay137||0), 0.002); end
  def test_intermediate_output_az137; assert_in_delta(0.0, (worksheet.intermediate_output_az137||0), 0.002); end
  def test_intermediate_output_ba137; assert_in_delta(0.0, (worksheet.intermediate_output_ba137||0), 0.002); end
  def test_intermediate_output_bb137; assert_in_delta(0.0, (worksheet.intermediate_output_bb137||0), 0.002); end
  def test_intermediate_output_bc137; assert_in_delta(0.0, (worksheet.intermediate_output_bc137||0), 0.002); end
  def test_intermediate_output_bd137; assert_in_delta(0.0, (worksheet.intermediate_output_bd137||0), 0.002); end
  def test_intermediate_output_be137; assert_in_delta(0.0, (worksheet.intermediate_output_be137||0), 0.002); end
  def test_intermediate_output_bf137; assert_in_delta(0.0, (worksheet.intermediate_output_bf137||0), 0.002); end
  def test_intermediate_output_c138; assert_equal("X2", worksheet.intermediate_output_c138); end
  def test_intermediate_output_d138; assert_equal("Bioenergy credit", worksheet.intermediate_output_d138); end
  def test_intermediate_output_ax138; assert_in_delta(-0.005613885808296621, worksheet.intermediate_output_ax138, 0.002); end
  def test_intermediate_output_ay138; assert_in_delta(-0.006359133272619555, worksheet.intermediate_output_ay138, 0.002); end
  def test_intermediate_output_az138; assert_in_delta(-0.009061672738148466, worksheet.intermediate_output_az138, 0.002); end
  def test_intermediate_output_ba138; assert_in_delta(-0.019983840491524164, worksheet.intermediate_output_ba138, 0.002); end
  def test_intermediate_output_bb138; assert_in_delta(-0.02042904743853215, worksheet.intermediate_output_bb138, 0.002); end
  def test_intermediate_output_bc138; assert_in_delta(-0.021011254204526444, worksheet.intermediate_output_bc138, 0.002); end
  def test_intermediate_output_bd138; assert_in_delta(-0.021681590729247777, worksheet.intermediate_output_bd138, 0.002); end
  def test_intermediate_output_be138; assert_in_delta(-0.02245593894276481, worksheet.intermediate_output_be138, 0.002); end
  def test_intermediate_output_bf138; assert_in_delta(-0.02333607477862315, worksheet.intermediate_output_bf138, 0.002); end
  def test_intermediate_output_c139; assert_equal("X3", worksheet.intermediate_output_c139); end
  def test_intermediate_output_d139; assert_equal("Carbon capture", worksheet.intermediate_output_d139); end
  def test_intermediate_output_ax139; assert_in_delta(0.0, (worksheet.intermediate_output_ax139||0), 0.002); end
  def test_intermediate_output_ay139; assert_in_delta(0.0, (worksheet.intermediate_output_ay139||0), 0.002); end
  def test_intermediate_output_az139; assert_in_delta(0.0, (worksheet.intermediate_output_az139||0), 0.002); end
  def test_intermediate_output_ba139; assert_in_delta(0.0, (worksheet.intermediate_output_ba139||0), 0.002); end
  def test_intermediate_output_bb139; assert_in_delta(0.0, (worksheet.intermediate_output_bb139||0), 0.002); end
  def test_intermediate_output_bc139; assert_in_delta(0.0, (worksheet.intermediate_output_bc139||0), 0.002); end
  def test_intermediate_output_bd139; assert_in_delta(0.0, (worksheet.intermediate_output_bd139||0), 0.002); end
  def test_intermediate_output_be139; assert_in_delta(0.0, (worksheet.intermediate_output_be139||0), 0.002); end
  def test_intermediate_output_bf139; assert_in_delta(0.0, (worksheet.intermediate_output_bf139||0), 0.002); end
  def test_intermediate_output_d140; assert_equal("Total", worksheet.intermediate_output_d140); end
  def test_intermediate_output_ax140; assert_in_delta(0.46350585047009585, worksheet.intermediate_output_ax140, 0.002); end
  def test_intermediate_output_ay140; assert_in_delta(0.5301115436897402, worksheet.intermediate_output_ay140, 0.002); end
  def test_intermediate_output_az140; assert_in_delta(0.6225711996248626, worksheet.intermediate_output_az140, 0.002); end
  def test_intermediate_output_ba140; assert_in_delta(0.76131448079778, worksheet.intermediate_output_ba140, 0.002); end
  def test_intermediate_output_bb140; assert_in_delta(0.9091264720172963, worksheet.intermediate_output_bb140, 0.002); end
  def test_intermediate_output_bc140; assert_in_epsilon(1.0541994885583388, worksheet.intermediate_output_bc140, 0.002); end
  def test_intermediate_output_bd140; assert_in_epsilon(1.2123770937473055, worksheet.intermediate_output_bd140, 0.002); end
  def test_intermediate_output_be140; assert_in_epsilon(1.3461152682024702, worksheet.intermediate_output_be140, 0.002); end
  def test_intermediate_output_bf140; assert_in_epsilon(1.5082790320259087, worksheet.intermediate_output_bf140, 0.002); end
  def test_intermediate_output_e143; assert_equal("Adjustment factor:", worksheet.intermediate_output_e143); end
  def test_intermediate_output_ax143; assert_in_delta(1.0, worksheet.intermediate_output_ax143, 0.002); end
  def test_intermediate_output_be143; assert_equal("% reduction 1990-2050", worksheet.intermediate_output_be143); end
  def test_intermediate_output_bf143; assert_in_delta(-0.5082790320259087, worksheet.intermediate_output_bf143, 0.002); end
  def test_intermediate_output_c145; assert_equal("Emissions by sector", worksheet.intermediate_output_c145); end
  def test_intermediate_output_f145; assert_equal("Sector", worksheet.intermediate_output_f145); end
  def test_intermediate_output_ax145; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax145, 0.002); end
  def test_intermediate_output_ay145; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay145, 0.002); end
  def test_intermediate_output_az145; assert_in_epsilon(2020.0, worksheet.intermediate_output_az145, 0.002); end
  def test_intermediate_output_ba145; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba145, 0.002); end
  def test_intermediate_output_bb145; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb145, 0.002); end
  def test_intermediate_output_bc145; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc145, 0.002); end
  def test_intermediate_output_bd145; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd145, 0.002); end
  def test_intermediate_output_be145; assert_in_epsilon(2045.0, worksheet.intermediate_output_be145, 0.002); end
  def test_intermediate_output_bf145; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf145, 0.002); end
  def test_intermediate_output_c146; assert_equal("I", worksheet.intermediate_output_c146); end
  def test_intermediate_output_f146; assert_equal("Hydrocarbon fuel power generation", worksheet.intermediate_output_f146); end
  def test_intermediate_output_ax146; assert_in_epsilon(149.82544637164256, worksheet.intermediate_output_ax146, 0.002); end
  def test_intermediate_output_ay146; assert_in_epsilon(176.2632160347501, worksheet.intermediate_output_ay146, 0.002); end
  def test_intermediate_output_az146; assert_in_epsilon(235.5504577440285, worksheet.intermediate_output_az146, 0.002); end
  def test_intermediate_output_ba146; assert_in_epsilon(341.82007565998407, worksheet.intermediate_output_ba146, 0.002); end
  def test_intermediate_output_bb146; assert_in_epsilon(453.9456967479541, worksheet.intermediate_output_bb146, 0.002); end
  def test_intermediate_output_bc146; assert_in_epsilon(567.8068741282668, worksheet.intermediate_output_bc146, 0.002); end
  def test_intermediate_output_bd146; assert_in_epsilon(700.5023667242193, worksheet.intermediate_output_bd146, 0.002); end
  def test_intermediate_output_be146; assert_in_epsilon(818.1523852014301, worksheet.intermediate_output_be146, 0.002); end
  def test_intermediate_output_bf146; assert_in_epsilon(960.6440232645404, worksheet.intermediate_output_bf146, 0.002); end
  def test_intermediate_output_c147; assert_equal("II", worksheet.intermediate_output_c147); end
  def test_intermediate_output_f147; assert_equal("Nuclear power generation", worksheet.intermediate_output_f147); end
  def test_intermediate_output_ax147; assert_in_delta(0.0, (worksheet.intermediate_output_ax147||0), 0.002); end
  def test_intermediate_output_ay147; assert_in_delta(0.0, (worksheet.intermediate_output_ay147||0), 0.002); end
  def test_intermediate_output_az147; assert_in_delta(0.0, (worksheet.intermediate_output_az147||0), 0.002); end
  def test_intermediate_output_ba147; assert_in_delta(0.0, (worksheet.intermediate_output_ba147||0), 0.002); end
  def test_intermediate_output_bb147; assert_in_delta(0.0, (worksheet.intermediate_output_bb147||0), 0.002); end
  def test_intermediate_output_bc147; assert_in_delta(0.0, (worksheet.intermediate_output_bc147||0), 0.002); end
  def test_intermediate_output_bd147; assert_in_delta(0.0, (worksheet.intermediate_output_bd147||0), 0.002); end
  def test_intermediate_output_be147; assert_in_delta(0.0, (worksheet.intermediate_output_be147||0), 0.002); end
  def test_intermediate_output_bf147; assert_in_delta(0.0, (worksheet.intermediate_output_bf147||0), 0.002); end
  def test_intermediate_output_c148; assert_equal("III", worksheet.intermediate_output_c148); end
  def test_intermediate_output_f148; assert_equal("National renewable power generation", worksheet.intermediate_output_f148); end
  def test_intermediate_output_ax148; assert_in_delta(0.0, (worksheet.intermediate_output_ax148||0), 0.002); end
  def test_intermediate_output_ay148; assert_in_delta(0.0, (worksheet.intermediate_output_ay148||0), 0.002); end
  def test_intermediate_output_az148; assert_in_delta(0.0, (worksheet.intermediate_output_az148||0), 0.002); end
  def test_intermediate_output_ba148; assert_in_delta(0.0, (worksheet.intermediate_output_ba148||0), 0.002); end
  def test_intermediate_output_bb148; assert_in_delta(0.0, (worksheet.intermediate_output_bb148||0), 0.002); end
  def test_intermediate_output_bc148; assert_in_delta(0.0, (worksheet.intermediate_output_bc148||0), 0.002); end
  def test_intermediate_output_bd148; assert_in_delta(0.0, (worksheet.intermediate_output_bd148||0), 0.002); end
  def test_intermediate_output_be148; assert_in_delta(0.0, (worksheet.intermediate_output_be148||0), 0.002); end
  def test_intermediate_output_bf148; assert_in_delta(0.0, (worksheet.intermediate_output_bf148||0), 0.002); end
  def test_intermediate_output_c149; assert_equal("IV", worksheet.intermediate_output_c149); end
  def test_intermediate_output_f149; assert_equal("Distributed renewable power generation", worksheet.intermediate_output_f149); end
  def test_intermediate_output_ax149; assert_in_delta(0.0, (worksheet.intermediate_output_ax149||0), 0.002); end
  def test_intermediate_output_ay149; assert_in_delta(0.0, (worksheet.intermediate_output_ay149||0), 0.002); end
  def test_intermediate_output_az149; assert_in_delta(0.0, (worksheet.intermediate_output_az149||0), 0.002); end
  def test_intermediate_output_ba149; assert_in_delta(0.0, (worksheet.intermediate_output_ba149||0), 0.002); end
  def test_intermediate_output_bb149; assert_in_delta(0.0, (worksheet.intermediate_output_bb149||0), 0.002); end
  def test_intermediate_output_bc149; assert_in_delta(0.0, (worksheet.intermediate_output_bc149||0), 0.002); end
  def test_intermediate_output_bd149; assert_in_delta(0.0, (worksheet.intermediate_output_bd149||0), 0.002); end
  def test_intermediate_output_be149; assert_in_delta(0.0, (worksheet.intermediate_output_be149||0), 0.002); end
  def test_intermediate_output_bf149; assert_in_delta(0.0, (worksheet.intermediate_output_bf149||0), 0.002); end
  def test_intermediate_output_c150; assert_equal("V", worksheet.intermediate_output_c150); end
  def test_intermediate_output_f150; assert_equal("Bioenergy", worksheet.intermediate_output_f150); end
  def test_intermediate_output_ax150; assert_in_epsilon(-4.488785452273249, worksheet.intermediate_output_ax150, 0.002); end
  def test_intermediate_output_ay150; assert_in_epsilon(-5.084675017973435, worksheet.intermediate_output_ay150, 0.002); end
  def test_intermediate_output_az150; assert_in_epsilon(-7.2455881984895445, worksheet.intermediate_output_az150, 0.002); end
  def test_intermediate_output_ba150; assert_in_epsilon(-15.978802480508723, worksheet.intermediate_output_ba150, 0.002); end
  def test_intermediate_output_bb150; assert_in_epsilon(-16.33478379812423, worksheet.intermediate_output_bb150, 0.002); end
  def test_intermediate_output_bc150; assert_in_epsilon(-16.800308276293695, worksheet.intermediate_output_bc150, 0.002); end
  def test_intermediate_output_bd150; assert_in_epsilon(-17.336300090706736, worksheet.intermediate_output_bd150, 0.002); end
  def test_intermediate_output_be150; assert_in_epsilon(-17.95545821299916, worksheet.intermediate_output_be150, 0.002); end
  def test_intermediate_output_bf150; assert_in_epsilon(-18.659202655072882, worksheet.intermediate_output_bf150, 0.002); end
  def test_intermediate_output_c151; assert_equal("VI", worksheet.intermediate_output_c151); end
  def test_intermediate_output_f151; assert_equal("Agriculture and waste", worksheet.intermediate_output_f151); end
  def test_intermediate_output_ax151; assert_in_epsilon(38.80475217298037, worksheet.intermediate_output_ax151, 0.002); end
  def test_intermediate_output_ay151; assert_in_epsilon(39.546887715564566, worksheet.intermediate_output_ay151, 0.002); end
  def test_intermediate_output_az151; assert_in_epsilon(40.212005590643216, worksheet.intermediate_output_az151, 0.002); end
  def test_intermediate_output_ba151; assert_in_epsilon(42.96075350266692, worksheet.intermediate_output_ba151, 0.002); end
  def test_intermediate_output_bb151; assert_in_epsilon(44.272007596778145, worksheet.intermediate_output_bb151, 0.002); end
  def test_intermediate_output_bc151; assert_in_epsilon(44.52641645217061, worksheet.intermediate_output_bc151, 0.002); end
  def test_intermediate_output_bd151; assert_in_epsilon(43.43282969427402, worksheet.intermediate_output_bd151, 0.002); end
  def test_intermediate_output_be151; assert_in_epsilon(42.02330928564139, worksheet.intermediate_output_be151, 0.002); end
  def test_intermediate_output_bf151; assert_in_epsilon(41.32471733049437, worksheet.intermediate_output_bf151, 0.002); end
  def test_intermediate_output_c152; assert_equal("VII", worksheet.intermediate_output_c152); end
  def test_intermediate_output_f152; assert_equal("Electricity distribution, storage, and balancing", worksheet.intermediate_output_f152); end
  def test_intermediate_output_ax152; assert_in_delta(0.0, (worksheet.intermediate_output_ax152||0), 0.002); end
  def test_intermediate_output_ay152; assert_in_delta(0.0, (worksheet.intermediate_output_ay152||0), 0.002); end
  def test_intermediate_output_az152; assert_in_delta(0.0, (worksheet.intermediate_output_az152||0), 0.002); end
  def test_intermediate_output_ba152; assert_in_delta(0.0, (worksheet.intermediate_output_ba152||0), 0.002); end
  def test_intermediate_output_bb152; assert_in_delta(0.0, (worksheet.intermediate_output_bb152||0), 0.002); end
  def test_intermediate_output_bc152; assert_in_delta(0.0, (worksheet.intermediate_output_bc152||0), 0.002); end
  def test_intermediate_output_bd152; assert_in_delta(0.0, (worksheet.intermediate_output_bd152||0), 0.002); end
  def test_intermediate_output_be152; assert_in_delta(0.0, (worksheet.intermediate_output_be152||0), 0.002); end
  def test_intermediate_output_bf152; assert_in_delta(0.0, (worksheet.intermediate_output_bf152||0), 0.002); end
  def test_intermediate_output_c153; assert_equal("IX", worksheet.intermediate_output_c153); end
  def test_intermediate_output_f153; assert_equal("Cooling", worksheet.intermediate_output_f153); end
  def test_intermediate_output_ax153; assert_in_delta(0.0, (worksheet.intermediate_output_ax153||0), 0.002); end
  def test_intermediate_output_ay153; assert_in_delta(0.0, (worksheet.intermediate_output_ay153||0), 0.002); end
  def test_intermediate_output_az153; assert_in_delta(0.0, (worksheet.intermediate_output_az153||0), 0.002); end
  def test_intermediate_output_ba153; assert_in_delta(0.0, (worksheet.intermediate_output_ba153||0), 0.002); end
  def test_intermediate_output_bb153; assert_in_delta(0.0, (worksheet.intermediate_output_bb153||0), 0.002); end
  def test_intermediate_output_bc153; assert_in_delta(0.0, (worksheet.intermediate_output_bc153||0), 0.002); end
  def test_intermediate_output_bd153; assert_in_delta(0.0, (worksheet.intermediate_output_bd153||0), 0.002); end
  def test_intermediate_output_be153; assert_in_delta(0.0, (worksheet.intermediate_output_be153||0), 0.002); end
  def test_intermediate_output_bf153; assert_in_delta(0.0, (worksheet.intermediate_output_bf153||0), 0.002); end
  def test_intermediate_output_c154; assert_equal("X", worksheet.intermediate_output_c154); end
  def test_intermediate_output_f154; assert_equal("Lighting and appliances", worksheet.intermediate_output_f154); end
  def test_intermediate_output_ax154; assert_in_epsilon(26.551572676409187, worksheet.intermediate_output_ax154, 0.002); end
  def test_intermediate_output_ay154; assert_in_epsilon(32.87150512725749, worksheet.intermediate_output_ay154, 0.002); end
  def test_intermediate_output_az154; assert_in_epsilon(38.13345246562365, worksheet.intermediate_output_az154, 0.002); end
  def test_intermediate_output_ba154; assert_in_epsilon(42.108179368363096, worksheet.intermediate_output_ba154, 0.002); end
  def test_intermediate_output_bb154; assert_in_epsilon(44.523804077092755, worksheet.intermediate_output_bb154, 0.002); end
  def test_intermediate_output_bc154; assert_in_epsilon(45.310261758407876, worksheet.intermediate_output_bc154, 0.002); end
  def test_intermediate_output_bd154; assert_in_epsilon(44.05416481030397, worksheet.intermediate_output_bd154, 0.002); end
  def test_intermediate_output_be154; assert_in_epsilon(40.438397322955865, worksheet.intermediate_output_be154, 0.002); end
  def test_intermediate_output_bf154; assert_in_epsilon(34.113699796258274, worksheet.intermediate_output_bf154, 0.002); end
  def test_intermediate_output_c155; assert_equal("XI", worksheet.intermediate_output_c155); end
  def test_intermediate_output_f155; assert_equal("Industry", worksheet.intermediate_output_f155); end
  def test_intermediate_output_ax155; assert_in_epsilon(32.56997673022367, worksheet.intermediate_output_ax155, 0.002); end
  def test_intermediate_output_ay155; assert_in_epsilon(34.42152334469555, worksheet.intermediate_output_ay155, 0.002); end
  def test_intermediate_output_az155; assert_in_epsilon(36.874828750985216, worksheet.intermediate_output_az155, 0.002); end
  def test_intermediate_output_ba155; assert_in_epsilon(40.08131529030466, worksheet.intermediate_output_ba155, 0.002); end
  def test_intermediate_output_bb155; assert_in_epsilon(43.21379550699321, worksheet.intermediate_output_bb155, 0.002); end
  def test_intermediate_output_bc155; assert_in_epsilon(45.45665539271021, worksheet.intermediate_output_bc155, 0.002); end
  def test_intermediate_output_bd155; assert_in_epsilon(48.16070684099529, worksheet.intermediate_output_bd155, 0.002); end
  def test_intermediate_output_be155; assert_in_epsilon(51.497256642102606, worksheet.intermediate_output_be155, 0.002); end
  def test_intermediate_output_bf155; assert_in_epsilon(57.09757103685284, worksheet.intermediate_output_bf155, 0.002); end
  def test_intermediate_output_c156; assert_equal("XII", worksheet.intermediate_output_c156); end
  def test_intermediate_output_f156; assert_equal("Transport", worksheet.intermediate_output_f156); end
  def test_intermediate_output_ax156; assert_in_epsilon(50.67482999898204, worksheet.intermediate_output_ax156, 0.002); end
  def test_intermediate_output_ay156; assert_in_epsilon(75.83904100694159, worksheet.intermediate_output_ay156, 0.002); end
  def test_intermediate_output_az156; assert_in_epsilon(90.12402484682984, worksheet.intermediate_output_az156, 0.002); end
  def test_intermediate_output_ba156; assert_in_epsilon(99.34115735105043, worksheet.intermediate_output_ba156, 0.002); end
  def test_intermediate_output_bb156; assert_in_epsilon(104.81008438794412, worksheet.intermediate_output_bb156, 0.002); end
  def test_intermediate_output_bc156; assert_in_epsilon(110.23279421241261, worksheet.intermediate_output_bc156, 0.002); end
  def test_intermediate_output_bd156; assert_in_epsilon(110.49844035427047, worksheet.intermediate_output_bd156, 0.002); end
  def test_intermediate_output_be156; assert_in_epsilon(108.61323792120592, worksheet.intermediate_output_be156, 0.002); end
  def test_intermediate_output_bf156; assert_in_epsilon(104.63623483709486, worksheet.intermediate_output_bf156, 0.002); end
  def test_intermediate_output_c157; assert_equal("XIII", worksheet.intermediate_output_c157); end
  def test_intermediate_output_f157; assert_equal("Food consumption [UNUSED]", worksheet.intermediate_output_f157); end
  def test_intermediate_output_ax157; assert_in_delta(0.0, (worksheet.intermediate_output_ax157||0), 0.002); end
  def test_intermediate_output_ay157; assert_in_delta(0.0, (worksheet.intermediate_output_ay157||0), 0.002); end
  def test_intermediate_output_az157; assert_in_delta(0.0, (worksheet.intermediate_output_az157||0), 0.002); end
  def test_intermediate_output_ba157; assert_in_delta(0.0, (worksheet.intermediate_output_ba157||0), 0.002); end
  def test_intermediate_output_bb157; assert_in_delta(0.0, (worksheet.intermediate_output_bb157||0), 0.002); end
  def test_intermediate_output_bc157; assert_in_delta(0.0, (worksheet.intermediate_output_bc157||0), 0.002); end
  def test_intermediate_output_bd157; assert_in_delta(0.0, (worksheet.intermediate_output_bd157||0), 0.002); end
  def test_intermediate_output_be157; assert_in_delta(0.0, (worksheet.intermediate_output_be157||0), 0.002); end
  def test_intermediate_output_bf157; assert_in_delta(0.0, (worksheet.intermediate_output_bf157||0), 0.002); end
  def test_intermediate_output_c158; assert_equal("XV", worksheet.intermediate_output_c158); end
  def test_intermediate_output_f158; assert_equal("Fossil fuel production", worksheet.intermediate_output_f158); end
  def test_intermediate_output_ax158; assert_in_epsilon(72.30442388792358, worksheet.intermediate_output_ax158, 0.002); end
  def test_intermediate_output_ay158; assert_in_epsilon(65.80125497410792, worksheet.intermediate_output_ay158, 0.002); end
  def test_intermediate_output_az158; assert_in_epsilon(60.13734772078316, worksheet.intermediate_output_az158, 0.002); end
  def test_intermediate_output_ba158; assert_in_epsilon(54.51866722091039, worksheet.intermediate_output_ba158, 0.002); end
  def test_intermediate_output_bb158; assert_in_epsilon(48.725977289365, worksheet.intermediate_output_bb158, 0.002); end
  def test_intermediate_output_bc158; assert_in_epsilon(42.75770266896423, worksheet.intermediate_output_bc158, 0.002); end
  def test_intermediate_output_bd158; assert_in_epsilon(36.60695070900211, worksheet.intermediate_output_bd158, 0.002); end
  def test_intermediate_output_be158; assert_in_epsilon(30.27042787687535, worksheet.intermediate_output_be158, 0.002); end
  def test_intermediate_output_bf158; assert_in_epsilon(23.748100218639582, worksheet.intermediate_output_bf158, 0.002); end
  def test_intermediate_output_c159; assert_equal("XVI", worksheet.intermediate_output_c159); end
  def test_intermediate_output_f159; assert_equal("Transfers", worksheet.intermediate_output_f159); end
  def test_intermediate_output_ax159; assert_in_epsilon(4.370651364088464, worksheet.intermediate_output_ax159, 0.002); end
  def test_intermediate_output_ay159; assert_in_epsilon(4.2111057063232735, worksheet.intermediate_output_ay159, 0.002); end
  def test_intermediate_output_az159; assert_in_epsilon(4.01279213994525, worksheet.intermediate_output_az159, 0.002); end
  def test_intermediate_output_ba159; assert_in_epsilon(3.8851839538645887, worksheet.intermediate_output_ba159, 0.002); end
  def test_intermediate_output_bb159; assert_in_epsilon(3.7683719979188792, worksheet.intermediate_output_bb159, 0.002); end
  def test_intermediate_output_bc159; assert_in_epsilon(3.6329351356818416, worksheet.intermediate_output_bc159, 0.002); end
  def test_intermediate_output_bd159; assert_in_epsilon(3.480797942780612, worksheet.intermediate_output_bd159, 0.002); end
  def test_intermediate_output_be159; assert_in_epsilon(3.295595643324091, worksheet.intermediate_output_be159, 0.002); end
  def test_intermediate_output_bf159; assert_in_epsilon(3.0939106800964886, worksheet.intermediate_output_bf159, 0.002); end
  def test_intermediate_output_f160; assert_equal("Total", worksheet.intermediate_output_f160); end
  def test_intermediate_output_ax160; assert_in_epsilon(370.61286774997666, worksheet.intermediate_output_ax160, 0.002); end
  def test_intermediate_output_ay160; assert_in_epsilon(423.8698588916671, worksheet.intermediate_output_ay160, 0.002); end
  def test_intermediate_output_az160; assert_in_epsilon(497.7993210603493, worksheet.intermediate_output_az160, 0.002); end
  def test_intermediate_output_ba160; assert_in_epsilon(608.7365298666355, worksheet.intermediate_output_ba160, 0.002); end
  def test_intermediate_output_bb160; assert_in_epsilon(726.924953805922, worksheet.intermediate_output_bb160, 0.002); end
  def test_intermediate_output_bc160; assert_in_epsilon(842.9233314723205, worksheet.intermediate_output_bc160, 0.002); end
  def test_intermediate_output_bd160; assert_in_epsilon(969.3999569851392, worksheet.intermediate_output_bd160, 0.002); end
  def test_intermediate_output_be160; assert_in_epsilon(1076.3351516805362, worksheet.intermediate_output_be160, 0.002); end
  def test_intermediate_output_bf160; assert_in_epsilon(1205.999054508904, worksheet.intermediate_output_bf160, 0.002); end
  def test_intermediate_output_f161; assert_equal("Emissions in the time period (up to and including year above)", worksheet.intermediate_output_f161); end
  def test_intermediate_output_ay161; assert_in_epsilon(2012.8353121749547, worksheet.intermediate_output_ay161, 0.002); end
  def test_intermediate_output_az161; assert_in_epsilon(2341.137680964382, worksheet.intermediate_output_az161, 0.002); end
  def test_intermediate_output_ba161; assert_in_epsilon(2821.808231720605, worksheet.intermediate_output_ba161, 0.002); end
  def test_intermediate_output_bb161; assert_in_epsilon(3398.247921151037, worksheet.intermediate_output_bb161, 0.002); end
  def test_intermediate_output_bc161; assert_in_epsilon(3982.6199020288054, worksheet.intermediate_output_bc161, 0.002); end
  def test_intermediate_output_bd161; assert_in_epsilon(4594.046533900058, worksheet.intermediate_output_bd161, 0.002); end
  def test_intermediate_output_be161; assert_in_epsilon(5167.805369011887, worksheet.intermediate_output_be161, 0.002); end
  def test_intermediate_output_bf161; assert_in_epsilon(5770.667466887784, worksheet.intermediate_output_bf161, 0.002); end
  def test_intermediate_output_bg161; assert_equal("REFERENCED - All costs", worksheet.intermediate_output_bg161); end
  def test_intermediate_output_c162; assert_equal("Modelled emissions", worksheet.intermediate_output_c162); end
  def test_intermediate_output_f162; assert_equal("Cumulative emissions", worksheet.intermediate_output_f162); end
  def test_intermediate_output_ay162; assert_in_epsilon(2012.8353121749547, worksheet.intermediate_output_ay162, 0.002); end
  def test_intermediate_output_az162; assert_in_epsilon(4353.972993139337, worksheet.intermediate_output_az162, 0.002); end
  def test_intermediate_output_ba162; assert_in_epsilon(7175.781224859942, worksheet.intermediate_output_ba162, 0.002); end
  def test_intermediate_output_bb162; assert_in_epsilon(10574.02914601098, worksheet.intermediate_output_bb162, 0.002); end
  def test_intermediate_output_bc162; assert_in_epsilon(14556.649048039786, worksheet.intermediate_output_bc162, 0.002); end
  def test_intermediate_output_bd162; assert_in_epsilon(19150.695581939843, worksheet.intermediate_output_bd162, 0.002); end
  def test_intermediate_output_be162; assert_in_epsilon(24318.50095095173, worksheet.intermediate_output_be162, 0.002); end
  def test_intermediate_output_bf162; assert_in_epsilon(30089.168417839515, worksheet.intermediate_output_bf162, 0.002); end
  def test_intermediate_output_d164; assert_equal("IPCC Sector", worksheet.intermediate_output_d164); end
  def test_intermediate_output_f164; assert_equal("Actuals, GHG Inv.", worksheet.intermediate_output_f164); end
  def test_intermediate_output_bf164; assert_equal("Mt CO2e", worksheet.intermediate_output_bf164); end
  def test_intermediate_output_c165; assert_equal("1A", worksheet.intermediate_output_c165); end
  def test_intermediate_output_d165; assert_equal("Fuel Combustion", worksheet.intermediate_output_d165); end
  def test_intermediate_output_f165; assert_in_epsilon(532.6387375112939, worksheet.intermediate_output_f165, 0.002); end
  def test_intermediate_output_ax165; assert_in_epsilon(298.04832073922194, worksheet.intermediate_output_ax165, 0.002); end
  def test_intermediate_output_ay165; assert_in_epsilon(351.36400665801204, worksheet.intermediate_output_ay165, 0.002); end
  def test_intermediate_output_az165; assert_in_epsilon(426.896483363418, worksheet.intermediate_output_az165, 0.002); end
  def test_intermediate_output_ba165; assert_in_epsilon(543.5740414298612, worksheet.intermediate_output_ba165, 0.002); end
  def test_intermediate_output_bb165; assert_in_epsilon(660.9657331020279, worksheet.intermediate_output_bb165, 0.002); end
  def test_intermediate_output_bc165; assert_in_epsilon(777.3299898915644, worksheet.intermediate_output_bc165, 0.002); end
  def test_intermediate_output_bd165; assert_in_epsilon(905.5858087823941, worksheet.intermediate_output_bd165, 0.002); end
  def test_intermediate_output_be165; assert_in_epsilon(1014.7110394560555, worksheet.intermediate_output_be165, 0.002); end
  def test_intermediate_output_bf165; assert_in_epsilon(1144.3237264158995, worksheet.intermediate_output_bf165, 0.002); end
  def test_intermediate_output_c166; assert_equal("1B", worksheet.intermediate_output_c166); end
  def test_intermediate_output_d166; assert_equal("Fugitive Emissions from Fuels", worksheet.intermediate_output_d166); end
  def test_intermediate_output_f166; assert_in_epsilon(13.3650064404099, worksheet.intermediate_output_f166, 0.002); end
  def test_intermediate_output_ax166; assert_in_epsilon(11.039051364088465, worksheet.intermediate_output_ax166, 0.002); end
  def test_intermediate_output_ay166; assert_in_epsilon(10.879505706323274, worksheet.intermediate_output_ay166, 0.002); end
  def test_intermediate_output_az166; assert_in_epsilon(10.77769594895811, worksheet.intermediate_output_az166, 0.002); end
  def test_intermediate_output_ba166; assert_in_epsilon(10.98611163754235, worksheet.intermediate_output_ba166, 0.002); end
  def test_intermediate_output_bb166; assert_in_epsilon(11.213723556261542, worksheet.intermediate_output_bb166, 0.002); end
  def test_intermediate_output_bc166; assert_in_epsilon(11.422710568689407, worksheet.intermediate_output_bc166, 0.002); end
  def test_intermediate_output_bd166; assert_in_epsilon(11.61499725045308, worksheet.intermediate_output_bd166, 0.002); end
  def test_intermediate_output_be166; assert_in_epsilon(11.774218825661459, worksheet.intermediate_output_be166, 0.002); end
  def test_intermediate_output_bf166; assert_in_epsilon(11.916957737098759, worksheet.intermediate_output_bf166, 0.002); end
  def test_intermediate_output_c167; assert_in_delta(1.0, worksheet.intermediate_output_c167, 0.002); end
  def test_intermediate_output_d167; assert_equal("Fuel Combustion", worksheet.intermediate_output_d167); end
  def test_intermediate_output_f167; assert_in_epsilon(546.0037439517039, worksheet.intermediate_output_f167, 0.002); end
  def test_intermediate_output_ax167; assert_in_epsilon(309.0873721033104, worksheet.intermediate_output_ax167, 0.002); end
  def test_intermediate_output_ay167; assert_in_epsilon(362.24351236433534, worksheet.intermediate_output_ay167, 0.002); end
  def test_intermediate_output_az167; assert_in_epsilon(437.6741793123761, worksheet.intermediate_output_az167, 0.002); end
  def test_intermediate_output_ba167; assert_in_epsilon(554.5601530674035, worksheet.intermediate_output_ba167, 0.002); end
  def test_intermediate_output_bb167; assert_in_epsilon(672.1794566582895, worksheet.intermediate_output_bb167, 0.002); end
  def test_intermediate_output_bc167; assert_in_epsilon(788.7527004602538, worksheet.intermediate_output_bc167, 0.002); end
  def test_intermediate_output_bd167; assert_in_epsilon(917.2008060328471, worksheet.intermediate_output_bd167, 0.002); end
  def test_intermediate_output_be167; assert_in_epsilon(1026.4852582817168, worksheet.intermediate_output_be167, 0.002); end
  def test_intermediate_output_bf167; assert_in_epsilon(1156.2406841529983, worksheet.intermediate_output_bf167, 0.002); end
  def test_intermediate_output_c168; assert_in_epsilon(2.0, worksheet.intermediate_output_c168, 0.002); end
  def test_intermediate_output_d168; assert_equal("Industrial Processes", worksheet.intermediate_output_d168); end
  def test_intermediate_output_f168; assert_in_epsilon(27.8913120599484, worksheet.intermediate_output_f168, 0.002); end
  def test_intermediate_output_ax168; assert_in_epsilon(27.891312059948405, worksheet.intermediate_output_ax168, 0.002); end
  def test_intermediate_output_ay168; assert_in_epsilon(27.858091129429077, worksheet.intermediate_output_ay168, 0.002); end
  def test_intermediate_output_az168; assert_in_epsilon(27.86547682600942, worksheet.intermediate_output_az168, 0.002); end
  def test_intermediate_output_ba168; assert_in_epsilon(27.914626100053326, worksheet.intermediate_output_ba168, 0.002); end
  def test_intermediate_output_bb168; assert_in_epsilon(27.542607500392428, worksheet.intermediate_output_bb168, 0.002); end
  def test_intermediate_output_bc168; assert_in_epsilon(27.19371178333455, worksheet.intermediate_output_bc168, 0.002); end
  def test_intermediate_output_bd168; assert_in_epsilon(26.867422835474294, worksheet.intermediate_output_bd168, 0.002); end
  def test_intermediate_output_be168; assert_in_epsilon(26.563252748959535, worksheet.intermediate_output_be168, 0.002); end
  def test_intermediate_output_bf168; assert_in_epsilon(27.891312059948405, worksheet.intermediate_output_bf168, 0.002); end
  def test_intermediate_output_c169; assert_in_epsilon(3.0, worksheet.intermediate_output_c169, 0.002); end
  def test_intermediate_output_d169; assert_equal("Solvent and Other Product Use", worksheet.intermediate_output_d169); end
  def test_intermediate_output_f169; assert_in_delta(0.0, (worksheet.intermediate_output_f169||0), 0.002); end
  def test_intermediate_output_ax169; assert_in_delta(0.0, (worksheet.intermediate_output_ax169||0), 0.002); end
  def test_intermediate_output_ay169; assert_in_delta(0.0, (worksheet.intermediate_output_ay169||0), 0.002); end
  def test_intermediate_output_az169; assert_in_delta(0.0, (worksheet.intermediate_output_az169||0), 0.002); end
  def test_intermediate_output_ba169; assert_in_delta(0.0, (worksheet.intermediate_output_ba169||0), 0.002); end
  def test_intermediate_output_bb169; assert_in_delta(0.0, (worksheet.intermediate_output_bb169||0), 0.002); end
  def test_intermediate_output_bc169; assert_in_delta(0.0, (worksheet.intermediate_output_bc169||0), 0.002); end
  def test_intermediate_output_bd169; assert_in_delta(0.0, (worksheet.intermediate_output_bd169||0), 0.002); end
  def test_intermediate_output_be169; assert_in_delta(0.0, (worksheet.intermediate_output_be169||0), 0.002); end
  def test_intermediate_output_bf169; assert_in_delta(0.0, (worksheet.intermediate_output_bf169||0), 0.002); end
  def test_intermediate_output_c170; assert_in_epsilon(4.0, worksheet.intermediate_output_c170, 0.002); end
  def test_intermediate_output_d170; assert_equal("Agriculture", worksheet.intermediate_output_d170); end
  def test_intermediate_output_f170; assert_in_epsilon(43.4591660991799, worksheet.intermediate_output_f170, 0.002); end
  def test_intermediate_output_ax170; assert_in_epsilon(23.28, worksheet.intermediate_output_ax170, 0.002); end
  def test_intermediate_output_ay170; assert_in_epsilon(22.545258398704277, worksheet.intermediate_output_ay170, 0.002); end
  def test_intermediate_output_az170; assert_in_epsilon(21.83370602510076, worksheet.intermediate_output_az170, 0.002); end
  def test_intermediate_output_ba170; assert_in_epsilon(21.83370602510076, worksheet.intermediate_output_ba170, 0.002); end
  def test_intermediate_output_bb170; assert_in_epsilon(21.83370602510076, worksheet.intermediate_output_bb170, 0.002); end
  def test_intermediate_output_bc170; assert_in_epsilon(21.83370602510076, worksheet.intermediate_output_bc170, 0.002); end
  def test_intermediate_output_bd170; assert_in_epsilon(21.83370602510076, worksheet.intermediate_output_bd170, 0.002); end
  def test_intermediate_output_be170; assert_in_epsilon(21.83370602510076, worksheet.intermediate_output_be170, 0.002); end
  def test_intermediate_output_bf170; assert_in_epsilon(21.83370602510076, worksheet.intermediate_output_bf170, 0.002); end
  def test_intermediate_output_c171; assert_in_epsilon(5.0, worksheet.intermediate_output_c171, 0.002); end
  def test_intermediate_output_d171; assert_equal("LULUCF", worksheet.intermediate_output_d171); end
  def test_intermediate_output_f171; assert_in_epsilon(-1.7798396847837301, worksheet.intermediate_output_f171, 0.002); end
  def test_intermediate_output_ax171; assert_in_epsilon(1.7217577099999988, worksheet.intermediate_output_ax171, 0.002); end
  def test_intermediate_output_ay171; assert_in_epsilon(5.066771169999999, worksheet.intermediate_output_ay171, 0.002); end
  def test_intermediate_output_az171; assert_in_epsilon(8.31095673, worksheet.intermediate_output_az171, 0.002); end
  def test_intermediate_output_ba171; assert_in_epsilon(11.30662978, worksheet.intermediate_output_ba171, 0.002); end
  def test_intermediate_output_bb171; assert_in_epsilon(12.974674579999999, worksheet.intermediate_output_bb171, 0.002); end
  def test_intermediate_output_bc171; assert_in_epsilon(13.239221689999997, worksheet.intermediate_output_bc171, 0.002); end
  def test_intermediate_output_bd171; assert_in_epsilon(12.214846649999998, worksheet.intermediate_output_bd171, 0.002); end
  def test_intermediate_output_be171; assert_in_epsilon(10.93357277, worksheet.intermediate_output_be171, 0.002); end
  def test_intermediate_output_bf171; assert_in_epsilon(10.422221529999998, worksheet.intermediate_output_bf171, 0.002); end
  def test_intermediate_output_c172; assert_in_epsilon(6.0, worksheet.intermediate_output_c172, 0.002); end
  def test_intermediate_output_d172; assert_equal("Waste", worksheet.intermediate_output_d172); end
  def test_intermediate_output_f172; assert_in_epsilon(22.8602295816192, worksheet.intermediate_output_f172, 0.002); end
  def test_intermediate_output_ax172; assert_in_epsilon(13.121211328991082, worksheet.intermediate_output_ax172, 0.002); end
  def test_intermediate_output_ay172; assert_in_epsilon(11.24090084717184, worksheet.intermediate_output_ay172, 0.002); end
  def test_intermediate_output_az172; assert_in_epsilon(9.360590365352598, worksheet.intermediate_output_az172, 0.002); end
  def test_intermediate_output_ba172; assert_in_epsilon(9.10021737458659, worksheet.intermediate_output_ba172, 0.002); end
  def test_intermediate_output_bb172; assert_in_epsilon(8.729292840263563, worksheet.intermediate_output_bb172, 0.002); end
  def test_intermediate_output_bc172; assert_in_epsilon(8.704299789925228, worksheet.intermediate_output_bc172, 0.002); end
  def test_intermediate_output_bd172; assert_in_epsilon(8.619475532423394, worksheet.intermediate_output_bd172, 0.002); end
  def test_intermediate_output_be172; assert_in_epsilon(8.47482006775806, worksheet.intermediate_output_be172, 0.002); end
  def test_intermediate_output_bf172; assert_in_epsilon(8.270333395929237, worksheet.intermediate_output_bf172, 0.002); end
  def test_intermediate_output_c173; assert_in_epsilon(7.0, worksheet.intermediate_output_c173, 0.002); end
  def test_intermediate_output_d173; assert_equal("Other", worksheet.intermediate_output_d173); end
  def test_intermediate_output_ax173; assert_in_delta(0.0, (worksheet.intermediate_output_ax173||0), 0.002); end
  def test_intermediate_output_ay173; assert_in_delta(0.0, (worksheet.intermediate_output_ay173||0), 0.002); end
  def test_intermediate_output_az173; assert_in_delta(0.0, (worksheet.intermediate_output_az173||0), 0.002); end
  def test_intermediate_output_ba173; assert_in_delta(0.0, (worksheet.intermediate_output_ba173||0), 0.002); end
  def test_intermediate_output_bb173; assert_in_delta(0.0, (worksheet.intermediate_output_bb173||0), 0.002); end
  def test_intermediate_output_bc173; assert_in_delta(0.0, (worksheet.intermediate_output_bc173||0), 0.002); end
  def test_intermediate_output_bd173; assert_in_delta(0.0, (worksheet.intermediate_output_bd173||0), 0.002); end
  def test_intermediate_output_be173; assert_in_delta(0.0, (worksheet.intermediate_output_be173||0), 0.002); end
  def test_intermediate_output_bf173; assert_in_delta(0.0, (worksheet.intermediate_output_bf173||0), 0.002); end
  def test_intermediate_output_c174; assert_equal("X2", worksheet.intermediate_output_c174); end
  def test_intermediate_output_d174; assert_equal("Bioenergy credit", worksheet.intermediate_output_d174); end
  def test_intermediate_output_ax174; assert_in_epsilon(-4.488785452273249, worksheet.intermediate_output_ax174, 0.002); end
  def test_intermediate_output_ay174; assert_in_epsilon(-5.084675017973435, worksheet.intermediate_output_ay174, 0.002); end
  def test_intermediate_output_az174; assert_in_epsilon(-7.2455881984895445, worksheet.intermediate_output_az174, 0.002); end
  def test_intermediate_output_ba174; assert_in_epsilon(-15.978802480508723, worksheet.intermediate_output_ba174, 0.002); end
  def test_intermediate_output_bb174; assert_in_epsilon(-16.33478379812423, worksheet.intermediate_output_bb174, 0.002); end
  def test_intermediate_output_bc174; assert_in_epsilon(-16.800308276293695, worksheet.intermediate_output_bc174, 0.002); end
  def test_intermediate_output_bd174; assert_in_epsilon(-17.336300090706736, worksheet.intermediate_output_bd174, 0.002); end
  def test_intermediate_output_be174; assert_in_epsilon(-17.95545821299916, worksheet.intermediate_output_be174, 0.002); end
  def test_intermediate_output_bf174; assert_in_epsilon(-18.659202655072882, worksheet.intermediate_output_bf174, 0.002); end
  def test_intermediate_output_c175; assert_equal("X3", worksheet.intermediate_output_c175); end
  def test_intermediate_output_d175; assert_equal("Carbon capture", worksheet.intermediate_output_d175); end
  def test_intermediate_output_ax175; assert_in_delta(0.0, (worksheet.intermediate_output_ax175||0), 0.002); end
  def test_intermediate_output_ay175; assert_in_delta(0.0, (worksheet.intermediate_output_ay175||0), 0.002); end
  def test_intermediate_output_az175; assert_in_delta(0.0, (worksheet.intermediate_output_az175||0), 0.002); end
  def test_intermediate_output_ba175; assert_in_delta(0.0, (worksheet.intermediate_output_ba175||0), 0.002); end
  def test_intermediate_output_bb175; assert_in_delta(0.0, (worksheet.intermediate_output_bb175||0), 0.002); end
  def test_intermediate_output_bc175; assert_in_delta(0.0, (worksheet.intermediate_output_bc175||0), 0.002); end
  def test_intermediate_output_bd175; assert_in_delta(0.0, (worksheet.intermediate_output_bd175||0), 0.002); end
  def test_intermediate_output_be175; assert_in_delta(0.0, (worksheet.intermediate_output_be175||0), 0.002); end
  def test_intermediate_output_bf175; assert_in_delta(0.0, (worksheet.intermediate_output_bf175||0), 0.002); end
  def test_intermediate_output_d176; assert_equal("Total", worksheet.intermediate_output_d176); end
  def test_intermediate_output_f176; assert_in_epsilon(638.4346120076677, worksheet.intermediate_output_f176, 0.002); end
  def test_intermediate_output_ax176; assert_in_epsilon(370.6128677499766, worksheet.intermediate_output_ax176, 0.002); end
  def test_intermediate_output_ay176; assert_in_epsilon(423.86985889166704, worksheet.intermediate_output_ay176, 0.002); end
  def test_intermediate_output_az176; assert_in_epsilon(497.7993210603493, worksheet.intermediate_output_az176, 0.002); end
  def test_intermediate_output_ba176; assert_in_epsilon(608.7365298666354, worksheet.intermediate_output_ba176, 0.002); end
  def test_intermediate_output_bb176; assert_in_epsilon(726.9249538059221, worksheet.intermediate_output_bb176, 0.002); end
  def test_intermediate_output_bc176; assert_in_epsilon(842.9233314723208, worksheet.intermediate_output_bc176, 0.002); end
  def test_intermediate_output_bd176; assert_in_epsilon(969.3999569851389, worksheet.intermediate_output_bd176, 0.002); end
  def test_intermediate_output_be176; assert_in_epsilon(1076.3351516805358, worksheet.intermediate_output_be176, 0.002); end
  def test_intermediate_output_bf176; assert_in_epsilon(1205.9990545089036, worksheet.intermediate_output_bf176, 0.002); end
  def test_intermediate_output_bg176; assert_equal("REFERENCED - All costs", worksheet.intermediate_output_bg176); end
  def test_intermediate_output_c180; assert_equal("Please note: emissions by sector need to account for bio-energy, which is accounted for seperately (in V). ", worksheet.intermediate_output_c180); end
  def test_intermediate_output_c181; assert_equal("Cumulative emissions are estimates based on a linear trajectory between the 5 year time periods", worksheet.intermediate_output_c181); end
  def test_intermediate_output_c184; assert_equal("Targets", worksheet.intermediate_output_c184); end
  def test_intermediate_output_aw184; assert_equal("2050 target", worksheet.intermediate_output_aw184); end
  def test_intermediate_output_ax184; assert_equal("2020 target ", worksheet.intermediate_output_ax184); end
  def test_intermediate_output_az184; assert_equal("2050 target", worksheet.intermediate_output_az184); end
  def test_intermediate_output_ba184; assert_equal("2020 target", worksheet.intermediate_output_ba184); end
  def test_intermediate_output_bc184; assert_equal("Actuals, as % of 2010, modelled", worksheet.intermediate_output_bc184); end
  def test_intermediate_output_e185; assert_equal("Base year (1990)", worksheet.intermediate_output_e185); end
  def test_intermediate_output_aw185; assert_equal("(20% of base)", worksheet.intermediate_output_aw185); end
  def test_intermediate_output_ax185; assert_equal("(66% of base)", worksheet.intermediate_output_ax185); end
  def test_intermediate_output_az185; assert_equal("% of 2010", worksheet.intermediate_output_az185); end
  def test_intermediate_output_ba185; assert_equal("% of 2010", worksheet.intermediate_output_ba185); end
  def test_intermediate_output_bd185; assert_in_epsilon(2020.0, worksheet.intermediate_output_bd185, 0.002); end
  def test_intermediate_output_be185; assert_in_epsilon(2030.0, worksheet.intermediate_output_be185, 0.002); end
  def test_intermediate_output_bf185; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf185, 0.002); end
  def test_intermediate_output_d186; assert_equal("Kyoto agreed sectors", worksheet.intermediate_output_d186); end
  def test_intermediate_output_e186; assert_in_epsilon(777.11767, worksheet.intermediate_output_e186, 0.002); end
  def test_intermediate_output_aw186; assert_in_epsilon(155.42353400000002, worksheet.intermediate_output_aw186, 0.002); end
  def test_intermediate_output_ax186; assert_in_epsilon(512.8976622, worksheet.intermediate_output_ax186, 0.002); end
  def test_intermediate_output_d187; assert_equal("International bunkers (CO2 only)", worksheet.intermediate_output_d187); end
  def test_intermediate_output_e187; assert_in_epsilon(22.4685, worksheet.intermediate_output_e187, 0.002); end
  def test_intermediate_output_az187; assert_in_delta(0.0, (worksheet.intermediate_output_az187||0), 0.002); end
  def test_intermediate_output_ba187; assert_in_delta(0.0, (worksheet.intermediate_output_ba187||0), 0.002); end
  def test_intermediate_output_d188; assert_equal("Total", worksheet.intermediate_output_d188); end
  def test_intermediate_output_e188; assert_in_epsilon(799.5861699999999, worksheet.intermediate_output_e188, 0.002); end
  def test_intermediate_output_aw188; assert_in_epsilon(159.917234, worksheet.intermediate_output_aw188, 0.002); end
  def test_intermediate_output_ax188; assert_in_epsilon(527.7268722, worksheet.intermediate_output_ax188, 0.002); end
  def test_intermediate_output_az188; assert_in_epsilon(345.0166461497932, worksheet.intermediate_output_az188, 0.002); end
  def test_intermediate_output_ba188; assert_in_epsilon(1138.5549322943175, worksheet.intermediate_output_ba188, 0.002); end
  def test_intermediate_output_bd188; assert_in_epsilon(1.3431787300924893, worksheet.intermediate_output_bd188, 0.002); end
  def test_intermediate_output_be188; assert_in_epsilon(1.9614131538906017, worksheet.intermediate_output_be188, 0.002); end
  def test_intermediate_output_bf188; assert_in_epsilon(3.2540668699136925, worksheet.intermediate_output_bf188, 0.002); end
  def test_intermediate_output_d189; assert_equal("Target, for chart", worksheet.intermediate_output_d189); end
  def test_intermediate_output_aw189; assert_in_delta(0.2, worksheet.intermediate_output_aw189, 0.002); end
  def test_intermediate_output_ax189; assert_in_delta(0.2, worksheet.intermediate_output_ax189, 0.002); end
  def test_intermediate_output_ay189; assert_in_delta(0.2, worksheet.intermediate_output_ay189, 0.002); end
  def test_intermediate_output_az189; assert_in_delta(0.2, worksheet.intermediate_output_az189, 0.002); end
  def test_intermediate_output_ba189; assert_in_delta(0.2, worksheet.intermediate_output_ba189, 0.002); end
  def test_intermediate_output_bb189; assert_in_delta(0.2, worksheet.intermediate_output_bb189, 0.002); end
  def test_intermediate_output_bc189; assert_in_delta(0.2, worksheet.intermediate_output_bc189, 0.002); end
  def test_intermediate_output_bd189; assert_in_delta(0.2, worksheet.intermediate_output_bd189, 0.002); end
  def test_intermediate_output_be189; assert_in_delta(0.2, worksheet.intermediate_output_be189, 0.002); end
  def test_intermediate_output_bf189; assert_in_delta(0.2, worksheet.intermediate_output_bf189, 0.002); end
  def test_intermediate_output_d190; assert_equal("Dummy, for chart", worksheet.intermediate_output_d190); end
  def test_intermediate_output_aw190; assert_in_delta(0.0, (worksheet.intermediate_output_aw190||0), 0.002); end
  def test_intermediate_output_ax190; assert_in_delta(0.0, (worksheet.intermediate_output_ax190||0), 0.002); end
  def test_intermediate_output_ay190; assert_in_delta(0.0, (worksheet.intermediate_output_ay190||0), 0.002); end
  def test_intermediate_output_az190; assert_in_delta(0.0, (worksheet.intermediate_output_az190||0), 0.002); end
  def test_intermediate_output_ba190; assert_in_delta(0.0, (worksheet.intermediate_output_ba190||0), 0.002); end
  def test_intermediate_output_bb190; assert_in_delta(0.0, (worksheet.intermediate_output_bb190||0), 0.002); end
  def test_intermediate_output_bc190; assert_in_delta(0.0, (worksheet.intermediate_output_bc190||0), 0.002); end
  def test_intermediate_output_bd190; assert_in_delta(0.0, (worksheet.intermediate_output_bd190||0), 0.002); end
  def test_intermediate_output_be190; assert_in_delta(0.0, (worksheet.intermediate_output_be190||0), 0.002); end
  def test_intermediate_output_bf190; assert_in_delta(0.0, (worksheet.intermediate_output_bf190||0), 0.002); end
  def test_intermediate_output_b193; assert_equal("Bio-energy - Production and Use", worksheet.intermediate_output_b193); end
  def test_intermediate_output_b195; assert_equal("Production", worksheet.intermediate_output_b195); end
  def test_intermediate_output_c197; assert_equal("Domestic", worksheet.intermediate_output_c197); end
  def test_intermediate_output_ax197; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax197, 0.002); end
  def test_intermediate_output_ay197; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay197, 0.002); end
  def test_intermediate_output_az197; assert_in_epsilon(2020.0, worksheet.intermediate_output_az197, 0.002); end
  def test_intermediate_output_ba197; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba197, 0.002); end
  def test_intermediate_output_bb197; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb197, 0.002); end
  def test_intermediate_output_bc197; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc197, 0.002); end
  def test_intermediate_output_bd197; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd197, 0.002); end
  def test_intermediate_output_be197; assert_in_epsilon(2045.0, worksheet.intermediate_output_be197, 0.002); end
  def test_intermediate_output_bf197; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf197, 0.002); end
  def test_intermediate_output_c198; assert_equal("V.a", worksheet.intermediate_output_c198); end
  def test_intermediate_output_d198; assert_equal("V.03", worksheet.intermediate_output_d198); end
  def test_intermediate_output_e198; assert_equal("Solid hydrocarbons", worksheet.intermediate_output_e198); end
  def test_intermediate_output_aj198; assert_in_epsilon(11.2811, worksheet.intermediate_output_aj198, 0.002); end
  def test_intermediate_output_ak198; assert_in_epsilon(11.5128859, worksheet.intermediate_output_ak198, 0.002); end
  def test_intermediate_output_al198; assert_in_epsilon(9.9829594, worksheet.intermediate_output_al198, 0.002); end
  def test_intermediate_output_am198; assert_in_epsilon(10.7253023, worksheet.intermediate_output_am198, 0.002); end
  def test_intermediate_output_an198; assert_in_epsilon(11.7831671, worksheet.intermediate_output_an198, 0.002); end
  def test_intermediate_output_ao198; assert_in_epsilon(11.9234249, worksheet.intermediate_output_ao198, 0.002); end
  def test_intermediate_output_ap198; assert_in_epsilon(8.2292717, worksheet.intermediate_output_ap198, 0.002); end
  def test_intermediate_output_aq198; assert_in_epsilon(13.56519449, worksheet.intermediate_output_aq198, 0.002); end
  def test_intermediate_output_ar198; assert_in_epsilon(13.10799238, worksheet.intermediate_output_ar198, 0.002); end
  def test_intermediate_output_as198; assert_in_epsilon(14.11044992, worksheet.intermediate_output_as198, 0.002); end
  def test_intermediate_output_at198; assert_in_epsilon(15.68101481, worksheet.intermediate_output_at198, 0.002); end
  def test_intermediate_output_au198; assert_in_epsilon(18.7866056, worksheet.intermediate_output_au198, 0.002); end
  def test_intermediate_output_av198; assert_in_epsilon(19.95985165, worksheet.intermediate_output_av198, 0.002); end
  def test_intermediate_output_aw198; assert_equal("DUKES - Commodity balances, production of wood waste, wood, poultry litter, meal and bone, and farm waste, and straw, SRC, and other plant-based biomass ", worksheet.intermediate_output_aw198); end
  def test_intermediate_output_ax198; assert_in_epsilon(43.57390766800001, worksheet.intermediate_output_ax198, 0.002); end
  def test_intermediate_output_ay198; assert_in_epsilon(45.981975894864384, worksheet.intermediate_output_ay198, 0.002); end
  def test_intermediate_output_az198; assert_in_epsilon(48.63429728053235, worksheet.intermediate_output_az198, 0.002); end
  def test_intermediate_output_ba198; assert_in_epsilon(54.15390536434295, worksheet.intermediate_output_ba198, 0.002); end
  def test_intermediate_output_bb198; assert_in_epsilon(57.260492152394946, worksheet.intermediate_output_bb198, 0.002); end
  def test_intermediate_output_bc198; assert_in_epsilon(60.4121398735751, worksheet.intermediate_output_bc198, 0.002); end
  def test_intermediate_output_bd198; assert_in_epsilon(63.61404473087052, worksheet.intermediate_output_bd198, 0.002); end
  def test_intermediate_output_be198; assert_in_epsilon(66.99928395527837, worksheet.intermediate_output_be198, 0.002); end
  def test_intermediate_output_bf198; assert_in_epsilon(70.41188163530069, worksheet.intermediate_output_bf198, 0.002); end
  def test_intermediate_output_c199; assert_equal("V.a", worksheet.intermediate_output_c199); end
  def test_intermediate_output_d199; assert_equal("V.04", worksheet.intermediate_output_d199); end
  def test_intermediate_output_e199; assert_equal("Liquid hydrocarbons", worksheet.intermediate_output_e199); end
  def test_intermediate_output_aj199; assert_in_delta(0.0, (worksheet.intermediate_output_aj199||0), 0.002); end
  def test_intermediate_output_ak199; assert_in_delta(0.0, (worksheet.intermediate_output_ak199||0), 0.002); end
  def test_intermediate_output_al199; assert_in_delta(0.0, (worksheet.intermediate_output_al199||0), 0.002); end
  def test_intermediate_output_am199; assert_in_delta(0.0, (worksheet.intermediate_output_am199||0), 0.002); end
  def test_intermediate_output_an199; assert_in_delta(0.0, (worksheet.intermediate_output_an199||0), 0.002); end
  def test_intermediate_output_ao199; assert_in_delta(0.0, (worksheet.intermediate_output_ao199||0), 0.002); end
  def test_intermediate_output_ap199; assert_in_delta(0.0, (worksheet.intermediate_output_ap199||0), 0.002); end
  def test_intermediate_output_aq199; assert_in_delta(0.09313615, worksheet.intermediate_output_aq199, 0.002); end
  def test_intermediate_output_ar199; assert_in_epsilon(2.691796244, worksheet.intermediate_output_ar199, 0.002); end
  def test_intermediate_output_as199; assert_in_epsilon(4.599912358, worksheet.intermediate_output_as199, 0.002); end
  def test_intermediate_output_at199; assert_in_epsilon(3.516727083, worksheet.intermediate_output_at199, 0.002); end
  def test_intermediate_output_au199; assert_in_epsilon(2.629156279, worksheet.intermediate_output_au199, 0.002); end
  def test_intermediate_output_av199; assert_in_epsilon(3.539047787, worksheet.intermediate_output_av199, 0.002); end
  def test_intermediate_output_aw199; assert_equal("DUKES - Commodity balances, production of liquid biofuels", worksheet.intermediate_output_aw199); end
  def test_intermediate_output_ax199; assert_in_epsilon(2.672768746666667, worksheet.intermediate_output_ax199, 0.002); end
  def test_intermediate_output_ay199; assert_in_epsilon(2.8758586901572527, worksheet.intermediate_output_ay199, 0.002); end
  def test_intermediate_output_az199; assert_in_epsilon(3.094380393390782, worksheet.intermediate_output_az199, 0.002); end
  def test_intermediate_output_ba199; assert_in_epsilon(3.3939484964401596, worksheet.intermediate_output_ba199, 0.002); end
  def test_intermediate_output_bb199; assert_in_epsilon(3.65183717805978, worksheet.intermediate_output_bb199, 0.002); end
  def test_intermediate_output_bc199; assert_in_epsilon(3.929321493548699, worksheet.intermediate_output_bc199, 0.002); end
  def test_intermediate_output_bd199; assert_in_epsilon(4.22789041428918, worksheet.intermediate_output_bd199, 0.002); end
  def test_intermediate_output_be199; assert_in_epsilon(4.549146050936843, worksheet.intermediate_output_be199, 0.002); end
  def test_intermediate_output_bf199; assert_in_epsilon(4.894812250291876, worksheet.intermediate_output_bf199, 0.002); end
  def test_intermediate_output_c200; assert_equal("V.a", worksheet.intermediate_output_c200); end
  def test_intermediate_output_d200; assert_equal("V.05", worksheet.intermediate_output_d200); end
  def test_intermediate_output_e200; assert_equal("Gaseous hydrocarbons", worksheet.intermediate_output_e200); end
  def test_intermediate_output_aj200; assert_in_epsilon(4.679912, worksheet.intermediate_output_aj200, 0.002); end
  def test_intermediate_output_ak200; assert_in_epsilon(6.65236, worksheet.intermediate_output_ak200, 0.002); end
  def test_intermediate_output_al200; assert_in_epsilon(8.5030419, worksheet.intermediate_output_al200, 0.002); end
  def test_intermediate_output_am200; assert_in_epsilon(9.7205866, worksheet.intermediate_output_am200, 0.002); end
  def test_intermediate_output_an200; assert_in_epsilon(10.375123, worksheet.intermediate_output_an200, 0.002); end
  def test_intermediate_output_ao200; assert_in_epsilon(12.654603, worksheet.intermediate_output_ao200, 0.002); end
  def test_intermediate_output_ap200; assert_in_epsilon(17.4844257, worksheet.intermediate_output_ap200, 0.002); end
  def test_intermediate_output_aq200; assert_in_epsilon(18.91593462, worksheet.intermediate_output_aq200, 0.002); end
  def test_intermediate_output_ar200; assert_in_epsilon(19.24482717, worksheet.intermediate_output_ar200, 0.002); end
  def test_intermediate_output_as200; assert_in_epsilon(20.29461125, worksheet.intermediate_output_as200, 0.002); end
  def test_intermediate_output_at200; assert_in_epsilon(20.91263605, worksheet.intermediate_output_at200, 0.002); end
  def test_intermediate_output_au200; assert_in_epsilon(21.92331406, worksheet.intermediate_output_au200, 0.002); end
  def test_intermediate_output_av200; assert_in_epsilon(22.89564828, worksheet.intermediate_output_av200, 0.002); end
  def test_intermediate_output_aw200; assert_equal("DUKES - Commodity balances, production of sewage gas and landfill gas", worksheet.intermediate_output_aw200); end
  def test_intermediate_output_ax200; assert_in_epsilon(18.21910735250313, worksheet.intermediate_output_ax200, 0.002); end
  def test_intermediate_output_ay200; assert_in_epsilon(20.69782488237147, worksheet.intermediate_output_ay200, 0.002); end
  def test_intermediate_output_az200; assert_in_epsilon(31.367059010000336, worksheet.intermediate_output_az200, 0.002); end
  def test_intermediate_output_ba200; assert_in_epsilon(35.0505337631886, worksheet.intermediate_output_ba200, 0.002); end
  def test_intermediate_output_bb200; assert_in_epsilon(35.86780566180724, worksheet.intermediate_output_bb200, 0.002); end
  def test_intermediate_output_bc200; assert_in_epsilon(37.038571500109896, worksheet.intermediate_output_bc200, 0.002); end
  def test_intermediate_output_bd200; assert_in_epsilon(38.40816616678621, worksheet.intermediate_output_bd200, 0.002); end
  def test_intermediate_output_be200; assert_in_epsilon(40.01569028436923, worksheet.intermediate_output_be200, 0.002); end
  def test_intermediate_output_bf200; assert_in_epsilon(41.83385069432951, worksheet.intermediate_output_bf200, 0.002); end
  def test_intermediate_output_c201; assert_equal("V.a", worksheet.intermediate_output_c201); end
  def test_intermediate_output_d201; assert_equal("V.16", worksheet.intermediate_output_d201); end
  def test_intermediate_output_e201; assert_equal("Traditional Fuel", worksheet.intermediate_output_e201); end
  def test_intermediate_output_ax201; assert_in_epsilon(204.5862760316, worksheet.intermediate_output_ax201, 0.002); end
  def test_intermediate_output_ay201; assert_in_epsilon(207.71462238928498, worksheet.intermediate_output_ay201, 0.002); end
  def test_intermediate_output_az201; assert_in_epsilon(210.94646951499553, worksheet.intermediate_output_az201, 0.002); end
  def test_intermediate_output_ba201; assert_in_epsilon(214.21404551092039, worksheet.intermediate_output_ba201, 0.002); end
  def test_intermediate_output_bb201; assert_in_epsilon(217.59471440997265, worksheet.intermediate_output_bb201, 0.002); end
  def test_intermediate_output_bc201; assert_in_epsilon(221.01956840323288, worksheet.intermediate_output_bc201, 0.002); end
  def test_intermediate_output_bd201; assert_in_epsilon(224.4904785011234, worksheet.intermediate_output_bd201, 0.002); end
  def test_intermediate_output_be201; assert_in_epsilon(228.04566580047737, worksheet.intermediate_output_be201, 0.002); end
  def test_intermediate_output_bf201; assert_in_epsilon(231.6412044667125, worksheet.intermediate_output_bf201, 0.002); end
  def test_intermediate_output_c203; assert_equal("Imports", worksheet.intermediate_output_c203); end
  def test_intermediate_output_c204; assert_equal("V.b", worksheet.intermediate_output_c204); end
  def test_intermediate_output_d204; assert_equal("V.03", worksheet.intermediate_output_d204); end
  def test_intermediate_output_e204; assert_equal("Solid hydrocarbons", worksheet.intermediate_output_e204); end
  def test_intermediate_output_aj204; assert_in_delta(0.0, (worksheet.intermediate_output_aj204||0), 0.002); end
  def test_intermediate_output_ak204; assert_in_delta(0.0, (worksheet.intermediate_output_ak204||0), 0.002); end
  def test_intermediate_output_al204; assert_in_delta(0.0, (worksheet.intermediate_output_al204||0), 0.002); end
  def test_intermediate_output_am204; assert_in_delta(0.0, (worksheet.intermediate_output_am204||0), 0.002); end
  def test_intermediate_output_an204; assert_in_delta(0.0, (worksheet.intermediate_output_an204||0), 0.002); end
  def test_intermediate_output_ao204; assert_in_epsilon(1.2843009, worksheet.intermediate_output_ao204, 0.002); end
  def test_intermediate_output_ap204; assert_in_epsilon(4.67526, worksheet.intermediate_output_ap204, 0.002); end
  def test_intermediate_output_aq204; assert_in_epsilon(4.89331583, worksheet.intermediate_output_aq204, 0.002); end
  def test_intermediate_output_ar204; assert_in_epsilon(5.78000326, worksheet.intermediate_output_ar204, 0.002); end
  def test_intermediate_output_as204; assert_in_epsilon(4.398455251, worksheet.intermediate_output_as204, 0.002); end
  def test_intermediate_output_at204; assert_in_epsilon(5.033138643, worksheet.intermediate_output_at204, 0.002); end
  def test_intermediate_output_au204; assert_in_epsilon(4.917245238, worksheet.intermediate_output_au204, 0.002); end
  def test_intermediate_output_av204; assert_in_epsilon(8.756573386, worksheet.intermediate_output_av204, 0.002); end
  def test_intermediate_output_aw204; assert_equal("DUKES - Commodity balances, imports of wood waste, wood, poultry litter, meal and bone, and farm waste, and straw, SRC, and other plant-based biomass ", worksheet.intermediate_output_aw204); end
  def test_intermediate_output_ax204; assert_in_epsilon(-42.053526133110374, worksheet.intermediate_output_ax204, 0.002); end
  def test_intermediate_output_ay204; assert_in_epsilon(-44.17252600175473, worksheet.intermediate_output_ay204, 0.002); end
  def test_intermediate_output_az204; assert_in_epsilon(-46.360095195136935, worksheet.intermediate_output_az204, 0.002); end
  def test_intermediate_output_ba204; assert_in_epsilon(-25.968784767031313, worksheet.intermediate_output_ba204, 0.002); end
  def test_intermediate_output_bb204; assert_in_epsilon(-28.617153639937943, worksheet.intermediate_output_bb204, 0.002); end
  def test_intermediate_output_bc204; assert_in_epsilon(-31.182007578489703, worksheet.intermediate_output_bc204, 0.002); end
  def test_intermediate_output_bd204; assert_in_epsilon(-33.70422358656603, worksheet.intermediate_output_bd204, 0.002); end
  def test_intermediate_output_be204; assert_in_epsilon(-36.30030769572962, worksheet.intermediate_output_be204, 0.002); end
  def test_intermediate_output_bf204; assert_in_epsilon(-38.79476778873158, worksheet.intermediate_output_bf204, 0.002); end
  def test_intermediate_output_c205; assert_equal("V.b", worksheet.intermediate_output_c205); end
  def test_intermediate_output_d205; assert_equal("V.04", worksheet.intermediate_output_d205); end
  def test_intermediate_output_e205; assert_equal("Liquid hydrocarbons", worksheet.intermediate_output_e205); end
  def test_intermediate_output_aj205; assert_in_delta(0.0, (worksheet.intermediate_output_aj205||0), 0.002); end
  def test_intermediate_output_ak205; assert_in_delta(0.0, (worksheet.intermediate_output_ak205||0), 0.002); end
  def test_intermediate_output_al205; assert_in_delta(0.0, (worksheet.intermediate_output_al205||0), 0.002); end
  def test_intermediate_output_am205; assert_in_delta(0.0, (worksheet.intermediate_output_am205||0), 0.002); end
  def test_intermediate_output_an205; assert_in_delta(0.0, (worksheet.intermediate_output_an205||0), 0.002); end
  def test_intermediate_output_ao205; assert_in_delta(0.0, (worksheet.intermediate_output_ao205||0), 0.002); end
  def test_intermediate_output_ap205; assert_in_delta(0.0, (worksheet.intermediate_output_ap205||0), 0.002); end
  def test_intermediate_output_aq205; assert_in_delta(0.768079488, worksheet.intermediate_output_aq205, 0.002); end
  def test_intermediate_output_ar205; assert_in_delta(0.621433135, worksheet.intermediate_output_ar205, 0.002); end
  def test_intermediate_output_as205; assert_in_delta(0.883831113, worksheet.intermediate_output_as205, 0.002); end
  def test_intermediate_output_at205; assert_in_epsilon(6.362225731, worksheet.intermediate_output_at205, 0.002); end
  def test_intermediate_output_au205; assert_in_epsilon(9.448472566, worksheet.intermediate_output_au205, 0.002); end
  def test_intermediate_output_av205; assert_in_epsilon(11.52719409, worksheet.intermediate_output_av205, 0.002); end
  def test_intermediate_output_aw205; assert_equal("DUKES - Commodity balances, imports of liquid biofuels", worksheet.intermediate_output_aw205); end
  def test_intermediate_output_ax205; assert_in_delta(0.0, (worksheet.intermediate_output_ax205||0), 0.002); end
  def test_intermediate_output_ay205; assert_in_delta(0.0, (worksheet.intermediate_output_ay205||0), 0.002); end
  def test_intermediate_output_az205; assert_in_delta(0.0, (worksheet.intermediate_output_az205||0), 0.002); end
  def test_intermediate_output_ba205; assert_in_delta(0.0, (worksheet.intermediate_output_ba205||0), 0.002); end
  def test_intermediate_output_bb205; assert_in_delta(0.0, (worksheet.intermediate_output_bb205||0), 0.002); end
  def test_intermediate_output_bc205; assert_in_delta(0.0, (worksheet.intermediate_output_bc205||0), 0.002); end
  def test_intermediate_output_bd205; assert_in_delta(0.0, (worksheet.intermediate_output_bd205||0), 0.002); end
  def test_intermediate_output_be205; assert_in_delta(0.0, (worksheet.intermediate_output_be205||0), 0.002); end
  def test_intermediate_output_bf205; assert_in_delta(0.0, (worksheet.intermediate_output_bf205||0), 0.002); end
  def test_intermediate_output_c206; assert_equal("V.b", worksheet.intermediate_output_c206); end
  def test_intermediate_output_d206; assert_equal("V.05", worksheet.intermediate_output_d206); end
  def test_intermediate_output_e206; assert_equal("Gaseous hydrocarbons", worksheet.intermediate_output_e206); end
  def test_intermediate_output_aj206; assert_in_delta(0.0, (worksheet.intermediate_output_aj206||0), 0.002); end
  def test_intermediate_output_ak206; assert_in_delta(0.0, (worksheet.intermediate_output_ak206||0), 0.002); end
  def test_intermediate_output_al206; assert_in_delta(0.0, (worksheet.intermediate_output_al206||0), 0.002); end
  def test_intermediate_output_am206; assert_in_delta(0.0, (worksheet.intermediate_output_am206||0), 0.002); end
  def test_intermediate_output_an206; assert_in_delta(0.0, (worksheet.intermediate_output_an206||0), 0.002); end
  def test_intermediate_output_ao206; assert_in_delta(0.0, (worksheet.intermediate_output_ao206||0), 0.002); end
  def test_intermediate_output_ap206; assert_in_delta(0.0, (worksheet.intermediate_output_ap206||0), 0.002); end
  def test_intermediate_output_aq206; assert_in_delta(0.0, (worksheet.intermediate_output_aq206||0), 0.002); end
  def test_intermediate_output_ar206; assert_in_delta(0.0, (worksheet.intermediate_output_ar206||0), 0.002); end
  def test_intermediate_output_as206; assert_in_delta(0.0, (worksheet.intermediate_output_as206||0), 0.002); end
  def test_intermediate_output_at206; assert_in_delta(0.0, (worksheet.intermediate_output_at206||0), 0.002); end
  def test_intermediate_output_au206; assert_in_delta(0.0, (worksheet.intermediate_output_au206||0), 0.002); end
  def test_intermediate_output_av206; assert_in_delta(0.0, (worksheet.intermediate_output_av206||0), 0.002); end
  def test_intermediate_output_aw206; assert_equal("DUKES - Commodity balances, imports of sewage gas and landfill gas", worksheet.intermediate_output_aw206); end
  def test_intermediate_output_ax206; assert_in_delta(0.0, (worksheet.intermediate_output_ax206||0), 0.002); end
  def test_intermediate_output_ay206; assert_in_delta(0.0, (worksheet.intermediate_output_ay206||0), 0.002); end
  def test_intermediate_output_az206; assert_in_delta(0.0, (worksheet.intermediate_output_az206||0), 0.002); end
  def test_intermediate_output_ba206; assert_in_delta(0.0, (worksheet.intermediate_output_ba206||0), 0.002); end
  def test_intermediate_output_bb206; assert_in_delta(0.0, (worksheet.intermediate_output_bb206||0), 0.002); end
  def test_intermediate_output_bc206; assert_in_delta(0.0, (worksheet.intermediate_output_bc206||0), 0.002); end
  def test_intermediate_output_bd206; assert_in_delta(0.0, (worksheet.intermediate_output_bd206||0), 0.002); end
  def test_intermediate_output_be206; assert_in_delta(0.0, (worksheet.intermediate_output_be206||0), 0.002); end
  def test_intermediate_output_bf206; assert_in_delta(0.0, (worksheet.intermediate_output_bf206||0), 0.002); end
  def test_intermediate_output_c207; assert_equal("V.b", worksheet.intermediate_output_c207); end
  def test_intermediate_output_d207; assert_equal("V.16", worksheet.intermediate_output_d207); end
  def test_intermediate_output_e207; assert_equal("Traditional Fuel", worksheet.intermediate_output_e207); end
  def test_intermediate_output_ax207; assert_in_epsilon(-1.1525306257784962, worksheet.intermediate_output_ax207, 0.002); end
  def test_intermediate_output_ay207; assert_in_epsilon(-30.032022821670978, worksheet.intermediate_output_ay207, 0.002); end
  def test_intermediate_output_az207; assert_in_epsilon(-57.84377873726257, worksheet.intermediate_output_az207, 0.002); end
  def test_intermediate_output_ba207; assert_in_epsilon(-84.55918117433103, worksheet.intermediate_output_ba207, 0.002); end
  def test_intermediate_output_bb207; assert_in_epsilon(-110.44937277112821, worksheet.intermediate_output_bb207, 0.002); end
  def test_intermediate_output_bc207; assert_in_epsilon(-135.6037108970798, worksheet.intermediate_output_bc207, 0.002); end
  def test_intermediate_output_bd207; assert_in_epsilon(-159.2414138656128, worksheet.intermediate_output_bd207, 0.002); end
  def test_intermediate_output_be207; assert_in_epsilon(-180.33781880696267, worksheet.intermediate_output_be207, 0.002); end
  def test_intermediate_output_bf207; assert_in_epsilon(-198.85030179835843, worksheet.intermediate_output_bf207, 0.002); end
  def test_intermediate_output_c209; assert_equal("Total", worksheet.intermediate_output_c209); end
  def test_intermediate_output_c210; assert_equal("V.b", worksheet.intermediate_output_c210); end
  def test_intermediate_output_d210; assert_equal("V.03", worksheet.intermediate_output_d210); end
  def test_intermediate_output_e210; assert_equal("Solid hydrocarbons", worksheet.intermediate_output_e210); end
  def test_intermediate_output_aj210; assert_in_epsilon(11.2811, worksheet.intermediate_output_aj210, 0.002); end
  def test_intermediate_output_ak210; assert_in_epsilon(11.5128859, worksheet.intermediate_output_ak210, 0.002); end
  def test_intermediate_output_al210; assert_in_epsilon(9.9829594, worksheet.intermediate_output_al210, 0.002); end
  def test_intermediate_output_am210; assert_in_epsilon(10.7253023, worksheet.intermediate_output_am210, 0.002); end
  def test_intermediate_output_an210; assert_in_epsilon(11.7831671, worksheet.intermediate_output_an210, 0.002); end
  def test_intermediate_output_ao210; assert_in_epsilon(13.2077258, worksheet.intermediate_output_ao210, 0.002); end
  def test_intermediate_output_ap210; assert_in_epsilon(12.9045317, worksheet.intermediate_output_ap210, 0.002); end
  def test_intermediate_output_aq210; assert_in_epsilon(18.45851032, worksheet.intermediate_output_aq210, 0.002); end
  def test_intermediate_output_ar210; assert_in_epsilon(18.88799564, worksheet.intermediate_output_ar210, 0.002); end
  def test_intermediate_output_as210; assert_in_epsilon(18.50890517, worksheet.intermediate_output_as210, 0.002); end
  def test_intermediate_output_at210; assert_in_epsilon(20.71415345, worksheet.intermediate_output_at210, 0.002); end
  def test_intermediate_output_au210; assert_in_epsilon(23.70385084, worksheet.intermediate_output_au210, 0.002); end
  def test_intermediate_output_av210; assert_in_epsilon(28.71642504, worksheet.intermediate_output_av210, 0.002); end
  def test_intermediate_output_aw210; assert_equal("Calculation", worksheet.intermediate_output_aw210); end
  def test_intermediate_output_ax210; assert_in_epsilon(1.520381534889637, worksheet.intermediate_output_ax210, 0.002); end
  def test_intermediate_output_ay210; assert_in_epsilon(1.809449893109651, worksheet.intermediate_output_ay210, 0.002); end
  def test_intermediate_output_az210; assert_in_epsilon(2.274202085395416, worksheet.intermediate_output_az210, 0.002); end
  def test_intermediate_output_ba210; assert_in_epsilon(28.185120597311634, worksheet.intermediate_output_ba210, 0.002); end
  def test_intermediate_output_bb210; assert_in_epsilon(28.643338512457003, worksheet.intermediate_output_bb210, 0.002); end
  def test_intermediate_output_bc210; assert_in_epsilon(29.230132295085397, worksheet.intermediate_output_bc210, 0.002); end
  def test_intermediate_output_bd210; assert_in_epsilon(29.909821144304487, worksheet.intermediate_output_bd210, 0.002); end
  def test_intermediate_output_be210; assert_in_epsilon(30.69897625954875, worksheet.intermediate_output_be210, 0.002); end
  def test_intermediate_output_bf210; assert_in_epsilon(31.617113846569104, worksheet.intermediate_output_bf210, 0.002); end
  def test_intermediate_output_c211; assert_equal("V.b", worksheet.intermediate_output_c211); end
  def test_intermediate_output_d211; assert_equal("V.04", worksheet.intermediate_output_d211); end
  def test_intermediate_output_e211; assert_equal("Liquid hydrocarbons", worksheet.intermediate_output_e211); end
  def test_intermediate_output_aj211; assert_in_delta(0.0, (worksheet.intermediate_output_aj211||0), 0.002); end
  def test_intermediate_output_ak211; assert_in_delta(0.0, (worksheet.intermediate_output_ak211||0), 0.002); end
  def test_intermediate_output_al211; assert_in_delta(0.0, (worksheet.intermediate_output_al211||0), 0.002); end
  def test_intermediate_output_am211; assert_in_delta(0.0, (worksheet.intermediate_output_am211||0), 0.002); end
  def test_intermediate_output_an211; assert_in_delta(0.0, (worksheet.intermediate_output_an211||0), 0.002); end
  def test_intermediate_output_ao211; assert_in_delta(0.0, (worksheet.intermediate_output_ao211||0), 0.002); end
  def test_intermediate_output_ap211; assert_in_delta(0.0, (worksheet.intermediate_output_ap211||0), 0.002); end
  def test_intermediate_output_aq211; assert_in_delta(0.861215638, worksheet.intermediate_output_aq211, 0.002); end
  def test_intermediate_output_ar211; assert_in_epsilon(3.313229379, worksheet.intermediate_output_ar211, 0.002); end
  def test_intermediate_output_as211; assert_in_epsilon(5.483743472, worksheet.intermediate_output_as211, 0.002); end
  def test_intermediate_output_at211; assert_in_epsilon(9.878952814, worksheet.intermediate_output_at211, 0.002); end
  def test_intermediate_output_au211; assert_in_epsilon(12.07762885, worksheet.intermediate_output_au211, 0.002); end
  def test_intermediate_output_av211; assert_in_epsilon(15.06624188, worksheet.intermediate_output_av211, 0.002); end
  def test_intermediate_output_aw211; assert_equal("Calculation", worksheet.intermediate_output_aw211); end
  def test_intermediate_output_ax211; assert_in_epsilon(2.672768746666667, worksheet.intermediate_output_ax211, 0.002); end
  def test_intermediate_output_ay211; assert_in_epsilon(2.8758586901572527, worksheet.intermediate_output_ay211, 0.002); end
  def test_intermediate_output_az211; assert_in_epsilon(3.094380393390782, worksheet.intermediate_output_az211, 0.002); end
  def test_intermediate_output_ba211; assert_in_epsilon(3.3939484964401596, worksheet.intermediate_output_ba211, 0.002); end
  def test_intermediate_output_bb211; assert_in_epsilon(3.65183717805978, worksheet.intermediate_output_bb211, 0.002); end
  def test_intermediate_output_bc211; assert_in_epsilon(3.929321493548699, worksheet.intermediate_output_bc211, 0.002); end
  def test_intermediate_output_bd211; assert_in_epsilon(4.22789041428918, worksheet.intermediate_output_bd211, 0.002); end
  def test_intermediate_output_be211; assert_in_epsilon(4.549146050936843, worksheet.intermediate_output_be211, 0.002); end
  def test_intermediate_output_bf211; assert_in_epsilon(4.894812250291876, worksheet.intermediate_output_bf211, 0.002); end
  def test_intermediate_output_c212; assert_equal("V.b", worksheet.intermediate_output_c212); end
  def test_intermediate_output_d212; assert_equal("V.05", worksheet.intermediate_output_d212); end
  def test_intermediate_output_e212; assert_equal("Gaseous hydrocarbons", worksheet.intermediate_output_e212); end
  def test_intermediate_output_aj212; assert_in_epsilon(4.679912, worksheet.intermediate_output_aj212, 0.002); end
  def test_intermediate_output_ak212; assert_in_epsilon(6.65236, worksheet.intermediate_output_ak212, 0.002); end
  def test_intermediate_output_al212; assert_in_epsilon(8.5030419, worksheet.intermediate_output_al212, 0.002); end
  def test_intermediate_output_am212; assert_in_epsilon(9.7205866, worksheet.intermediate_output_am212, 0.002); end
  def test_intermediate_output_an212; assert_in_epsilon(10.375123, worksheet.intermediate_output_an212, 0.002); end
  def test_intermediate_output_ao212; assert_in_epsilon(12.654603, worksheet.intermediate_output_ao212, 0.002); end
  def test_intermediate_output_ap212; assert_in_epsilon(17.4844257, worksheet.intermediate_output_ap212, 0.002); end
  def test_intermediate_output_aq212; assert_in_epsilon(18.91593462, worksheet.intermediate_output_aq212, 0.002); end
  def test_intermediate_output_ar212; assert_in_epsilon(19.24482717, worksheet.intermediate_output_ar212, 0.002); end
  def test_intermediate_output_as212; assert_in_epsilon(20.29461125, worksheet.intermediate_output_as212, 0.002); end
  def test_intermediate_output_at212; assert_in_epsilon(20.91263605, worksheet.intermediate_output_at212, 0.002); end
  def test_intermediate_output_au212; assert_in_epsilon(21.92331406, worksheet.intermediate_output_au212, 0.002); end
  def test_intermediate_output_av212; assert_in_epsilon(22.89564828, worksheet.intermediate_output_av212, 0.002); end
  def test_intermediate_output_aw212; assert_equal("Calculation", worksheet.intermediate_output_aw212); end
  def test_intermediate_output_ax212; assert_in_epsilon(18.21910735250313, worksheet.intermediate_output_ax212, 0.002); end
  def test_intermediate_output_ay212; assert_in_epsilon(20.69782488237147, worksheet.intermediate_output_ay212, 0.002); end
  def test_intermediate_output_az212; assert_in_epsilon(31.367059010000336, worksheet.intermediate_output_az212, 0.002); end
  def test_intermediate_output_ba212; assert_in_epsilon(35.0505337631886, worksheet.intermediate_output_ba212, 0.002); end
  def test_intermediate_output_bb212; assert_in_epsilon(35.86780566180724, worksheet.intermediate_output_bb212, 0.002); end
  def test_intermediate_output_bc212; assert_in_epsilon(37.038571500109896, worksheet.intermediate_output_bc212, 0.002); end
  def test_intermediate_output_bd212; assert_in_epsilon(38.40816616678621, worksheet.intermediate_output_bd212, 0.002); end
  def test_intermediate_output_be212; assert_in_epsilon(40.01569028436923, worksheet.intermediate_output_be212, 0.002); end
  def test_intermediate_output_bf212; assert_in_epsilon(41.83385069432951, worksheet.intermediate_output_bf212, 0.002); end
  def test_intermediate_output_c213; assert_equal("V.b", worksheet.intermediate_output_c213); end
  def test_intermediate_output_d213; assert_equal("V.16", worksheet.intermediate_output_d213); end
  def test_intermediate_output_e213; assert_equal("Traditional Fuel", worksheet.intermediate_output_e213); end
  def test_intermediate_output_ax213; assert_in_epsilon(203.4337454058215, worksheet.intermediate_output_ax213, 0.002); end
  def test_intermediate_output_ay213; assert_in_epsilon(177.682599567614, worksheet.intermediate_output_ay213, 0.002); end
  def test_intermediate_output_az213; assert_in_epsilon(153.10269077773296, worksheet.intermediate_output_az213, 0.002); end
  def test_intermediate_output_ba213; assert_in_epsilon(129.65486433658936, worksheet.intermediate_output_ba213, 0.002); end
  def test_intermediate_output_bb213; assert_in_epsilon(107.14534163884444, worksheet.intermediate_output_bb213, 0.002); end
  def test_intermediate_output_bc213; assert_in_epsilon(85.41585750615309, worksheet.intermediate_output_bc213, 0.002); end
  def test_intermediate_output_bd213; assert_in_epsilon(65.24906463551059, worksheet.intermediate_output_bd213, 0.002); end
  def test_intermediate_output_be213; assert_in_epsilon(47.70784699351469, worksheet.intermediate_output_be213, 0.002); end
  def test_intermediate_output_bf213; assert_in_epsilon(32.79090266835408, worksheet.intermediate_output_bf213, 0.002); end
  def test_intermediate_output_b216; assert_equal("Hydro-carbon use by sector and Bio-energy share", worksheet.intermediate_output_b216); end
  def test_intermediate_output_ax216; assert_equal("Please note: Bio-energy is not assigned to sectors but is assumed to replace fossil fuels up to maximum demand", worksheet.intermediate_output_ax216); end
  def test_intermediate_output_c218; assert_equal("Solid Hydrocarbon consumption", worksheet.intermediate_output_c218); end
  def test_intermediate_output_ax218; assert_in_epsilon(1.5203815348896348, worksheet.intermediate_output_ax218, 0.002); end
  def test_intermediate_output_ay218; assert_in_epsilon(1.8094498931096499, worksheet.intermediate_output_ay218, 0.002); end
  def test_intermediate_output_az218; assert_in_epsilon(2.274202085395415, worksheet.intermediate_output_az218, 0.002); end
  def test_intermediate_output_ba218; assert_in_epsilon(28.185120597311634, worksheet.intermediate_output_ba218, 0.002); end
  def test_intermediate_output_bb218; assert_in_epsilon(28.643338512457003, worksheet.intermediate_output_bb218, 0.002); end
  def test_intermediate_output_bc218; assert_in_epsilon(29.230132295085397, worksheet.intermediate_output_bc218, 0.002); end
  def test_intermediate_output_bd218; assert_in_epsilon(29.909821144304487, worksheet.intermediate_output_bd218, 0.002); end
  def test_intermediate_output_be218; assert_in_epsilon(30.69897625954875, worksheet.intermediate_output_be218, 0.002); end
  def test_intermediate_output_bf218; assert_in_epsilon(31.617113846569104, worksheet.intermediate_output_bf218, 0.002); end
  def test_intermediate_output_c219; assert_equal("V", worksheet.intermediate_output_c219); end
  def test_intermediate_output_d219; assert_equal("Share of solid biomass to total solid hydrocarbon consumption", worksheet.intermediate_output_d219); end
  def test_intermediate_output_ax219; assert_in_epsilon(1.0000000000000016, worksheet.intermediate_output_ax219, 0.002); end
  def test_intermediate_output_ay219; assert_in_epsilon(1.0000000000000007, worksheet.intermediate_output_ay219, 0.002); end
  def test_intermediate_output_az219; assert_in_epsilon(1.0000000000000004, worksheet.intermediate_output_az219, 0.002); end
  def test_intermediate_output_ba219; assert_in_delta(1.0, worksheet.intermediate_output_ba219, 0.002); end
  def test_intermediate_output_bb219; assert_in_delta(1.0, worksheet.intermediate_output_bb219, 0.002); end
  def test_intermediate_output_bc219; assert_in_delta(1.0, worksheet.intermediate_output_bc219, 0.002); end
  def test_intermediate_output_bd219; assert_in_delta(1.0, worksheet.intermediate_output_bd219, 0.002); end
  def test_intermediate_output_be219; assert_in_delta(1.0, worksheet.intermediate_output_be219, 0.002); end
  def test_intermediate_output_bf219; assert_in_delta(1.0, worksheet.intermediate_output_bf219, 0.002); end
  def test_intermediate_output_c220; assert_equal("I.c", worksheet.intermediate_output_c220); end
  def test_intermediate_output_d220; assert_equal("Coal power stations", worksheet.intermediate_output_d220); end
  def test_intermediate_output_ak220; assert_in_delta(0.0, (worksheet.intermediate_output_ak220||0), 0.002); end
  def test_intermediate_output_al220; assert_in_delta(0.0, (worksheet.intermediate_output_al220||0), 0.002); end
  def test_intermediate_output_am220; assert_in_delta(0.0, (worksheet.intermediate_output_am220||0), 0.002); end
  def test_intermediate_output_an220; assert_in_delta(0.0, (worksheet.intermediate_output_an220||0), 0.002); end
  def test_intermediate_output_ao220; assert_in_delta(0.0, (worksheet.intermediate_output_ao220||0), 0.002); end
  def test_intermediate_output_ap220; assert_in_delta(0.0, (worksheet.intermediate_output_ap220||0), 0.002); end
  def test_intermediate_output_aq220; assert_in_delta(0.0, (worksheet.intermediate_output_aq220||0), 0.002); end
  def test_intermediate_output_ar220; assert_in_delta(0.0, (worksheet.intermediate_output_ar220||0), 0.002); end
  def test_intermediate_output_as220; assert_in_delta(0.0, (worksheet.intermediate_output_as220||0), 0.002); end
  def test_intermediate_output_at220; assert_in_delta(0.0, (worksheet.intermediate_output_at220||0), 0.002); end
  def test_intermediate_output_au220; assert_in_delta(0.0, (worksheet.intermediate_output_au220||0), 0.002); end
  def test_intermediate_output_av220; assert_in_delta(0.0, (worksheet.intermediate_output_av220||0), 0.002); end
  def test_intermediate_output_aw220; assert_equal("n/a ", worksheet.intermediate_output_aw220); end
  def test_intermediate_output_ax220; assert_in_delta(0.0, (worksheet.intermediate_output_ax220||0), 0.002); end
  def test_intermediate_output_ay220; assert_in_delta(0.0, (worksheet.intermediate_output_ay220||0), 0.002); end
  def test_intermediate_output_az220; assert_in_delta(0.0, (worksheet.intermediate_output_az220||0), 0.002); end
  def test_intermediate_output_ba220; assert_in_epsilon(25.43293421052631, worksheet.intermediate_output_ba220, 0.002); end
  def test_intermediate_output_bb220; assert_in_epsilon(25.43293421052631, worksheet.intermediate_output_bb220, 0.002); end
  def test_intermediate_output_bc220; assert_in_epsilon(25.43293421052631, worksheet.intermediate_output_bc220, 0.002); end
  def test_intermediate_output_bd220; assert_in_epsilon(25.43293421052631, worksheet.intermediate_output_bd220, 0.002); end
  def test_intermediate_output_be220; assert_in_epsilon(25.43293421052631, worksheet.intermediate_output_be220, 0.002); end
  def test_intermediate_output_bf220; assert_in_epsilon(25.43293421052631, worksheet.intermediate_output_bf220, 0.002); end
  def test_intermediate_output_c221; assert_equal("I.b", worksheet.intermediate_output_c221); end
  def test_intermediate_output_d221; assert_equal("Biomass power station", worksheet.intermediate_output_d221); end
  def test_intermediate_output_ak221; assert_in_delta(0.0, (worksheet.intermediate_output_ak221||0), 0.002); end
  def test_intermediate_output_al221; assert_in_delta(0.0, (worksheet.intermediate_output_al221||0), 0.002); end
  def test_intermediate_output_am221; assert_in_delta(0.0, (worksheet.intermediate_output_am221||0), 0.002); end
  def test_intermediate_output_an221; assert_in_delta(0.0, (worksheet.intermediate_output_an221||0), 0.002); end
  def test_intermediate_output_ao221; assert_in_delta(0.0, (worksheet.intermediate_output_ao221||0), 0.002); end
  def test_intermediate_output_ap221; assert_in_delta(0.0, (worksheet.intermediate_output_ap221||0), 0.002); end
  def test_intermediate_output_aq221; assert_in_delta(0.0, (worksheet.intermediate_output_aq221||0), 0.002); end
  def test_intermediate_output_ar221; assert_in_delta(0.0, (worksheet.intermediate_output_ar221||0), 0.002); end
  def test_intermediate_output_as221; assert_in_delta(0.0, (worksheet.intermediate_output_as221||0), 0.002); end
  def test_intermediate_output_at221; assert_in_delta(0.0, (worksheet.intermediate_output_at221||0), 0.002); end
  def test_intermediate_output_au221; assert_in_delta(0.0, (worksheet.intermediate_output_au221||0), 0.002); end
  def test_intermediate_output_av221; assert_in_delta(0.0, (worksheet.intermediate_output_av221||0), 0.002); end
  def test_intermediate_output_aw221; assert_equal("n/a ", worksheet.intermediate_output_aw221); end
  def test_intermediate_output_ax221; assert_in_delta(0.0, (worksheet.intermediate_output_ax221||0), 0.002); end
  def test_intermediate_output_ay221; assert_in_delta(0.0, (worksheet.intermediate_output_ay221||0), 0.002); end
  def test_intermediate_output_az221; assert_in_delta(0.11834100000000002, worksheet.intermediate_output_az221, 0.002); end
  def test_intermediate_output_ba221; assert_in_delta(0.11834100000000002, worksheet.intermediate_output_ba221, 0.002); end
  def test_intermediate_output_bb221; assert_in_delta(0.11834100000000002, worksheet.intermediate_output_bb221, 0.002); end
  def test_intermediate_output_bc221; assert_in_delta(0.11834100000000002, worksheet.intermediate_output_bc221, 0.002); end
  def test_intermediate_output_bd221; assert_in_delta(0.11834100000000002, worksheet.intermediate_output_bd221, 0.002); end
  def test_intermediate_output_be221; assert_in_delta(0.11834100000000002, worksheet.intermediate_output_be221, 0.002); end
  def test_intermediate_output_bf221; assert_in_delta(0.11834100000000002, worksheet.intermediate_output_bf221, 0.002); end
  def test_intermediate_output_c222; assert_equal("I.a", worksheet.intermediate_output_c222); end
  def test_intermediate_output_d222; assert_equal("Natural gas power stations", worksheet.intermediate_output_d222); end
  def test_intermediate_output_ak222; assert_in_delta(0.0, (worksheet.intermediate_output_ak222||0), 0.002); end
  def test_intermediate_output_al222; assert_in_delta(0.0, (worksheet.intermediate_output_al222||0), 0.002); end
  def test_intermediate_output_am222; assert_in_delta(0.0, (worksheet.intermediate_output_am222||0), 0.002); end
  def test_intermediate_output_an222; assert_in_delta(0.0, (worksheet.intermediate_output_an222||0), 0.002); end
  def test_intermediate_output_ao222; assert_in_delta(0.0, (worksheet.intermediate_output_ao222||0), 0.002); end
  def test_intermediate_output_ap222; assert_in_delta(0.0, (worksheet.intermediate_output_ap222||0), 0.002); end
  def test_intermediate_output_aq222; assert_in_delta(0.0, (worksheet.intermediate_output_aq222||0), 0.002); end
  def test_intermediate_output_ar222; assert_in_delta(0.0, (worksheet.intermediate_output_ar222||0), 0.002); end
  def test_intermediate_output_as222; assert_in_delta(0.0, (worksheet.intermediate_output_as222||0), 0.002); end
  def test_intermediate_output_at222; assert_in_delta(0.0, (worksheet.intermediate_output_at222||0), 0.002); end
  def test_intermediate_output_au222; assert_in_delta(0.0, (worksheet.intermediate_output_au222||0), 0.002); end
  def test_intermediate_output_av222; assert_in_delta(0.0, (worksheet.intermediate_output_av222||0), 0.002); end
  def test_intermediate_output_aw222; assert_equal("DUKES -  Electricity fuel use, generation and supply", worksheet.intermediate_output_aw222); end
  def test_intermediate_output_ax222; assert_in_delta(0.0, (worksheet.intermediate_output_ax222||0), 0.002); end
  def test_intermediate_output_ay222; assert_in_delta(0.0, (worksheet.intermediate_output_ay222||0), 0.002); end
  def test_intermediate_output_az222; assert_in_delta(0.0, (worksheet.intermediate_output_az222||0), 0.002); end
  def test_intermediate_output_ba222; assert_in_delta(0.0, (worksheet.intermediate_output_ba222||0), 0.002); end
  def test_intermediate_output_bb222; assert_in_delta(0.0, (worksheet.intermediate_output_bb222||0), 0.002); end
  def test_intermediate_output_bc222; assert_in_delta(0.0, (worksheet.intermediate_output_bc222||0), 0.002); end
  def test_intermediate_output_bd222; assert_in_delta(0.0, (worksheet.intermediate_output_bd222||0), 0.002); end
  def test_intermediate_output_be222; assert_in_delta(0.0, (worksheet.intermediate_output_be222||0), 0.002); end
  def test_intermediate_output_bf222; assert_in_delta(0.0, (worksheet.intermediate_output_bf222||0), 0.002); end
  def test_intermediate_output_c223; assert_equal("XI", worksheet.intermediate_output_c223); end
  def test_intermediate_output_d223; assert_equal("Industry", worksheet.intermediate_output_d223); end
  def test_intermediate_output_ak223; assert_in_epsilon(113.55532, worksheet.intermediate_output_ak223, 0.002); end
  def test_intermediate_output_al223; assert_in_epsilon(117.004, worksheet.intermediate_output_al223, 0.002); end
  def test_intermediate_output_am223; assert_in_epsilon(114.168, worksheet.intermediate_output_am223, 0.002); end
  def test_intermediate_output_an223; assert_in_epsilon(112.6194092, worksheet.intermediate_output_an223, 0.002); end
  def test_intermediate_output_ao223; assert_in_epsilon(112.1681073, worksheet.intermediate_output_ao223, 0.002); end
  def test_intermediate_output_ap223; assert_in_epsilon(113.9677442, worksheet.intermediate_output_ap223, 0.002); end
  def test_intermediate_output_aq223; assert_in_epsilon(118.5182465, worksheet.intermediate_output_aq223, 0.002); end
  def test_intermediate_output_ar223; assert_in_epsilon(117.2874293, worksheet.intermediate_output_ar223, 0.002); end
  def test_intermediate_output_as223; assert_in_epsilon(116.4151009, worksheet.intermediate_output_as223, 0.002); end
  def test_intermediate_output_at223; assert_in_epsilon(116.8549575, worksheet.intermediate_output_at223, 0.002); end
  def test_intermediate_output_au223; assert_in_epsilon(103.0706654, worksheet.intermediate_output_au223, 0.002); end
  def test_intermediate_output_av223; assert_in_epsilon(106.6044588, worksheet.intermediate_output_av223, 0.002); end
  def test_intermediate_output_aw223; assert_equal("DUKES - Aggregate energy balances, industry, coal", worksheet.intermediate_output_aw223); end
  def test_intermediate_output_ax223; assert_in_epsilon(1.507731915164449, worksheet.intermediate_output_ax223, 0.002); end
  def test_intermediate_output_ay223; assert_in_epsilon(1.796613993863308, worksheet.intermediate_output_ay223, 0.002); end
  def test_intermediate_output_az223; assert_in_epsilon(2.1424701278326816, worksheet.intermediate_output_az223, 0.002); end
  def test_intermediate_output_ba223; assert_in_epsilon(2.556658660864889, worksheet.intermediate_output_ba223, 0.002); end
  def test_intermediate_output_bb223; assert_in_epsilon(2.948852801666873, worksheet.intermediate_output_bb223, 0.002); end
  def test_intermediate_output_bc223; assert_in_epsilon(3.4696117782766, worksheet.intermediate_output_bc223, 0.002); end
  def test_intermediate_output_bd223; assert_in_epsilon(4.083254227075439, worksheet.intermediate_output_bd223, 0.002); end
  def test_intermediate_output_be223; assert_in_epsilon(4.806350756066858, worksheet.intermediate_output_be223, 0.002); end
  def test_intermediate_output_bf223; assert_in_epsilon(5.658416949401846, worksheet.intermediate_output_bf223, 0.002); end
  def test_intermediate_output_c224; assert_equal("IX", worksheet.intermediate_output_c224); end
  def test_intermediate_output_d224; assert_equal("Heating", worksheet.intermediate_output_d224); end
  def test_intermediate_output_ak224; assert_in_epsilon(24.42074453, worksheet.intermediate_output_ak224, 0.002); end
  def test_intermediate_output_al224; assert_in_epsilon(17.4515637, worksheet.intermediate_output_al224, 0.002); end
  def test_intermediate_output_am224; assert_in_epsilon(17.50532048, worksheet.intermediate_output_am224, 0.002); end
  def test_intermediate_output_an224; assert_in_epsilon(11.8550141, worksheet.intermediate_output_an224, 0.002); end
  def test_intermediate_output_ao224; assert_in_epsilon(9.603553023, worksheet.intermediate_output_ao224, 0.002); end
  def test_intermediate_output_ap224; assert_in_epsilon(8.68614397, worksheet.intermediate_output_ap224, 0.002); end
  def test_intermediate_output_aq224; assert_in_epsilon(5.883140333, worksheet.intermediate_output_aq224, 0.002); end
  def test_intermediate_output_ar224; assert_in_epsilon(5.193713923, worksheet.intermediate_output_ar224, 0.002); end
  def test_intermediate_output_as224; assert_in_epsilon(5.849571352, worksheet.intermediate_output_as224, 0.002); end
  def test_intermediate_output_at224; assert_in_epsilon(6.189137293, worksheet.intermediate_output_at224, 0.002); end
  def test_intermediate_output_au224; assert_in_epsilon(6.601790658, worksheet.intermediate_output_au224, 0.002); end
  def test_intermediate_output_av224; assert_in_epsilon(6.54085466, worksheet.intermediate_output_av224, 0.002); end
  def test_intermediate_output_aw224; assert_equal("DUKES - Aggregate energy balances, domestic coal", worksheet.intermediate_output_aw224); end
  def test_intermediate_output_ax224; assert_in_delta(0.0, (worksheet.intermediate_output_ax224||0), 0.002); end
  def test_intermediate_output_ay224; assert_in_delta(0.0, (worksheet.intermediate_output_ay224||0), 0.002); end
  def test_intermediate_output_az224; assert_in_delta(0.0, (worksheet.intermediate_output_az224||0), 0.002); end
  def test_intermediate_output_ba224; assert_in_delta(0.0, (worksheet.intermediate_output_ba224||0), 0.002); end
  def test_intermediate_output_bb224; assert_in_delta(0.0, (worksheet.intermediate_output_bb224||0), 0.002); end
  def test_intermediate_output_bc224; assert_in_delta(0.0, (worksheet.intermediate_output_bc224||0), 0.002); end
  def test_intermediate_output_bd224; assert_in_delta(0.0, (worksheet.intermediate_output_bd224||0), 0.002); end
  def test_intermediate_output_be224; assert_in_delta(0.0, (worksheet.intermediate_output_be224||0), 0.002); end
  def test_intermediate_output_bf224; assert_in_delta(0.0, (worksheet.intermediate_output_bf224||0), 0.002); end
  def test_intermediate_output_c226; assert_equal("Liquid Hydrocarbon consumption", worksheet.intermediate_output_c226); end
  def test_intermediate_output_ax226; assert_in_epsilon(792.1857986150538, worksheet.intermediate_output_ax226, 0.002); end
  def test_intermediate_output_ay226; assert_in_epsilon(995.4673391121312, worksheet.intermediate_output_ay226, 0.002); end
  def test_intermediate_output_az226; assert_in_epsilon(1285.5978383769477, worksheet.intermediate_output_az226, 0.002); end
  def test_intermediate_output_ba226; assert_in_epsilon(1710.3015775286888, worksheet.intermediate_output_ba226, 0.002); end
  def test_intermediate_output_bb226; assert_in_epsilon(2174.690887077946, worksheet.intermediate_output_bb226, 0.002); end
  def test_intermediate_output_bc226; assert_in_epsilon(2640.906216194241, worksheet.intermediate_output_bc226, 0.002); end
  def test_intermediate_output_bd226; assert_in_epsilon(3160.171996923956, worksheet.intermediate_output_bd226, 0.002); end
  def test_intermediate_output_be226; assert_in_epsilon(3612.7799486993217, worksheet.intermediate_output_be226, 0.002); end
  def test_intermediate_output_bf226; assert_in_epsilon(4153.960766294276, worksheet.intermediate_output_bf226, 0.002); end
  def test_intermediate_output_c227; assert_equal("V", worksheet.intermediate_output_c227); end
  def test_intermediate_output_d227; assert_equal("Share of Bioliquids to total liquid hydrocarbon consumption", worksheet.intermediate_output_d227); end
  def test_intermediate_output_ax227; assert_in_delta(0.003373916512186106, worksheet.intermediate_output_ax227, 0.002); end
  def test_intermediate_output_ay227; assert_in_delta(0.0028889533359499914, worksheet.intermediate_output_ay227, 0.002); end
  def test_intermediate_output_az227; assert_in_delta(0.0024069583045483343, worksheet.intermediate_output_az227, 0.002); end
  def test_intermediate_output_ba227; assert_in_delta(0.0019844152288886192, worksheet.intermediate_output_ba227, 0.002); end
  def test_intermediate_output_bb227; assert_in_delta(0.001679244254785388, worksheet.intermediate_output_bb227, 0.002); end
  def test_intermediate_output_bc227; assert_in_delta(0.001487868622313733, worksheet.intermediate_output_bc227, 0.002); end
  def test_intermediate_output_bd227; assert_in_delta(0.0013378671852052732, worksheet.intermediate_output_bd227, 0.002); end
  def test_intermediate_output_be227; assert_in_delta(0.0012591816040649342, worksheet.intermediate_output_be227, 0.002); end
  def test_intermediate_output_bf227; assert_in_delta(0.001178348214072929, worksheet.intermediate_output_bf227, 0.002); end
  def test_intermediate_output_c228; assert_equal("XII", worksheet.intermediate_output_c228); end
  def test_intermediate_output_d228; assert_equal("Transport", worksheet.intermediate_output_d228); end
  def test_intermediate_output_ak228; assert_equal(:na, worksheet.intermediate_output_ak228); end
  def test_intermediate_output_al228; assert_equal(:na, worksheet.intermediate_output_al228); end
  def test_intermediate_output_am228; assert_equal(:na, worksheet.intermediate_output_am228); end
  def test_intermediate_output_an228; assert_equal(:na, worksheet.intermediate_output_an228); end
  def test_intermediate_output_ao228; assert_equal(:na, worksheet.intermediate_output_ao228); end
  def test_intermediate_output_ap228; assert_equal(:na, worksheet.intermediate_output_ap228); end
  def test_intermediate_output_aq228; assert_equal(:na, worksheet.intermediate_output_aq228); end
  def test_intermediate_output_ar228; assert_equal(:na, worksheet.intermediate_output_ar228); end
  def test_intermediate_output_as228; assert_equal(:na, worksheet.intermediate_output_as228); end
  def test_intermediate_output_at228; assert_equal(:na, worksheet.intermediate_output_at228); end
  def test_intermediate_output_au228; assert_equal(:na, worksheet.intermediate_output_au228); end
  def test_intermediate_output_av228; assert_equal(:na, worksheet.intermediate_output_av228); end
  def test_intermediate_output_aw228; assert_equal("Energy consumption in the UK, Transport, Table 2.1, total petroleum use", worksheet.intermediate_output_aw228); end
  def test_intermediate_output_ax228; assert_in_epsilon(198.87357996050167, worksheet.intermediate_output_ax228, 0.002); end
  def test_intermediate_output_ay228; assert_in_epsilon(297.17436776033543, worksheet.intermediate_output_ay228, 0.002); end
  def test_intermediate_output_az228; assert_in_epsilon(352.91619012045675, worksheet.intermediate_output_az228, 0.002); end
  def test_intermediate_output_ba228; assert_in_epsilon(388.90581553538766, worksheet.intermediate_output_ba228, 0.002); end
  def test_intermediate_output_bb228; assert_in_epsilon(410.32219967448697, worksheet.intermediate_output_bb228, 0.002); end
  def test_intermediate_output_bc228; assert_in_epsilon(431.39581318409927, worksheet.intermediate_output_bc228, 0.002); end
  def test_intermediate_output_bd228; assert_in_epsilon(432.2479164941955, worksheet.intermediate_output_bd228, 0.002); end
  def test_intermediate_output_be228; assert_in_epsilon(424.676255798201, worksheet.intermediate_output_be228, 0.002); end
  def test_intermediate_output_bf228; assert_in_epsilon(408.91267736954836, worksheet.intermediate_output_bf228, 0.002); end
  def test_intermediate_output_c229; assert_equal("XI", worksheet.intermediate_output_c229); end
  def test_intermediate_output_d229; assert_equal("Industry", worksheet.intermediate_output_d229); end
  def test_intermediate_output_ak229; assert_in_epsilon(73.00151, worksheet.intermediate_output_ak229, 0.002); end
  def test_intermediate_output_al229; assert_in_epsilon(76.15702378, worksheet.intermediate_output_al229, 0.002); end
  def test_intermediate_output_am229; assert_in_epsilon(72.21332952, worksheet.intermediate_output_am229, 0.002); end
  def test_intermediate_output_an229; assert_in_epsilon(58.04690626, worksheet.intermediate_output_an229, 0.002); end
  def test_intermediate_output_ao229; assert_in_epsilon(56.93925004, worksheet.intermediate_output_ao229, 0.002); end
  def test_intermediate_output_ap229; assert_in_epsilon(53.5808897, worksheet.intermediate_output_ap229, 0.002); end
  def test_intermediate_output_aq229; assert_in_epsilon(55.73394665, worksheet.intermediate_output_aq229, 0.002); end
  def test_intermediate_output_ar229; assert_in_epsilon(59.85796902, worksheet.intermediate_output_ar229, 0.002); end
  def test_intermediate_output_as229; assert_in_epsilon(60.4447161, worksheet.intermediate_output_as229, 0.002); end
  def test_intermediate_output_at229; assert_in_epsilon(59.74594793, worksheet.intermediate_output_at229, 0.002); end
  def test_intermediate_output_au229; assert_in_epsilon(52.77511272, worksheet.intermediate_output_au229, 0.002); end
  def test_intermediate_output_av229; assert_in_epsilon(55.63460029, worksheet.intermediate_output_av229, 0.002); end
  def test_intermediate_output_aw229; assert_equal("DUKES - aggregate energy balances, industry liquid hydrocarbons", worksheet.intermediate_output_aw229); end
  def test_intermediate_output_ax229; assert_in_epsilon(2.4375855710328915, worksheet.intermediate_output_ax229, 0.002); end
  def test_intermediate_output_ay229; assert_in_epsilon(5.598087261577213, worksheet.intermediate_output_ay229, 0.002); end
  def test_intermediate_output_az229; assert_in_epsilon(9.898165546130697, worksheet.intermediate_output_az229, 0.002); end
  def test_intermediate_output_ba229; assert_in_epsilon(15.669640091504293, worksheet.intermediate_output_ba229, 0.002); end
  def test_intermediate_output_bb229; assert_in_epsilon(22.537660698453955, worksheet.intermediate_output_bb229, 0.002); end
  def test_intermediate_output_bc229; assert_in_epsilon(25.32207894321168, worksheet.intermediate_output_bc229, 0.002); end
  def test_intermediate_output_bd229; assert_in_epsilon(28.441977719628916, worksheet.intermediate_output_bd229, 0.002); end
  def test_intermediate_output_be229; assert_in_epsilon(33.3186010039211, worksheet.intermediate_output_be229, 0.002); end
  def test_intermediate_output_bf229; assert_in_epsilon(39.04307695087274, worksheet.intermediate_output_bf229, 0.002); end
  def test_intermediate_output_c230; assert_equal("XV.a", worksheet.intermediate_output_c230); end
  def test_intermediate_output_d230; assert_equal("Petroleum refineries", worksheet.intermediate_output_d230); end
  def test_intermediate_output_ak230; assert_in_epsilon(68.37816011, worksheet.intermediate_output_ak230, 0.002); end
  def test_intermediate_output_al230; assert_in_epsilon(64.8507886, worksheet.intermediate_output_al230, 0.002); end
  def test_intermediate_output_am230; assert_in_epsilon(63.04462365, worksheet.intermediate_output_am230, 0.002); end
  def test_intermediate_output_an230; assert_in_epsilon(70.29185596, worksheet.intermediate_output_an230, 0.002); end
  def test_intermediate_output_ao230; assert_in_epsilon(67.50576921, worksheet.intermediate_output_ao230, 0.002); end
  def test_intermediate_output_ap230; assert_in_epsilon(67.55346877, worksheet.intermediate_output_ap230, 0.002); end
  def test_intermediate_output_aq230; assert_in_epsilon(69.45787, worksheet.intermediate_output_aq230, 0.002); end
  def test_intermediate_output_ar230; assert_in_epsilon(60.05119281, worksheet.intermediate_output_ar230, 0.002); end
  def test_intermediate_output_as230; assert_in_epsilon(57.24685939, worksheet.intermediate_output_as230, 0.002); end
  def test_intermediate_output_at230; assert_in_epsilon(58.57160534, worksheet.intermediate_output_at230, 0.002); end
  def test_intermediate_output_au230; assert_in_epsilon(53.80431206, worksheet.intermediate_output_au230, 0.002); end
  def test_intermediate_output_av230; assert_in_epsilon(54.98917277, worksheet.intermediate_output_av230, 0.002); end
  def test_intermediate_output_aw230; assert_equal("DUKES aggregate energy balances, petroleum refinaries petroleum products use", worksheet.intermediate_output_aw230); end
  def test_intermediate_output_ax230; assert_in_delta(0.2101405410269232, worksheet.intermediate_output_ax230, 0.002); end
  def test_intermediate_output_ay230; assert_in_delta(0.2101405410269232, worksheet.intermediate_output_ay230, 0.002); end
  def test_intermediate_output_az230; assert_in_delta(0.19872961841888523, worksheet.intermediate_output_az230, 0.002); end
  def test_intermediate_output_ba230; assert_in_delta(0.1738666274963195, worksheet.intermediate_output_ba230, 0.002); end
  def test_intermediate_output_bb230; assert_in_delta(0.15438446389956498, worksheet.intermediate_output_bb230, 0.002); end
  def test_intermediate_output_bc230; assert_in_delta(0.15109859055350178, worksheet.intermediate_output_bc230, 0.002); end
  def test_intermediate_output_bd230; assert_in_delta(0.15308592798673343, worksheet.intermediate_output_bd230, 0.002); end
  def test_intermediate_output_be230; assert_in_delta(0.15512707369322312, worksheet.intermediate_output_be230, 0.002); end
  def test_intermediate_output_bf230; assert_in_delta(0.1571682193997129, worksheet.intermediate_output_bf230, 0.002); end
  def test_intermediate_output_c231; assert_equal("I.d", worksheet.intermediate_output_c231); end
  def test_intermediate_output_d231; assert_equal("Self Generation ", worksheet.intermediate_output_d231); end
  def test_intermediate_output_ax231; assert_in_epsilon(559.9591211378593, worksheet.intermediate_output_ax231, 0.002); end
  def test_intermediate_output_ay231; assert_in_epsilon(659.6029763162866, worksheet.intermediate_output_ay231, 0.002); end
  def test_intermediate_output_az231; assert_in_epsilon(888.0199886960177, worksheet.intermediate_output_az231, 0.002); end
  def test_intermediate_output_ba231; assert_in_epsilon(1269.9530737101743, worksheet.intermediate_output_ba231, 0.002); end
  def test_intermediate_output_bb231; assert_in_epsilon(1705.8792562753595, worksheet.intermediate_output_bb231, 0.002); end
  def test_intermediate_output_bc231; assert_in_epsilon(2148.6166366894195, worksheet.intermediate_output_bc231, 0.002); end
  def test_intermediate_output_bd231; assert_in_epsilon(2665.2693650802576, worksheet.intermediate_output_bd231, 0.002); end
  def test_intermediate_output_be231; assert_in_epsilon(3123.0629444722063, worksheet.intermediate_output_be231, 0.002); end
  def test_intermediate_output_bf231; assert_in_epsilon(3678.0672480633884, worksheet.intermediate_output_bf231, 0.002); end
  def test_intermediate_output_c233; assert_equal("Gaseous Hydrocarbon consumption", worksheet.intermediate_output_c233); end
  def test_intermediate_output_ax233; assert_in_epsilon(425.9367787395166, worksheet.intermediate_output_ax233, 0.002); end
  def test_intermediate_output_ay233; assert_in_epsilon(413.532226329711, worksheet.intermediate_output_ay233, 0.002); end
  def test_intermediate_output_az233; assert_in_epsilon(405.70171322230397, worksheet.intermediate_output_az233, 0.002); end
  def test_intermediate_output_ba233; assert_in_epsilon(397.4812157423789, worksheet.intermediate_output_ba233, 0.002); end
  def test_intermediate_output_bb233; assert_in_epsilon(387.4016453397174, worksheet.intermediate_output_bb233, 0.002); end
  def test_intermediate_output_bc233; assert_in_epsilon(375.9381382765105, worksheet.intermediate_output_bc233, 0.002); end
  def test_intermediate_output_bd233; assert_in_epsilon(363.115564121233, worksheet.intermediate_output_bd233, 0.002); end
  def test_intermediate_output_be233; assert_in_epsilon(347.44642991498705, worksheet.intermediate_output_be233, 0.002); end
  def test_intermediate_output_bf233; assert_in_epsilon(330.4503412094535, worksheet.intermediate_output_bf233, 0.002); end
  def test_intermediate_output_c234; assert_equal("V", worksheet.intermediate_output_c234); end
  def test_intermediate_output_d234; assert_equal("Share of Biogas to total gaseous hydrocarbon consumption", worksheet.intermediate_output_d234); end
  def test_intermediate_output_ax234; assert_in_delta(0.04277420561431512, worksheet.intermediate_output_ax234, 0.002); end
  def test_intermediate_output_ay234; assert_in_delta(0.050051298458826776, worksheet.intermediate_output_ay234, 0.002); end
  def test_intermediate_output_az234; assert_in_delta(0.07731556951255164, worksheet.intermediate_output_az234, 0.002); end
  def test_intermediate_output_ba234; assert_in_delta(0.08818161053906517, worksheet.intermediate_output_ba234, 0.002); end
  def test_intermediate_output_bb234; assert_in_delta(0.09258557905801951, worksheet.intermediate_output_bb234, 0.002); end
  def test_intermediate_output_bc234; assert_in_delta(0.09852304868538568, worksheet.intermediate_output_bc234, 0.002); end
  def test_intermediate_output_bd234; assert_in_delta(0.1057739462634626, worksheet.intermediate_output_bd234, 0.002); end
  def test_intermediate_output_be234; assert_in_delta(0.1151708201294808, worksheet.intermediate_output_be234, 0.002); end
  def test_intermediate_output_bf234; assert_in_delta(0.1265964820651023, worksheet.intermediate_output_bf234, 0.002); end
  def test_intermediate_output_c235; assert_equal("IX.a", worksheet.intermediate_output_c235); end
  def test_intermediate_output_d235; assert_equal("Residential Cooling", worksheet.intermediate_output_d235); end
  def test_intermediate_output_ar235; assert_in_epsilon(254.0914794, worksheet.intermediate_output_ar235, 0.002); end
  def test_intermediate_output_as235; assert_in_epsilon(241.4598289, worksheet.intermediate_output_as235, 0.002); end
  def test_intermediate_output_at235; assert_in_epsilon(254.5511238, worksheet.intermediate_output_at235, 0.002); end
  def test_intermediate_output_au235; assert_in_epsilon(251.6905486, worksheet.intermediate_output_au235, 0.002); end
  def test_intermediate_output_aw235; assert_equal("Energy consumption in UK, domestic gas space heating", worksheet.intermediate_output_aw235); end
  def test_intermediate_output_ax235; assert_in_delta(0.0, (worksheet.intermediate_output_ax235||0), 0.002); end
  def test_intermediate_output_ay235; assert_in_delta(0.0, (worksheet.intermediate_output_ay235||0), 0.002); end
  def test_intermediate_output_az235; assert_in_delta(0.0, (worksheet.intermediate_output_az235||0), 0.002); end
  def test_intermediate_output_ba235; assert_in_delta(0.0, (worksheet.intermediate_output_ba235||0), 0.002); end
  def test_intermediate_output_bb235; assert_in_delta(0.0, (worksheet.intermediate_output_bb235||0), 0.002); end
  def test_intermediate_output_bc235; assert_in_delta(0.0, (worksheet.intermediate_output_bc235||0), 0.002); end
  def test_intermediate_output_bd235; assert_in_delta(0.0, (worksheet.intermediate_output_bd235||0), 0.002); end
  def test_intermediate_output_be235; assert_in_delta(0.0, (worksheet.intermediate_output_be235||0), 0.002); end
  def test_intermediate_output_bf235; assert_in_delta(0.0, (worksheet.intermediate_output_bf235||0), 0.002); end
  def test_intermediate_output_c236; assert_equal("IX.c", worksheet.intermediate_output_c236); end
  def test_intermediate_output_d236; assert_equal("Service Sector Cooling", worksheet.intermediate_output_d236); end
  def test_intermediate_output_ar236; assert_in_epsilon(75.26536024, worksheet.intermediate_output_ar236, 0.002); end
  def test_intermediate_output_as236; assert_in_epsilon(72.43646261, worksheet.intermediate_output_as236, 0.002); end
  def test_intermediate_output_at236; assert_in_epsilon(70.4353316, worksheet.intermediate_output_at236, 0.002); end
  def test_intermediate_output_au236; assert_in_epsilon(61.68484301, worksheet.intermediate_output_au236, 0.002); end
  def test_intermediate_output_aw236; assert_equal("Energy consumption in UK, commercial gas space heating", worksheet.intermediate_output_aw236); end
  def test_intermediate_output_ax236; assert_in_delta(0.0, (worksheet.intermediate_output_ax236||0), 0.002); end
  def test_intermediate_output_ay236; assert_in_delta(0.0, (worksheet.intermediate_output_ay236||0), 0.002); end
  def test_intermediate_output_az236; assert_in_delta(0.0, (worksheet.intermediate_output_az236||0), 0.002); end
  def test_intermediate_output_ba236; assert_in_delta(0.0, (worksheet.intermediate_output_ba236||0), 0.002); end
  def test_intermediate_output_bb236; assert_in_delta(0.0, (worksheet.intermediate_output_bb236||0), 0.002); end
  def test_intermediate_output_bc236; assert_in_delta(0.0, (worksheet.intermediate_output_bc236||0), 0.002); end
  def test_intermediate_output_bd236; assert_in_delta(0.0, (worksheet.intermediate_output_bd236||0), 0.002); end
  def test_intermediate_output_be236; assert_in_delta(0.0, (worksheet.intermediate_output_be236||0), 0.002); end
  def test_intermediate_output_bf236; assert_in_delta(0.0, (worksheet.intermediate_output_bf236||0), 0.002); end
  def test_intermediate_output_c237; assert_equal("XI", worksheet.intermediate_output_c237); end
  def test_intermediate_output_d237; assert_equal("Industry", worksheet.intermediate_output_d237); end
  def test_intermediate_output_ak237; assert_in_epsilon(68.19307333, worksheet.intermediate_output_ak237, 0.002); end
  def test_intermediate_output_al237; assert_in_epsilon(84.8390885, worksheet.intermediate_output_al237, 0.002); end
  def test_intermediate_output_am237; assert_in_epsilon(76.97345584, worksheet.intermediate_output_am237, 0.002); end
  def test_intermediate_output_an237; assert_in_epsilon(62.61575762, worksheet.intermediate_output_an237, 0.002); end
  def test_intermediate_output_ao237; assert_in_epsilon(69.01463435, worksheet.intermediate_output_ao237, 0.002); end
  def test_intermediate_output_ap237; assert_in_epsilon(68.26181377, worksheet.intermediate_output_ap237, 0.002); end
  def test_intermediate_output_aq237; assert_in_epsilon(68.96100319, worksheet.intermediate_output_aq237, 0.002); end
  def test_intermediate_output_ar237; assert_in_epsilon(73.31393634, worksheet.intermediate_output_ar237, 0.002); end
  def test_intermediate_output_as237; assert_in_epsilon(75.52793362, worksheet.intermediate_output_as237, 0.002); end
  def test_intermediate_output_at237; assert_in_epsilon(74.21415243, worksheet.intermediate_output_at237, 0.002); end
  def test_intermediate_output_au237; assert_in_epsilon(59.8750939, worksheet.intermediate_output_au237, 0.002); end
  def test_intermediate_output_av237; assert_in_epsilon(59.91086183, worksheet.intermediate_output_av237, 0.002); end
  def test_intermediate_output_aw237; assert_equal("DUKES - 1.2 and 2.5", worksheet.intermediate_output_aw237); end
  def test_intermediate_output_ax237; assert_in_epsilon(19.417508445869466, worksheet.intermediate_output_ax237, 0.002); end
  def test_intermediate_output_ay237; assert_in_epsilon(24.77249686514882, worksheet.intermediate_output_ay237, 0.002); end
  def test_intermediate_output_az237; assert_in_epsilon(31.496910128840543, worksheet.intermediate_output_az237, 0.002); end
  def test_intermediate_output_ba237; assert_in_epsilon(39.9272559964205, worksheet.intermediate_output_ba237, 0.002); end
  def test_intermediate_output_bb237; assert_in_epsilon(48.7613873989915, worksheet.intermediate_output_bb237, 0.002); end
  def test_intermediate_output_bc237; assert_in_epsilon(58.07034449957678, worksheet.intermediate_output_bc237, 0.002); end
  def test_intermediate_output_bd237; assert_in_epsilon(69.13371812048415, worksheet.intermediate_output_bd237, 0.002); end
  def test_intermediate_output_be237; assert_in_epsilon(80.89332713176933, worksheet.intermediate_output_be237, 0.002); end
  def test_intermediate_output_bf237; assert_in_epsilon(94.68417695332423, worksheet.intermediate_output_bf237, 0.002); end
  def test_intermediate_output_c238; assert_equal("I.a", worksheet.intermediate_output_c238); end
  def test_intermediate_output_d238; assert_equal("Natural gas power stations", worksheet.intermediate_output_d238); end
  def test_intermediate_output_ak238; assert_in_delta(0.0, (worksheet.intermediate_output_ak238||0), 0.002); end
  def test_intermediate_output_al238; assert_in_delta(0.0, (worksheet.intermediate_output_al238||0), 0.002); end
  def test_intermediate_output_am238; assert_in_delta(0.0, (worksheet.intermediate_output_am238||0), 0.002); end
  def test_intermediate_output_an238; assert_in_delta(0.0, (worksheet.intermediate_output_an238||0), 0.002); end
  def test_intermediate_output_ao238; assert_in_delta(0.0, (worksheet.intermediate_output_ao238||0), 0.002); end
  def test_intermediate_output_ap238; assert_in_delta(0.0, (worksheet.intermediate_output_ap238||0), 0.002); end
  def test_intermediate_output_aq238; assert_in_delta(0.0, (worksheet.intermediate_output_aq238||0), 0.002); end
  def test_intermediate_output_ar238; assert_in_delta(0.0, (worksheet.intermediate_output_ar238||0), 0.002); end
  def test_intermediate_output_as238; assert_in_delta(0.0, (worksheet.intermediate_output_as238||0), 0.002); end
  def test_intermediate_output_at238; assert_in_delta(0.0, (worksheet.intermediate_output_at238||0), 0.002); end
  def test_intermediate_output_au238; assert_in_delta(0.0, (worksheet.intermediate_output_au238||0), 0.002); end
  def test_intermediate_output_av238; assert_in_delta(0.0, (worksheet.intermediate_output_av238||0), 0.002); end
  def test_intermediate_output_aw238; assert_equal("DUKES -  Electricity fuel use, generation and supply", worksheet.intermediate_output_aw238); end
  def test_intermediate_output_ax238; assert_in_epsilon(38.65805999999999, worksheet.intermediate_output_ax238, 0.002); end
  def test_intermediate_output_ay238; assert_in_epsilon(44.3279088, worksheet.intermediate_output_ay238, 0.002); end
  def test_intermediate_output_az238; assert_in_epsilon(49.9977576, worksheet.intermediate_output_az238, 0.002); end
  def test_intermediate_output_ba238; assert_in_epsilon(55.538746199999984, worksheet.intermediate_output_ba238, 0.002); end
  def test_intermediate_output_bb238; assert_in_epsilon(61.208595, worksheet.intermediate_output_bb238, 0.002); end
  def test_intermediate_output_bc238; assert_in_epsilon(66.8784438, worksheet.intermediate_output_bc238, 0.002); end
  def test_intermediate_output_bd238; assert_in_epsilon(72.54829260000001, worksheet.intermediate_output_bd238, 0.002); end
  def test_intermediate_output_be238; assert_in_epsilon(77.960421, worksheet.intermediate_output_be238, 0.002); end
  def test_intermediate_output_bf238; assert_in_epsilon(83.75912999999998, worksheet.intermediate_output_bf238, 0.002); end
  def test_intermediate_output_c239; assert_equal("I.b", worksheet.intermediate_output_c239); end
  def test_intermediate_output_d239; assert_equal("Biomass power station", worksheet.intermediate_output_d239); end
  def test_intermediate_output_ak239; assert_in_delta(0.0, (worksheet.intermediate_output_ak239||0), 0.002); end
  def test_intermediate_output_al239; assert_in_delta(0.0, (worksheet.intermediate_output_al239||0), 0.002); end
  def test_intermediate_output_am239; assert_in_delta(0.0, (worksheet.intermediate_output_am239||0), 0.002); end
  def test_intermediate_output_an239; assert_in_delta(0.0, (worksheet.intermediate_output_an239||0), 0.002); end
  def test_intermediate_output_ao239; assert_in_delta(0.0, (worksheet.intermediate_output_ao239||0), 0.002); end
  def test_intermediate_output_ap239; assert_in_delta(0.0, (worksheet.intermediate_output_ap239||0), 0.002); end
  def test_intermediate_output_aq239; assert_in_delta(0.0, (worksheet.intermediate_output_aq239||0), 0.002); end
  def test_intermediate_output_ar239; assert_in_delta(0.0, (worksheet.intermediate_output_ar239||0), 0.002); end
  def test_intermediate_output_as239; assert_in_delta(0.0, (worksheet.intermediate_output_as239||0), 0.002); end
  def test_intermediate_output_at239; assert_in_delta(0.0, (worksheet.intermediate_output_at239||0), 0.002); end
  def test_intermediate_output_au239; assert_in_delta(0.0, (worksheet.intermediate_output_au239||0), 0.002); end
  def test_intermediate_output_av239; assert_in_delta(0.0, (worksheet.intermediate_output_av239||0), 0.002); end
  def test_intermediate_output_aw239; assert_equal("n/a ", worksheet.intermediate_output_aw239); end
  def test_intermediate_output_ax239; assert_in_delta(0.0, (worksheet.intermediate_output_ax239||0), 0.002); end
  def test_intermediate_output_ay239; assert_in_delta(0.0, (worksheet.intermediate_output_ay239||0), 0.002); end
  def test_intermediate_output_az239; assert_in_delta(0.0, (worksheet.intermediate_output_az239||0), 0.002); end
  def test_intermediate_output_ba239; assert_in_delta(0.0, (worksheet.intermediate_output_ba239||0), 0.002); end
  def test_intermediate_output_bb239; assert_in_delta(0.0, (worksheet.intermediate_output_bb239||0), 0.002); end
  def test_intermediate_output_bc239; assert_in_delta(0.0, (worksheet.intermediate_output_bc239||0), 0.002); end
  def test_intermediate_output_bd239; assert_in_delta(0.0, (worksheet.intermediate_output_bd239||0), 0.002); end
  def test_intermediate_output_be239; assert_in_delta(0.0, (worksheet.intermediate_output_be239||0), 0.002); end
  def test_intermediate_output_bf239; assert_in_delta(0.0, (worksheet.intermediate_output_bf239||0), 0.002); end
  def test_intermediate_output_c240; assert_equal("I.c", worksheet.intermediate_output_c240); end
  def test_intermediate_output_d240; assert_equal("Coal power stations", worksheet.intermediate_output_d240); end
  def test_intermediate_output_ak240; assert_in_delta(0.0, (worksheet.intermediate_output_ak240||0), 0.002); end
  def test_intermediate_output_al240; assert_in_delta(0.0, (worksheet.intermediate_output_al240||0), 0.002); end
  def test_intermediate_output_am240; assert_in_delta(0.0, (worksheet.intermediate_output_am240||0), 0.002); end
  def test_intermediate_output_an240; assert_in_delta(0.0, (worksheet.intermediate_output_an240||0), 0.002); end
  def test_intermediate_output_ao240; assert_in_delta(0.0, (worksheet.intermediate_output_ao240||0), 0.002); end
  def test_intermediate_output_ap240; assert_in_delta(0.0, (worksheet.intermediate_output_ap240||0), 0.002); end
  def test_intermediate_output_aq240; assert_in_delta(0.0, (worksheet.intermediate_output_aq240||0), 0.002); end
  def test_intermediate_output_ar240; assert_in_delta(0.0, (worksheet.intermediate_output_ar240||0), 0.002); end
  def test_intermediate_output_as240; assert_in_delta(0.0, (worksheet.intermediate_output_as240||0), 0.002); end
  def test_intermediate_output_at240; assert_in_delta(0.0, (worksheet.intermediate_output_at240||0), 0.002); end
  def test_intermediate_output_au240; assert_in_delta(0.0, (worksheet.intermediate_output_au240||0), 0.002); end
  def test_intermediate_output_av240; assert_in_delta(0.0, (worksheet.intermediate_output_av240||0), 0.002); end
  def test_intermediate_output_aw240; assert_equal("n/a ", worksheet.intermediate_output_aw240); end
  def test_intermediate_output_ax240; assert_in_delta(0.0, (worksheet.intermediate_output_ax240||0), 0.002); end
  def test_intermediate_output_ay240; assert_in_delta(0.0, (worksheet.intermediate_output_ay240||0), 0.002); end
  def test_intermediate_output_az240; assert_in_delta(0.0, (worksheet.intermediate_output_az240||0), 0.002); end
  def test_intermediate_output_ba240; assert_in_delta(0.0, (worksheet.intermediate_output_ba240||0), 0.002); end
  def test_intermediate_output_bb240; assert_in_delta(0.0, (worksheet.intermediate_output_bb240||0), 0.002); end
  def test_intermediate_output_bc240; assert_in_delta(0.0, (worksheet.intermediate_output_bc240||0), 0.002); end
  def test_intermediate_output_bd240; assert_in_delta(0.0, (worksheet.intermediate_output_bd240||0), 0.002); end
  def test_intermediate_output_be240; assert_in_delta(0.0, (worksheet.intermediate_output_be240||0), 0.002); end
  def test_intermediate_output_bf240; assert_in_delta(0.0, (worksheet.intermediate_output_bf240||0), 0.002); end
  def test_intermediate_output_d242; assert_equal("Traditional Fuel Consumption", worksheet.intermediate_output_d242); end
  def test_intermediate_output_ax242; assert_in_epsilon(203.4337454058215, worksheet.intermediate_output_ax242, 0.002); end
  def test_intermediate_output_ay242; assert_in_epsilon(177.682599567614, worksheet.intermediate_output_ay242, 0.002); end
  def test_intermediate_output_az242; assert_in_epsilon(153.10269077773296, worksheet.intermediate_output_az242, 0.002); end
  def test_intermediate_output_ba242; assert_in_epsilon(129.65486433658936, worksheet.intermediate_output_ba242, 0.002); end
  def test_intermediate_output_bb242; assert_in_epsilon(107.14534163884444, worksheet.intermediate_output_bb242, 0.002); end
  def test_intermediate_output_bc242; assert_in_epsilon(85.41585750615307, worksheet.intermediate_output_bc242, 0.002); end
  def test_intermediate_output_bd242; assert_in_epsilon(65.2490646355106, worksheet.intermediate_output_bd242, 0.002); end
  def test_intermediate_output_be242; assert_in_epsilon(47.7078469935147, worksheet.intermediate_output_be242, 0.002); end
  def test_intermediate_output_bf242; assert_in_epsilon(32.79090266835409, worksheet.intermediate_output_bf242, 0.002); end
  def test_intermediate_output_c243; assert_equal("V", worksheet.intermediate_output_c243); end
  def test_intermediate_output_d243; assert_equal("Share of Traditional Fuel consumption", worksheet.intermediate_output_d243); end
  def test_intermediate_output_ax243; assert_in_delta(0.477614884555983, worksheet.intermediate_output_ax243, 0.002); end
  def test_intermediate_output_ay243; assert_in_delta(0.4296705026948659, worksheet.intermediate_output_ay243, 0.002); end
  def test_intermediate_output_az243; assert_in_delta(0.3773774815041031, worksheet.intermediate_output_az243, 0.002); end
  def test_intermediate_output_ba243; assert_in_delta(0.3261911738254899, worksheet.intermediate_output_ba243, 0.002); end
  def test_intermediate_output_bb243; assert_in_delta(0.2765743071248119, worksheet.intermediate_output_bb243, 0.002); end
  def test_intermediate_output_bc243; assert_in_delta(0.22720721525552673, worksheet.intermediate_output_bc243, 0.002); end
  def test_intermediate_output_bd243; assert_in_delta(0.17969228279547378, worksheet.intermediate_output_bd243, 0.002); end
  def test_intermediate_output_be243; assert_in_delta(0.13730993582287726, worksheet.intermediate_output_be243, 0.002); end
  def test_intermediate_output_bf243; assert_in_delta(0.09923095418312736, worksheet.intermediate_output_bf243, 0.002); end
  def test_intermediate_output_c244; assert_equal("X.a", worksheet.intermediate_output_c244); end
  def test_intermediate_output_d244; assert_equal("Residential Lighting, Appliances, and Cooking", worksheet.intermediate_output_d244); end
  def test_intermediate_output_ax244; assert_in_epsilon(175.06123735689337, worksheet.intermediate_output_ax244, 0.002); end
  def test_intermediate_output_ay244; assert_in_epsilon(149.6234924987437, worksheet.intermediate_output_ay244, 0.002); end
  def test_intermediate_output_az244; assert_in_epsilon(124.86464374828869, worksheet.intermediate_output_az244, 0.002); end
  def test_intermediate_output_ba244; assert_in_epsilon(101.11038741860584, worksheet.intermediate_output_ba244, 0.002); end
  def test_intermediate_output_bb244; assert_in_epsilon(78.72758532661236, worksheet.intermediate_output_bb244, 0.002); end
  def test_intermediate_output_bc244; assert_in_epsilon(58.12811205575061, worksheet.intermediate_output_bc244, 0.002); end
  def test_intermediate_output_bd244; assert_in_epsilon(39.773012854309584, worksheet.intermediate_output_bd244, 0.002); end
  def test_intermediate_output_be244; assert_in_epsilon(24.17699513785537, worksheet.intermediate_output_be244, 0.002); end
  def test_intermediate_output_bf244; assert_in_epsilon(11.913278164905856, worksheet.intermediate_output_bf244, 0.002); end
  def test_intermediate_output_c245; assert_equal("X.b", worksheet.intermediate_output_c245); end
  def test_intermediate_output_d245; assert_equal("Service Sector Lighting, Appliances, and Cooking", worksheet.intermediate_output_d245); end
  def test_intermediate_output_ax245; assert_in_epsilon(16.427232673994066, worksheet.intermediate_output_ax245, 0.002); end
  def test_intermediate_output_ay245; assert_in_epsilon(14.985964695312001, worksheet.intermediate_output_ay245, 0.002); end
  def test_intermediate_output_az245; assert_in_epsilon(13.844996245824, worksheet.intermediate_output_az245, 0.002); end
  def test_intermediate_output_ba245; assert_in_epsilon(12.604885897072, worksheet.intermediate_output_ba245, 0.002); end
  def test_intermediate_output_bb245; assert_in_epsilon(11.039100356924054, worksheet.intermediate_output_bb245, 0.002); end
  def test_intermediate_output_bc245; assert_in_epsilon(10.061680012821373, worksheet.intermediate_output_bc245, 0.002); end
  def test_intermediate_output_bd245; assert_in_epsilon(8.739287782564856, worksheet.intermediate_output_bd245, 0.002); end
  def test_intermediate_output_be245; assert_in_epsilon(7.071923666154459, worksheet.intermediate_output_be245, 0.002); end
  def test_intermediate_output_bf245; assert_in_epsilon(5.059587663590186, worksheet.intermediate_output_bf245, 0.002); end
  def test_intermediate_output_c246; assert_equal("XI.a", worksheet.intermediate_output_c246); end
  def test_intermediate_output_d246; assert_equal("Industrial processes", worksheet.intermediate_output_d246); end
  def test_intermediate_output_ax246; assert_in_epsilon(5.686009374934056, worksheet.intermediate_output_ax246, 0.002); end
  def test_intermediate_output_ay246; assert_in_epsilon(6.7021086608646065, worksheet.intermediate_output_ay246, 0.002); end
  def test_intermediate_output_az246; assert_in_epsilon(7.904548081608782, worksheet.intermediate_output_az246, 0.002); end
  def test_intermediate_output_ba246; assert_in_epsilon(9.327627230551954, worksheet.intermediate_output_ba246, 0.002); end
  def test_intermediate_output_bb246; assert_in_epsilon(10.636933320298363, worksheet.intermediate_output_bb246, 0.002); end
  def test_intermediate_output_bc246; assert_in_epsilon(10.347964952754772, worksheet.intermediate_output_bc246, 0.002); end
  def test_intermediate_output_bd246; assert_in_epsilon(9.71532902304156, worksheet.intermediate_output_bd246, 0.002); end
  def test_intermediate_output_be246; assert_in_epsilon(9.286847223586811, worksheet.intermediate_output_be246, 0.002); end
  def test_intermediate_output_bf246; assert_in_epsilon(8.48762542410277, worksheet.intermediate_output_bf246, 0.002); end
  def test_intermediate_output_d249; assert_equal("Bio type", worksheet.intermediate_output_d249); end
  def test_intermediate_output_e249; assert_equal("Column1", worksheet.intermediate_output_e249); end
  def test_intermediate_output_f249; assert_equal("Column2", worksheet.intermediate_output_f249); end
  def test_intermediate_output_g249; assert_equal("Column22", worksheet.intermediate_output_g249); end
  def test_intermediate_output_h249; assert_equal("Column23", worksheet.intermediate_output_h249); end
  def test_intermediate_output_i249; assert_equal("Column24", worksheet.intermediate_output_i249); end
  def test_intermediate_output_j249; assert_equal("Column25", worksheet.intermediate_output_j249); end
  def test_intermediate_output_k249; assert_equal("Column26", worksheet.intermediate_output_k249); end
  def test_intermediate_output_l249; assert_equal("Column27", worksheet.intermediate_output_l249); end
  def test_intermediate_output_m249; assert_equal("Column28", worksheet.intermediate_output_m249); end
  def test_intermediate_output_n249; assert_equal("Column29", worksheet.intermediate_output_n249); end
  def test_intermediate_output_o249; assert_equal("Column30", worksheet.intermediate_output_o249); end
  def test_intermediate_output_p249; assert_equal("Column31", worksheet.intermediate_output_p249); end
  def test_intermediate_output_q249; assert_equal("Column32", worksheet.intermediate_output_q249); end
  def test_intermediate_output_r249; assert_equal("Column33", worksheet.intermediate_output_r249); end
  def test_intermediate_output_s249; assert_equal("Column34", worksheet.intermediate_output_s249); end
  def test_intermediate_output_t249; assert_equal("Column35", worksheet.intermediate_output_t249); end
  def test_intermediate_output_u249; assert_equal("Column36", worksheet.intermediate_output_u249); end
  def test_intermediate_output_v249; assert_equal("Column37", worksheet.intermediate_output_v249); end
  def test_intermediate_output_w249; assert_equal("Column38", worksheet.intermediate_output_w249); end
  def test_intermediate_output_x249; assert_equal("Column39", worksheet.intermediate_output_x249); end
  def test_intermediate_output_y249; assert_equal("Column40", worksheet.intermediate_output_y249); end
  def test_intermediate_output_z249; assert_equal("Column41", worksheet.intermediate_output_z249); end
  def test_intermediate_output_aa249; assert_equal("Column42", worksheet.intermediate_output_aa249); end
  def test_intermediate_output_ab249; assert_equal("Column43", worksheet.intermediate_output_ab249); end
  def test_intermediate_output_ac249; assert_equal("Column44", worksheet.intermediate_output_ac249); end
  def test_intermediate_output_ad249; assert_equal("Column45", worksheet.intermediate_output_ad249); end
  def test_intermediate_output_ae249; assert_equal("Column46", worksheet.intermediate_output_ae249); end
  def test_intermediate_output_af249; assert_equal("Column47", worksheet.intermediate_output_af249); end
  def test_intermediate_output_ag249; assert_equal("Column48", worksheet.intermediate_output_ag249); end
  def test_intermediate_output_ah249; assert_equal("Column49", worksheet.intermediate_output_ah249); end
  def test_intermediate_output_ai249; assert_equal("Column50", worksheet.intermediate_output_ai249); end
  def test_intermediate_output_aj249; assert_equal("Column51", worksheet.intermediate_output_aj249); end
  def test_intermediate_output_ak249; assert_equal("Column52", worksheet.intermediate_output_ak249); end
  def test_intermediate_output_al249; assert_equal("Column53", worksheet.intermediate_output_al249); end
  def test_intermediate_output_am249; assert_equal("Column54", worksheet.intermediate_output_am249); end
  def test_intermediate_output_an249; assert_equal("Column55", worksheet.intermediate_output_an249); end
  def test_intermediate_output_ao249; assert_equal("Column56", worksheet.intermediate_output_ao249); end
  def test_intermediate_output_ap249; assert_equal("Column57", worksheet.intermediate_output_ap249); end
  def test_intermediate_output_aq249; assert_equal("Column58", worksheet.intermediate_output_aq249); end
  def test_intermediate_output_ar249; assert_equal("Column59", worksheet.intermediate_output_ar249); end
  def test_intermediate_output_as249; assert_equal("Column60", worksheet.intermediate_output_as249); end
  def test_intermediate_output_at249; assert_equal("Column61", worksheet.intermediate_output_at249); end
  def test_intermediate_output_au249; assert_equal("Column612", worksheet.intermediate_output_au249); end
  def test_intermediate_output_av249; assert_equal("Column62", worksheet.intermediate_output_av249); end
  def test_intermediate_output_aw249; assert_equal("Column63", worksheet.intermediate_output_aw249); end
  def test_intermediate_output_ax249; assert_equal("2010", worksheet.intermediate_output_ax249); end
  def test_intermediate_output_ay249; assert_equal("2015", worksheet.intermediate_output_ay249); end
  def test_intermediate_output_az249; assert_equal("2020", worksheet.intermediate_output_az249); end
  def test_intermediate_output_ba249; assert_equal("2025", worksheet.intermediate_output_ba249); end
  def test_intermediate_output_bb249; assert_equal("2030", worksheet.intermediate_output_bb249); end
  def test_intermediate_output_bc249; assert_equal("2035", worksheet.intermediate_output_bc249); end
  def test_intermediate_output_bd249; assert_equal("2040", worksheet.intermediate_output_bd249); end
  def test_intermediate_output_be249; assert_equal("2045", worksheet.intermediate_output_be249); end
  def test_intermediate_output_bf249; assert_equal("2050", worksheet.intermediate_output_bf249); end
  def test_intermediate_output_d250; assert_equal("Solid", worksheet.intermediate_output_d250); end
  def test_intermediate_output_ax250; assert_in_epsilon(1.0000000000000016, worksheet.intermediate_output_ax250, 0.002); end
  def test_intermediate_output_ay250; assert_in_epsilon(1.0000000000000007, worksheet.intermediate_output_ay250, 0.002); end
  def test_intermediate_output_az250; assert_in_epsilon(1.0000000000000004, worksheet.intermediate_output_az250, 0.002); end
  def test_intermediate_output_ba250; assert_in_delta(1.0, worksheet.intermediate_output_ba250, 0.002); end
  def test_intermediate_output_bb250; assert_in_delta(1.0, worksheet.intermediate_output_bb250, 0.002); end
  def test_intermediate_output_bc250; assert_in_delta(1.0, worksheet.intermediate_output_bc250, 0.002); end
  def test_intermediate_output_bd250; assert_in_delta(1.0, worksheet.intermediate_output_bd250, 0.002); end
  def test_intermediate_output_be250; assert_in_delta(1.0, worksheet.intermediate_output_be250, 0.002); end
  def test_intermediate_output_bf250; assert_in_delta(1.0, worksheet.intermediate_output_bf250, 0.002); end
  def test_intermediate_output_d251; assert_equal("Liquid", worksheet.intermediate_output_d251); end
  def test_intermediate_output_ax251; assert_in_delta(0.003373916512186106, worksheet.intermediate_output_ax251, 0.002); end
  def test_intermediate_output_ay251; assert_in_delta(0.0028889533359499914, worksheet.intermediate_output_ay251, 0.002); end
  def test_intermediate_output_az251; assert_in_delta(0.0024069583045483343, worksheet.intermediate_output_az251, 0.002); end
  def test_intermediate_output_ba251; assert_in_delta(0.0019844152288886192, worksheet.intermediate_output_ba251, 0.002); end
  def test_intermediate_output_bb251; assert_in_delta(0.001679244254785388, worksheet.intermediate_output_bb251, 0.002); end
  def test_intermediate_output_bc251; assert_in_delta(0.001487868622313733, worksheet.intermediate_output_bc251, 0.002); end
  def test_intermediate_output_bd251; assert_in_delta(0.0013378671852052732, worksheet.intermediate_output_bd251, 0.002); end
  def test_intermediate_output_be251; assert_in_delta(0.0012591816040649342, worksheet.intermediate_output_be251, 0.002); end
  def test_intermediate_output_bf251; assert_in_delta(0.001178348214072929, worksheet.intermediate_output_bf251, 0.002); end
  def test_intermediate_output_d252; assert_equal("Gas", worksheet.intermediate_output_d252); end
  def test_intermediate_output_ax252; assert_in_delta(0.04277420561431512, worksheet.intermediate_output_ax252, 0.002); end
  def test_intermediate_output_ay252; assert_in_delta(0.050051298458826776, worksheet.intermediate_output_ay252, 0.002); end
  def test_intermediate_output_az252; assert_in_delta(0.07731556951255164, worksheet.intermediate_output_az252, 0.002); end
  def test_intermediate_output_ba252; assert_in_delta(0.08818161053906517, worksheet.intermediate_output_ba252, 0.002); end
  def test_intermediate_output_bb252; assert_in_delta(0.09258557905801951, worksheet.intermediate_output_bb252, 0.002); end
  def test_intermediate_output_bc252; assert_in_delta(0.09852304868538568, worksheet.intermediate_output_bc252, 0.002); end
  def test_intermediate_output_bd252; assert_in_delta(0.1057739462634626, worksheet.intermediate_output_bd252, 0.002); end
  def test_intermediate_output_be252; assert_in_delta(0.1151708201294808, worksheet.intermediate_output_be252, 0.002); end
  def test_intermediate_output_bf252; assert_in_delta(0.1265964820651023, worksheet.intermediate_output_bf252, 0.002); end
  def test_intermediate_output_d253; assert_equal("Fuelwood", worksheet.intermediate_output_d253); end
  def test_intermediate_output_ax253; assert_in_delta(0.477614884555983, worksheet.intermediate_output_ax253, 0.002); end
  def test_intermediate_output_ay253; assert_in_delta(0.4296705026948659, worksheet.intermediate_output_ay253, 0.002); end
  def test_intermediate_output_az253; assert_in_delta(0.3773774815041031, worksheet.intermediate_output_az253, 0.002); end
  def test_intermediate_output_ba253; assert_in_delta(0.3261911738254899, worksheet.intermediate_output_ba253, 0.002); end
  def test_intermediate_output_bb253; assert_in_delta(0.2765743071248119, worksheet.intermediate_output_bb253, 0.002); end
  def test_intermediate_output_bc253; assert_in_delta(0.22720721525552673, worksheet.intermediate_output_bc253, 0.002); end
  def test_intermediate_output_bd253; assert_in_delta(0.17969228279547378, worksheet.intermediate_output_bd253, 0.002); end
  def test_intermediate_output_be253; assert_in_delta(0.13730993582287726, worksheet.intermediate_output_be253, 0.002); end
  def test_intermediate_output_bf253; assert_in_delta(0.09923095418312736, worksheet.intermediate_output_bf253, 0.002); end
  def test_intermediate_output_b255; assert_equal("Electricity Generation Emissions", worksheet.intermediate_output_b255); end
  def test_intermediate_output_c258; assert_equal("Emissions from Electricity Generation, exlcuding CHP", worksheet.intermediate_output_c258); end
  def test_intermediate_output_ax258; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax258, 0.002); end
  def test_intermediate_output_ay258; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay258, 0.002); end
  def test_intermediate_output_az258; assert_in_epsilon(2020.0, worksheet.intermediate_output_az258, 0.002); end
  def test_intermediate_output_ba258; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba258, 0.002); end
  def test_intermediate_output_bb258; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb258, 0.002); end
  def test_intermediate_output_bc258; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc258, 0.002); end
  def test_intermediate_output_bd258; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd258, 0.002); end
  def test_intermediate_output_be258; assert_in_epsilon(2045.0, worksheet.intermediate_output_be258, 0.002); end
  def test_intermediate_output_bf258; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf258, 0.002); end
  def test_intermediate_output_c259; assert_equal("Power Generation", worksheet.intermediate_output_c259); end
  def test_intermediate_output_ax259; assert_in_epsilon(149.82544637164256, worksheet.intermediate_output_ax259, 0.002); end
  def test_intermediate_output_ay259; assert_in_epsilon(176.2632160347501, worksheet.intermediate_output_ay259, 0.002); end
  def test_intermediate_output_az259; assert_in_epsilon(235.5504577440285, worksheet.intermediate_output_az259, 0.002); end
  def test_intermediate_output_ba259; assert_in_epsilon(341.82007565998407, worksheet.intermediate_output_ba259, 0.002); end
  def test_intermediate_output_bb259; assert_in_epsilon(453.9456967479541, worksheet.intermediate_output_bb259, 0.002); end
  def test_intermediate_output_bc259; assert_in_epsilon(567.8068741282668, worksheet.intermediate_output_bc259, 0.002); end
  def test_intermediate_output_bd259; assert_in_epsilon(700.5023667242193, worksheet.intermediate_output_bd259, 0.002); end
  def test_intermediate_output_be259; assert_in_epsilon(818.1523852014301, worksheet.intermediate_output_be259, 0.002); end
  def test_intermediate_output_bf259; assert_in_epsilon(960.6440232645404, worksheet.intermediate_output_bf259, 0.002); end
  def test_intermediate_output_c260; assert_equal("Bioenergy in Gas Power", worksheet.intermediate_output_c260); end
  def test_intermediate_output_ax260; assert_in_delta(-0.30552230744322767, worksheet.intermediate_output_ax260, 0.002); end
  def test_intermediate_output_ay260; assert_in_delta(-0.40993359305856614, worksheet.intermediate_output_ay260, 0.002); end
  def test_intermediate_output_az260; assert_in_delta(-0.7142305176286263, worksheet.intermediate_output_az260, 0.002); end
  def test_intermediate_output_ba260; assert_in_delta(-0.9048883867057043, worksheet.intermediate_output_ba260, 0.002); end
  def test_intermediate_output_bb260; assert_in_epsilon(-1.0470723097540295, worksheet.intermediate_output_bb260, 0.002); end
  def test_intermediate_output_bc260; assert_in_epsilon(-1.2174325745487176, worksheet.intermediate_output_bc260, 0.002); end
  def test_intermediate_output_bd260; assert_in_epsilon(-1.4178386804049565, worksheet.intermediate_output_bd260, 0.002); end
  def test_intermediate_output_be260; assert_in_epsilon(-1.6589662545058617, worksheet.intermediate_output_be260, 0.002); end
  def test_intermediate_output_bf260; assert_in_epsilon(-1.9591816838758256, worksheet.intermediate_output_bf260, 0.002); end
  def test_intermediate_output_c261; assert_equal("Bioenergy in Solid BM Power", worksheet.intermediate_output_c261); end
  def test_intermediate_output_ax261; assert_in_delta(0.0, (worksheet.intermediate_output_ax261||0), 0.002); end
  def test_intermediate_output_ay261; assert_in_delta(0.0, (worksheet.intermediate_output_ay261||0), 0.002); end
  def test_intermediate_output_az261; assert_in_delta(0.0, (worksheet.intermediate_output_az261||0), 0.002); end
  def test_intermediate_output_ba261; assert_in_delta(0.0, (worksheet.intermediate_output_ba261||0), 0.002); end
  def test_intermediate_output_bb261; assert_in_delta(0.0, (worksheet.intermediate_output_bb261||0), 0.002); end
  def test_intermediate_output_bc261; assert_in_delta(0.0, (worksheet.intermediate_output_bc261||0), 0.002); end
  def test_intermediate_output_bd261; assert_in_delta(0.0, (worksheet.intermediate_output_bd261||0), 0.002); end
  def test_intermediate_output_be261; assert_in_delta(0.0, (worksheet.intermediate_output_be261||0), 0.002); end
  def test_intermediate_output_bf261; assert_in_delta(0.0, (worksheet.intermediate_output_bf261||0), 0.002); end
  def test_intermediate_output_c262; assert_equal("Bioenergy in Solid HC CCS Power", worksheet.intermediate_output_c262); end
  def test_intermediate_output_ax262; assert_in_delta(0.0, (worksheet.intermediate_output_ax262||0), 0.002); end
  def test_intermediate_output_ay262; assert_in_delta(0.0, (worksheet.intermediate_output_ay262||0), 0.002); end
  def test_intermediate_output_az262; assert_in_delta(-0.03687898627675124, worksheet.intermediate_output_az262, 0.002); end
  def test_intermediate_output_ba262; assert_in_delta(-0.03687898627675122, worksheet.intermediate_output_ba262, 0.002); end
  def test_intermediate_output_bb262; assert_in_delta(-0.03687898627675122, worksheet.intermediate_output_bb262, 0.002); end
  def test_intermediate_output_bc262; assert_in_delta(-0.03687898627675122, worksheet.intermediate_output_bc262, 0.002); end
  def test_intermediate_output_bd262; assert_in_delta(-0.03687898627675122, worksheet.intermediate_output_bd262, 0.002); end
  def test_intermediate_output_be262; assert_in_delta(-0.03687898627675122, worksheet.intermediate_output_be262, 0.002); end
  def test_intermediate_output_bf262; assert_in_delta(-0.03687898627675122, worksheet.intermediate_output_bf262, 0.002); end
  def test_intermediate_output_c263; assert_equal("Total Emissions from Power", worksheet.intermediate_output_c263); end
  def test_intermediate_output_ax263; assert_in_epsilon(149.51992406419933, worksheet.intermediate_output_ax263, 0.002); end
  def test_intermediate_output_ay263; assert_in_epsilon(175.85328244169153, worksheet.intermediate_output_ay263, 0.002); end
  def test_intermediate_output_az263; assert_in_epsilon(234.79934824012312, worksheet.intermediate_output_az263, 0.002); end
  def test_intermediate_output_ba263; assert_in_epsilon(340.87830828700163, worksheet.intermediate_output_ba263, 0.002); end
  def test_intermediate_output_bb263; assert_in_epsilon(452.86174545192335, worksheet.intermediate_output_bb263, 0.002); end
  def test_intermediate_output_bc263; assert_in_epsilon(566.5525625674413, worksheet.intermediate_output_bc263, 0.002); end
  def test_intermediate_output_bd263; assert_in_epsilon(699.0476490575376, worksheet.intermediate_output_bd263, 0.002); end
  def test_intermediate_output_be263; assert_in_epsilon(816.4565399606474, worksheet.intermediate_output_be263, 0.002); end
  def test_intermediate_output_bf263; assert_in_epsilon(958.6479625943878, worksheet.intermediate_output_bf263, 0.002); end
  def test_intermediate_output_c265; assert_equal("Emissions reclassified", worksheet.intermediate_output_c265); end
  def test_intermediate_output_ax265; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax265, 0.002); end
  def test_intermediate_output_ay265; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay265, 0.002); end
  def test_intermediate_output_az265; assert_in_epsilon(2020.0, worksheet.intermediate_output_az265, 0.002); end
  def test_intermediate_output_ba265; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba265, 0.002); end
  def test_intermediate_output_bb265; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb265, 0.002); end
  def test_intermediate_output_bc265; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc265, 0.002); end
  def test_intermediate_output_bd265; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd265, 0.002); end
  def test_intermediate_output_be265; assert_in_epsilon(2045.0, worksheet.intermediate_output_be265, 0.002); end
  def test_intermediate_output_bf265; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf265, 0.002); end
  def test_intermediate_output_c266; assert_in_delta(1.0, worksheet.intermediate_output_c266, 0.002); end
  def test_intermediate_output_d266; assert_equal("Fuel Combustion", worksheet.intermediate_output_d266); end
  def test_intermediate_output_ax266; assert_in_epsilon(149.82544637164256, worksheet.intermediate_output_ax266, 0.002); end
  def test_intermediate_output_ay266; assert_in_epsilon(176.2632160347501, worksheet.intermediate_output_ay266, 0.002); end
  def test_intermediate_output_az266; assert_in_epsilon(235.5504577440285, worksheet.intermediate_output_az266, 0.002); end
  def test_intermediate_output_ba266; assert_in_epsilon(341.82007565998407, worksheet.intermediate_output_ba266, 0.002); end
  def test_intermediate_output_bb266; assert_in_epsilon(453.9456967479541, worksheet.intermediate_output_bb266, 0.002); end
  def test_intermediate_output_bc266; assert_in_epsilon(567.8068741282668, worksheet.intermediate_output_bc266, 0.002); end
  def test_intermediate_output_bd266; assert_in_epsilon(700.5023667242193, worksheet.intermediate_output_bd266, 0.002); end
  def test_intermediate_output_be266; assert_in_epsilon(818.1523852014301, worksheet.intermediate_output_be266, 0.002); end
  def test_intermediate_output_bf266; assert_in_epsilon(960.6440232645404, worksheet.intermediate_output_bf266, 0.002); end
  def test_intermediate_output_c267; assert_equal("X2", worksheet.intermediate_output_c267); end
  def test_intermediate_output_d267; assert_equal("Bioenergy credit", worksheet.intermediate_output_d267); end
  def test_intermediate_output_ax267; assert_in_delta(-0.30552230744322767, worksheet.intermediate_output_ax267, 0.002); end
  def test_intermediate_output_ay267; assert_in_delta(-0.40993359305856614, worksheet.intermediate_output_ay267, 0.002); end
  def test_intermediate_output_az267; assert_in_delta(-0.7511095039053776, worksheet.intermediate_output_az267, 0.002); end
  def test_intermediate_output_ba267; assert_in_delta(-0.9417673729824555, worksheet.intermediate_output_ba267, 0.002); end
  def test_intermediate_output_bb267; assert_in_epsilon(-1.0839512960307807, worksheet.intermediate_output_bb267, 0.002); end
  def test_intermediate_output_bc267; assert_in_epsilon(-1.2543115608254687, worksheet.intermediate_output_bc267, 0.002); end
  def test_intermediate_output_bd267; assert_in_epsilon(-1.4547176666817077, worksheet.intermediate_output_bd267, 0.002); end
  def test_intermediate_output_be267; assert_in_epsilon(-1.6958452407826128, worksheet.intermediate_output_be267, 0.002); end
  def test_intermediate_output_bf267; assert_in_epsilon(-1.9960606701525767, worksheet.intermediate_output_bf267, 0.002); end
  def test_intermediate_output_d268; assert_equal("Total", worksheet.intermediate_output_d268); end
  def test_intermediate_output_ax268; assert_in_epsilon(149.51992406419933, worksheet.intermediate_output_ax268, 0.002); end
  def test_intermediate_output_ay268; assert_in_epsilon(175.85328244169153, worksheet.intermediate_output_ay268, 0.002); end
  def test_intermediate_output_az268; assert_in_epsilon(234.79934824012312, worksheet.intermediate_output_az268, 0.002); end
  def test_intermediate_output_ba268; assert_in_epsilon(340.87830828700163, worksheet.intermediate_output_ba268, 0.002); end
  def test_intermediate_output_bb268; assert_in_epsilon(452.86174545192335, worksheet.intermediate_output_bb268, 0.002); end
  def test_intermediate_output_bc268; assert_in_epsilon(566.5525625674413, worksheet.intermediate_output_bc268, 0.002); end
  def test_intermediate_output_bd268; assert_in_epsilon(699.0476490575376, worksheet.intermediate_output_bd268, 0.002); end
  def test_intermediate_output_be268; assert_in_epsilon(816.4565399606474, worksheet.intermediate_output_be268, 0.002); end
  def test_intermediate_output_bf268; assert_in_epsilon(958.6479625943878, worksheet.intermediate_output_bf268, 0.002); end
  def test_intermediate_output_c270; assert_equal("Emissions intensity", worksheet.intermediate_output_c270); end
  def test_intermediate_output_e270; assert_equal("MtCO2e/TWh", worksheet.intermediate_output_e270); end
  def test_intermediate_output_ax270; assert_in_epsilon(1.0751572464336758, worksheet.intermediate_output_ax270, 0.002); end
  def test_intermediate_output_ay270; assert_in_epsilon(1.0828926816623978, worksheet.intermediate_output_ay270, 0.002); end
  def test_intermediate_output_az270; assert_in_epsilon(1.1102428480420086, worksheet.intermediate_output_az270, 0.002); end
  def test_intermediate_output_ba270; assert_in_epsilon(1.1360248435891116, worksheet.intermediate_output_ba270, 0.002); end
  def test_intermediate_output_bb270; assert_in_epsilon(1.1606220087756838, worksheet.intermediate_output_bb270, 0.002); end
  def test_intermediate_output_bc270; assert_in_epsilon(1.1762400986929955, worksheet.intermediate_output_bc270, 0.002); end
  def test_intermediate_output_bd270; assert_in_epsilon(1.1893096995141654, worksheet.intermediate_output_bd270, 0.002); end
  def test_intermediate_output_be270; assert_in_epsilon(1.1969575173659042, worksheet.intermediate_output_be270, 0.002); end
  def test_intermediate_output_bf270; assert_in_epsilon(1.2045169478233793, worksheet.intermediate_output_bf270, 0.002); end
  def test_intermediate_output_e271; assert_equal("gCO2e/KWh", worksheet.intermediate_output_e271); end
  def test_intermediate_output_ax271; assert_in_epsilon(1075.157246433676, worksheet.intermediate_output_ax271, 0.002); end
  def test_intermediate_output_ay271; assert_in_epsilon(1082.8926816623978, worksheet.intermediate_output_ay271, 0.002); end
  def test_intermediate_output_az271; assert_in_epsilon(1110.2428480420085, worksheet.intermediate_output_az271, 0.002); end
  def test_intermediate_output_ba271; assert_in_epsilon(1136.0248435891117, worksheet.intermediate_output_ba271, 0.002); end
  def test_intermediate_output_bb271; assert_in_epsilon(1160.6220087756838, worksheet.intermediate_output_bb271, 0.002); end
  def test_intermediate_output_bc271; assert_in_epsilon(1176.2400986929956, worksheet.intermediate_output_bc271, 0.002); end
  def test_intermediate_output_bd271; assert_in_epsilon(1189.3096995141655, worksheet.intermediate_output_bd271, 0.002); end
  def test_intermediate_output_be271; assert_in_epsilon(1196.957517365904, worksheet.intermediate_output_be271, 0.002); end
  def test_intermediate_output_bf271; assert_in_epsilon(1204.5169478233793, worksheet.intermediate_output_bf271, 0.002); end
  def test_intermediate_output_c273; assert_equal("Note: Emissions from CHP are excluded, while emissions from district heating are included.", worksheet.intermediate_output_c273); end
  def test_intermediate_output_b276; assert_equal("Primary supply, format for web-based interface", worksheet.intermediate_output_b276); end
  def test_intermediate_output_c278; assert_equal("N.01", worksheet.intermediate_output_c278); end
  def test_intermediate_output_d278; assert_equal("Nuclear fission", worksheet.intermediate_output_d278); end
  def test_intermediate_output_e278; assert_in_delta(0.0, (worksheet.intermediate_output_e278||0), 0.002); end
  def test_intermediate_output_aw278; assert_in_delta(0.0, (worksheet.intermediate_output_aw278||0), 0.002); end
  def test_intermediate_output_ax278; assert_in_delta(0.0, (worksheet.intermediate_output_ax278||0), 0.002); end
  def test_intermediate_output_ay278; assert_in_delta(0.0, (worksheet.intermediate_output_ay278||0), 0.002); end
  def test_intermediate_output_az278; assert_in_delta(0.0, (worksheet.intermediate_output_az278||0), 0.002); end
  def test_intermediate_output_ba278; assert_in_delta(0.0, (worksheet.intermediate_output_ba278||0), 0.002); end
  def test_intermediate_output_bb278; assert_in_delta(0.0, (worksheet.intermediate_output_bb278||0), 0.002); end
  def test_intermediate_output_bc278; assert_in_delta(0.0, (worksheet.intermediate_output_bc278||0), 0.002); end
  def test_intermediate_output_bd278; assert_in_delta(0.0, (worksheet.intermediate_output_bd278||0), 0.002); end
  def test_intermediate_output_be278; assert_in_delta(0.0, (worksheet.intermediate_output_be278||0), 0.002); end
  def test_intermediate_output_bf278; assert_in_delta(0.0, (worksheet.intermediate_output_bf278||0), 0.002); end
  def test_intermediate_output_c279; assert_equal("R.01", worksheet.intermediate_output_c279); end
  def test_intermediate_output_d279; assert_equal("Solar", worksheet.intermediate_output_d279); end
  def test_intermediate_output_e279; assert_in_delta(0.0, (worksheet.intermediate_output_e279||0), 0.002); end
  def test_intermediate_output_aw279; assert_in_delta(0.0, (worksheet.intermediate_output_aw279||0), 0.002); end
  def test_intermediate_output_ax279; assert_in_delta(0.027612899999999996, worksheet.intermediate_output_ax279, 0.002); end
  def test_intermediate_output_ay279; assert_in_delta(0.92043, worksheet.intermediate_output_ay279, 0.002); end
  def test_intermediate_output_az279; assert_in_epsilon(2.024946, worksheet.intermediate_output_az279, 0.002); end
  def test_intermediate_output_ba279; assert_in_epsilon(3.1294619999999997, worksheet.intermediate_output_ba279, 0.002); end
  def test_intermediate_output_bb279; assert_in_epsilon(4.233978, worksheet.intermediate_output_bb279, 0.002); end
  def test_intermediate_output_bc279; assert_in_epsilon(5.338494, worksheet.intermediate_output_bc279, 0.002); end
  def test_intermediate_output_bd279; assert_in_epsilon(6.443009999999999, worksheet.intermediate_output_bd279, 0.002); end
  def test_intermediate_output_be279; assert_in_epsilon(7.547526, worksheet.intermediate_output_be279, 0.002); end
  def test_intermediate_output_bf279; assert_in_epsilon(8.652042, worksheet.intermediate_output_bf279, 0.002); end
  def test_intermediate_output_c280; assert_equal("R.02", worksheet.intermediate_output_c280); end
  def test_intermediate_output_d280; assert_equal("Wind", worksheet.intermediate_output_d280); end
  def test_intermediate_output_e280; assert_in_delta(0.0, (worksheet.intermediate_output_e280||0), 0.002); end
  def test_intermediate_output_aw280; assert_in_delta(0.0, (worksheet.intermediate_output_aw280||0), 0.002); end
  def test_intermediate_output_ax280; assert_in_delta(0.0, (worksheet.intermediate_output_ax280||0), 0.002); end
  def test_intermediate_output_ay280; assert_in_delta(0.0, (worksheet.intermediate_output_ay280||0), 0.002); end
  def test_intermediate_output_az280; assert_in_delta(0.017532, worksheet.intermediate_output_az280, 0.002); end
  def test_intermediate_output_ba280; assert_in_delta(0.017532, worksheet.intermediate_output_ba280, 0.002); end
  def test_intermediate_output_bb280; assert_in_delta(0.017532, worksheet.intermediate_output_bb280, 0.002); end
  def test_intermediate_output_bc280; assert_in_delta(0.017532, worksheet.intermediate_output_bc280, 0.002); end
  def test_intermediate_output_bd280; assert_in_delta(0.017532, worksheet.intermediate_output_bd280, 0.002); end
  def test_intermediate_output_be280; assert_in_delta(0.017532, worksheet.intermediate_output_be280, 0.002); end
  def test_intermediate_output_bf280; assert_in_delta(0.017532, worksheet.intermediate_output_bf280, 0.002); end
  def test_intermediate_output_c281; assert_equal("R.06", worksheet.intermediate_output_c281); end
  def test_intermediate_output_d281; assert_equal("Hydro", worksheet.intermediate_output_d281); end
  def test_intermediate_output_e281; assert_in_delta(0.0, (worksheet.intermediate_output_e281||0), 0.002); end
  def test_intermediate_output_aw281; assert_in_delta(0.0, (worksheet.intermediate_output_aw281||0), 0.002); end
  def test_intermediate_output_ax281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_ax281, 0.002); end
  def test_intermediate_output_ay281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_ay281, 0.002); end
  def test_intermediate_output_az281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_az281, 0.002); end
  def test_intermediate_output_ba281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_ba281, 0.002); end
  def test_intermediate_output_bb281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_bb281, 0.002); end
  def test_intermediate_output_bc281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_bc281, 0.002); end
  def test_intermediate_output_bd281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_bd281, 0.002); end
  def test_intermediate_output_be281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_be281, 0.002); end
  def test_intermediate_output_bf281; assert_in_epsilon(10.273751999999998, worksheet.intermediate_output_bf281, 0.002); end
  def test_intermediate_output_c282; assert_equal("Y.02", worksheet.intermediate_output_c282); end
  def test_intermediate_output_d282; assert_equal("Electricity oversupply (imports)", worksheet.intermediate_output_d282); end
  def test_intermediate_output_e282; assert_in_delta(0.0, (worksheet.intermediate_output_e282||0), 0.002); end
  def test_intermediate_output_aw282; assert_in_delta(0.0, (worksheet.intermediate_output_aw282||0), 0.002); end
  def test_intermediate_output_ax282; assert_in_delta(0.0, (worksheet.intermediate_output_ax282||0), 0.002); end
  def test_intermediate_output_ay282; assert_in_delta(0.0, (worksheet.intermediate_output_ay282||0), 0.002); end
  def test_intermediate_output_az282; assert_in_delta(0.0, (worksheet.intermediate_output_az282||0), 0.002); end
  def test_intermediate_output_ba282; assert_in_delta(0.0, (worksheet.intermediate_output_ba282||0), 0.002); end
  def test_intermediate_output_bb282; assert_in_delta(0.0, (worksheet.intermediate_output_bb282||0), 0.002); end
  def test_intermediate_output_bc282; assert_in_delta(0.0, (worksheet.intermediate_output_bc282||0), 0.002); end
  def test_intermediate_output_bd282; assert_in_delta(0.0, (worksheet.intermediate_output_bd282||0), 0.002); end
  def test_intermediate_output_be282; assert_in_delta(0.0, (worksheet.intermediate_output_be282||0), 0.002); end
  def test_intermediate_output_bf282; assert_in_delta(0.0, (worksheet.intermediate_output_bf282||0), 0.002); end
  def test_intermediate_output_d283; assert_equal("Bioenergy", worksheet.intermediate_output_d283); end
  def test_intermediate_output_e283; assert_in_delta(0.0, (worksheet.intermediate_output_e283||0), 0.002); end
  def test_intermediate_output_aw283; assert_in_delta(0.0, (worksheet.intermediate_output_aw283||0), 0.002); end
  def test_intermediate_output_ax283; assert_in_epsilon(1775.43418782733, worksheet.intermediate_output_ax283, 0.002); end
  def test_intermediate_output_ay283; assert_in_epsilon(1777.5409535560138, worksheet.intermediate_output_ay283, 0.002); end
  def test_intermediate_output_az283; assert_in_epsilon(1792.8691142678465, worksheet.intermediate_output_az283, 0.002); end
  def test_intermediate_output_ba283; assert_in_epsilon(1818.149655638295, worksheet.intermediate_output_ba283, 0.002); end
  def test_intermediate_output_bb283; assert_in_epsilon(1822.954882937613, worksheet.intermediate_output_bb283, 0.002); end
  def test_intermediate_output_bc283; assert_in_epsilon(1829.4554905016487, worksheet.intermediate_output_bc283, 0.002); end
  def test_intermediate_output_bd283; assert_in_epsilon(1838.1020409144148, worksheet.intermediate_output_bd283, 0.002); end
  def test_intermediate_output_be283; assert_in_epsilon(1850.4394416902317, worksheet.intermediate_output_be283, 0.002); end
  def test_intermediate_output_bf283; assert_in_epsilon(1866.152294795299, worksheet.intermediate_output_bf283, 0.002); end
  def test_intermediate_output_d284; assert_equal("Coal", worksheet.intermediate_output_d284); end
  def test_intermediate_output_e284; assert_in_delta(0.0, (worksheet.intermediate_output_e284||0), 0.002); end
  def test_intermediate_output_aw284; assert_in_delta(0.0, (worksheet.intermediate_output_aw284||0), 0.002); end
  def test_intermediate_output_ax284; assert_in_delta(0.0, (worksheet.intermediate_output_ax284||0), 0.002); end
  def test_intermediate_output_ay284; assert_in_delta(0.0, (worksheet.intermediate_output_ay284||0), 0.002); end
  def test_intermediate_output_az284; assert_in_delta(0.0, (worksheet.intermediate_output_az284||0), 0.002); end
  def test_intermediate_output_ba284; assert_in_delta(0.0, (worksheet.intermediate_output_ba284||0), 0.002); end
  def test_intermediate_output_bb284; assert_in_delta(0.0, (worksheet.intermediate_output_bb284||0), 0.002); end
  def test_intermediate_output_bc284; assert_in_delta(0.0, (worksheet.intermediate_output_bc284||0), 0.002); end
  def test_intermediate_output_bd284; assert_in_delta(0.0, (worksheet.intermediate_output_bd284||0), 0.002); end
  def test_intermediate_output_be284; assert_in_delta(0.0, (worksheet.intermediate_output_be284||0), 0.002); end
  def test_intermediate_output_bf284; assert_in_delta(0.0, (worksheet.intermediate_output_bf284||0), 0.002); end
  def test_intermediate_output_d285; assert_equal("Oil", worksheet.intermediate_output_d285); end
  def test_intermediate_output_e285; assert_in_delta(0.0, (worksheet.intermediate_output_e285||0), 0.002); end
  def test_intermediate_output_aw285; assert_in_delta(0.0, (worksheet.intermediate_output_aw285||0), 0.002); end
  def test_intermediate_output_ax285; assert_in_epsilon(789.5130298683872, worksheet.intermediate_output_ax285, 0.002); end
  def test_intermediate_output_ay285; assert_in_epsilon(992.591480421974, worksheet.intermediate_output_ay285, 0.002); end
  def test_intermediate_output_az285; assert_in_epsilon(1282.503457983557, worksheet.intermediate_output_az285, 0.002); end
  def test_intermediate_output_ba285; assert_in_epsilon(1706.9076290322487, worksheet.intermediate_output_ba285, 0.002); end
  def test_intermediate_output_bb285; assert_in_epsilon(2171.0390498998863, worksheet.intermediate_output_bb285, 0.002); end
  def test_intermediate_output_bc285; assert_in_epsilon(2636.9768947006924, worksheet.intermediate_output_bc285, 0.002); end
  def test_intermediate_output_bd285; assert_in_epsilon(3155.944106509667, worksheet.intermediate_output_bd285, 0.002); end
  def test_intermediate_output_be285; assert_in_epsilon(3608.2308026483847, worksheet.intermediate_output_be285, 0.002); end
  def test_intermediate_output_bf285; assert_in_epsilon(4149.065954043985, worksheet.intermediate_output_bf285, 0.002); end
  def test_intermediate_output_d286; assert_equal("Natural gas", worksheet.intermediate_output_d286); end
  def test_intermediate_output_e286; assert_in_delta(0.0, (worksheet.intermediate_output_e286||0), 0.002); end
  def test_intermediate_output_aw286; assert_in_delta(0.0, (worksheet.intermediate_output_aw286||0), 0.002); end
  def test_intermediate_output_ax286; assert_in_epsilon(412.6102834436577, worksheet.intermediate_output_ax286, 0.002); end
  def test_intermediate_output_ay286; assert_in_epsilon(397.5484142647076, worksheet.intermediate_output_ay286, 0.002); end
  def test_intermediate_output_az286; assert_in_epsilon(378.82667006285135, worksheet.intermediate_output_az286, 0.002); end
  def test_intermediate_output_ba286; assert_in_epsilon(366.77985016294065, worksheet.intermediate_output_ba286, 0.002); end
  def test_intermediate_output_bb286; assert_in_epsilon(355.752245754045, worksheet.intermediate_output_bb286, 0.002); end
  def test_intermediate_output_bc286; assert_in_epsilon(342.9663615777174, worksheet.intermediate_output_bc286, 0.002); end
  def test_intermediate_output_bd286; assert_in_epsilon(328.60388672990007, worksheet.intermediate_output_bd286, 0.002); end
  def test_intermediate_output_be286; assert_in_epsilon(311.1199085061853, worksheet.intermediate_output_be286, 0.002); end
  def test_intermediate_output_bf286; assert_in_epsilon(292.0798884013054, worksheet.intermediate_output_bf286, 0.002); end
  def test_intermediate_output_d287; assert_equal("Total used in Nigeria", worksheet.intermediate_output_d287); end
  def test_intermediate_output_e287; assert_in_delta(0.0, (worksheet.intermediate_output_e287||0), 0.002); end
  def test_intermediate_output_aw287; assert_in_delta(0.0, (worksheet.intermediate_output_aw287||0), 0.002); end
  def test_intermediate_output_ax287; assert_in_epsilon(2983.4102773727086, worksheet.intermediate_output_ax287, 0.002); end
  def test_intermediate_output_ay287; assert_in_epsilon(3173.569220246445, worksheet.intermediate_output_ay287, 0.002); end
  def test_intermediate_output_az287; assert_in_epsilon(3460.1518185459213, worksheet.intermediate_output_az287, 0.002); end
  def test_intermediate_output_ba287; assert_in_epsilon(3897.920220695567, worksheet.intermediate_output_ba287, 0.002); end
  def test_intermediate_output_bb287; assert_in_epsilon(4355.610651924878, worksheet.intermediate_output_bb287, 0.002); end
  def test_intermediate_output_bc287; assert_in_epsilon(4814.990033740058, worksheet.intermediate_output_bc287, 0.002); end
  def test_intermediate_output_bd287; assert_in_epsilon(5328.097776127316, worksheet.intermediate_output_bd287, 0.002); end
  def test_intermediate_output_be287; assert_in_epsilon(5774.993577884801, worksheet.intermediate_output_be287, 0.002); end
  def test_intermediate_output_bf287; assert_in_epsilon(6312.25807340059, worksheet.intermediate_output_bf287, 0.002); end
  def test_intermediate_output_d288; assert_equal("Imported energy", worksheet.intermediate_output_d288); end
  def test_intermediate_output_aw288; assert_in_delta(0.0, (worksheet.intermediate_output_aw288||0), 0.002); end
  def test_intermediate_output_ax288; assert_in_delta(0.0, (worksheet.intermediate_output_ax288||0), 0.002); end
  def test_intermediate_output_ay288; assert_in_delta(0.0, (worksheet.intermediate_output_ay288||0), 0.002); end
  def test_intermediate_output_az288; assert_in_delta(0.0, (worksheet.intermediate_output_az288||0), 0.002); end
  def test_intermediate_output_ba288; assert_in_epsilon(206.28582618424866, worksheet.intermediate_output_ba288, 0.002); end
  def test_intermediate_output_bb288; assert_in_epsilon(649.5752775678864, worksheet.intermediate_output_bb288, 0.002); end
  def test_intermediate_output_bc288; assert_in_epsilon(1094.6711528846922, worksheet.intermediate_output_bc288, 0.002); end
  def test_intermediate_output_bd288; assert_in_epsilon(1592.796395209667, worksheet.intermediate_output_bd288, 0.002); end
  def test_intermediate_output_be288; assert_in_epsilon(2024.2411218643847, worksheet.intermediate_output_be288, 0.002); end
  def test_intermediate_output_bf288; assert_in_epsilon(2544.2343037759847, worksheet.intermediate_output_bf288, 0.002); end
  def test_intermediate_output_be289; assert_equal("% imported", worksheet.intermediate_output_be289); end
  def test_intermediate_output_bf289; assert_in_delta(0.4030624657913162, worksheet.intermediate_output_bf289, 0.002); end
  def test_intermediate_output_d290; assert_equal("Primary demand", worksheet.intermediate_output_d290); end
  def test_intermediate_output_aw290; assert_in_delta(0.0, (worksheet.intermediate_output_aw290||0), 0.002); end
  def test_intermediate_output_ax290; assert_in_epsilon(2983.4102773727086, worksheet.intermediate_output_ax290, 0.002); end
  def test_intermediate_output_ay290; assert_in_epsilon(3173.5692202464456, worksheet.intermediate_output_ay290, 0.002); end
  def test_intermediate_output_az290; assert_in_epsilon(3460.1518185459213, worksheet.intermediate_output_az290, 0.002); end
  def test_intermediate_output_ba290; assert_in_epsilon(3897.9202206955674, worksheet.intermediate_output_ba290, 0.002); end
  def test_intermediate_output_bb290; assert_in_epsilon(4355.610651924877, worksheet.intermediate_output_bb290, 0.002); end
  def test_intermediate_output_bc290; assert_in_epsilon(4814.990033740058, worksheet.intermediate_output_bc290, 0.002); end
  def test_intermediate_output_bd290; assert_in_epsilon(5328.097776127314, worksheet.intermediate_output_bd290, 0.002); end
  def test_intermediate_output_be290; assert_in_epsilon(5774.993577884801, worksheet.intermediate_output_be290, 0.002); end
  def test_intermediate_output_bf290; assert_in_epsilon(6312.258073400589, worksheet.intermediate_output_bf290, 0.002); end
  def test_intermediate_output_b293; assert_equal("Electricity, format for web-based interface", worksheet.intermediate_output_b293); end
  def test_intermediate_output_c295; assert_equal("V.01", worksheet.intermediate_output_c295); end
  def test_intermediate_output_ax295; assert_in_epsilon(2010.0, worksheet.intermediate_output_ax295, 0.002); end
  def test_intermediate_output_ay295; assert_in_epsilon(2015.0, worksheet.intermediate_output_ay295, 0.002); end
  def test_intermediate_output_az295; assert_in_epsilon(2020.0, worksheet.intermediate_output_az295, 0.002); end
  def test_intermediate_output_ba295; assert_in_epsilon(2025.0, worksheet.intermediate_output_ba295, 0.002); end
  def test_intermediate_output_bb295; assert_in_epsilon(2030.0, worksheet.intermediate_output_bb295, 0.002); end
  def test_intermediate_output_bc295; assert_in_epsilon(2035.0, worksheet.intermediate_output_bc295, 0.002); end
  def test_intermediate_output_bd295; assert_in_epsilon(2040.0, worksheet.intermediate_output_bd295, 0.002); end
  def test_intermediate_output_be295; assert_in_epsilon(2045.0, worksheet.intermediate_output_be295, 0.002); end
  def test_intermediate_output_bf295; assert_in_epsilon(2050.0, worksheet.intermediate_output_bf295, 0.002); end
  def test_intermediate_output_bg295; assert_equal("TWh", worksheet.intermediate_output_bg295); end
  def test_intermediate_output_c297; assert_equal("VI.a", worksheet.intermediate_output_c297); end
  def test_intermediate_output_d297; assert_equal("Agriculture and land use", worksheet.intermediate_output_d297); end
  def test_intermediate_output_ax297; assert_in_epsilon(1.24142109, worksheet.intermediate_output_ax297, 0.002); end
  def test_intermediate_output_ay297; assert_in_epsilon(1.2635883530175855, worksheet.intermediate_output_ay297, 0.002); end
  def test_intermediate_output_az297; assert_in_epsilon(1.2868863692322783, worksheet.intermediate_output_az297, 0.002); end
  def test_intermediate_output_ba297; assert_in_epsilon(1.3113728184213127, worksheet.intermediate_output_ba297, 0.002); end
  def test_intermediate_output_bb297; assert_in_epsilon(1.3371083226102514, worksheet.intermediate_output_bb297, 0.002); end
  def test_intermediate_output_bc297; assert_in_epsilon(1.3641565961572164, worksheet.intermediate_output_bc297, 0.002); end
  def test_intermediate_output_bd297; assert_in_epsilon(1.3925846034929303, worksheet.intermediate_output_bd297, 0.002); end
  def test_intermediate_output_be297; assert_in_epsilon(1.4224627249070825, worksheet.intermediate_output_be297, 0.002); end
  def test_intermediate_output_bf297; assert_in_epsilon(1.4538649307914644, worksheet.intermediate_output_bf297, 0.002); end
  def test_intermediate_output_c298; assert_equal("IX.a", worksheet.intermediate_output_c298); end
  def test_intermediate_output_d298; assert_equal("Residential Cooling", worksheet.intermediate_output_d298); end
  def test_intermediate_output_ax298; assert_in_epsilon(37.59474475042564, worksheet.intermediate_output_ax298, 0.002); end
  def test_intermediate_output_ay298; assert_in_epsilon(40.53884979446483, worksheet.intermediate_output_ay298, 0.002); end
  def test_intermediate_output_az298; assert_in_epsilon(43.480083668665216, worksheet.intermediate_output_az298, 0.002); end
  def test_intermediate_output_ba298; assert_in_epsilon(46.4000150201092, worksheet.intermediate_output_ba298, 0.002); end
  def test_intermediate_output_bb298; assert_in_epsilon(49.277805125145015, worksheet.intermediate_output_bb298, 0.002); end
  def test_intermediate_output_bc298; assert_in_epsilon(52.08998298452563, worksheet.intermediate_output_bc298, 0.002); end
  def test_intermediate_output_bd298; assert_in_epsilon(54.81020234706122, worksheet.intermediate_output_bd298, 0.002); end
  def test_intermediate_output_be298; assert_in_epsilon(57.408979332392974, worksheet.intermediate_output_be298, 0.002); end
  def test_intermediate_output_bf298; assert_in_epsilon(59.85340923128411, worksheet.intermediate_output_bf298, 0.002); end
  def test_intermediate_output_c299; assert_equal("IX.c", worksheet.intermediate_output_c299); end
  def test_intermediate_output_d299; assert_equal("Service Sector Cooling", worksheet.intermediate_output_d299); end
  def test_intermediate_output_ax299; assert_in_epsilon(7.6376658252466445, worksheet.intermediate_output_ax299, 0.002); end
  def test_intermediate_output_ay299; assert_in_epsilon(11.164654317475202, worksheet.intermediate_output_ay299, 0.002); end
  def test_intermediate_output_az299; assert_in_epsilon(14.39449468289782, worksheet.intermediate_output_az299, 0.002); end
  def test_intermediate_output_ba299; assert_in_epsilon(17.327186921514574, worksheet.intermediate_output_ba299, 0.002); end
  def test_intermediate_output_bb299; assert_in_epsilon(19.96273103332554, worksheet.intermediate_output_bb299, 0.002); end
  def test_intermediate_output_bc299; assert_in_epsilon(22.301127018330565, worksheet.intermediate_output_bc299, 0.002); end
  def test_intermediate_output_bd299; assert_in_epsilon(24.34237487652973, worksheet.intermediate_output_bd299, 0.002); end
  def test_intermediate_output_be299; assert_in_epsilon(26.086474607923098, worksheet.intermediate_output_be299, 0.002); end
  def test_intermediate_output_bf299; assert_in_epsilon(27.533426212510538, worksheet.intermediate_output_bf299, 0.002); end
  def test_intermediate_output_c300; assert_equal("X.a", worksheet.intermediate_output_c300); end
  def test_intermediate_output_d300; assert_equal("Residential Lighting, Appliances, and Cooking", worksheet.intermediate_output_d300); end
  def test_intermediate_output_ax300; assert_in_epsilon(27.202503328691595, worksheet.intermediate_output_ax300, 0.002); end
  def test_intermediate_output_ay300; assert_in_epsilon(35.415531633592785, worksheet.intermediate_output_ay300, 0.002); end
  def test_intermediate_output_az300; assert_in_epsilon(63.448228099669514, worksheet.intermediate_output_az300, 0.002); end
  def test_intermediate_output_ba300; assert_in_epsilon(117.61679628205225, worksheet.intermediate_output_ba300, 0.002); end
  def test_intermediate_output_bb300; assert_in_epsilon(166.59798652039314, worksheet.intermediate_output_bb300, 0.002); end
  def test_intermediate_output_bc300; assert_in_epsilon(218.28060959949943, worksheet.intermediate_output_bc300, 0.002); end
  def test_intermediate_output_bd300; assert_in_epsilon(270.65130119474014, worksheet.intermediate_output_bd300, 0.002); end
  def test_intermediate_output_be300; assert_in_epsilon(321.6771459342246, worksheet.intermediate_output_be300, 0.002); end
  def test_intermediate_output_bf300; assert_in_epsilon(371.1567191366419, worksheet.intermediate_output_bf300, 0.002); end
  def test_intermediate_output_c301; assert_equal("X.b", worksheet.intermediate_output_c301); end
  def test_intermediate_output_d301; assert_equal("Service Sector Lighting, Appliances, and Cooking", worksheet.intermediate_output_d301); end
  def test_intermediate_output_ax301; assert_in_epsilon(10.747311068475991, worksheet.intermediate_output_ax301, 0.002); end
  def test_intermediate_output_ay301; assert_in_epsilon(11.87796980239625, worksheet.intermediate_output_ay301, 0.002); end
  def test_intermediate_output_az301; assert_in_epsilon(13.181003517972247, worksheet.intermediate_output_az301, 0.002); end
  def test_intermediate_output_ba301; assert_in_epsilon(14.460746058737476, worksheet.intermediate_output_ba301, 0.002); end
  def test_intermediate_output_bb301; assert_in_epsilon(20.02036878612206, worksheet.intermediate_output_bb301, 0.002); end
  def test_intermediate_output_bc301; assert_in_epsilon(26.20520051945836, worksheet.intermediate_output_bc301, 0.002); end
  def test_intermediate_output_bd301; assert_in_epsilon(28.921353483281138, worksheet.intermediate_output_bd301, 0.002); end
  def test_intermediate_output_be301; assert_in_epsilon(31.61597820855462, worksheet.intermediate_output_be301, 0.002); end
  def test_intermediate_output_bf301; assert_in_epsilon(36.020206104359104, worksheet.intermediate_output_bf301, 0.002); end
  def test_intermediate_output_c302; assert_equal("XI.a", worksheet.intermediate_output_c302); end
  def test_intermediate_output_d302; assert_equal("Industrial processes", worksheet.intermediate_output_d302); end
  def test_intermediate_output_ax302; assert_in_epsilon(24.44916469299917, worksheet.intermediate_output_ax302, 0.002); end
  def test_intermediate_output_ay302; assert_in_epsilon(24.982561473647642, worksheet.intermediate_output_ay302, 0.002); end
  def test_intermediate_output_az302; assert_in_epsilon(24.8255212104248, worksheet.intermediate_output_az302, 0.002); end
  def test_intermediate_output_ba302; assert_in_epsilon(23.67914021157986, worksheet.intermediate_output_ba302, 0.002); end
  def test_intermediate_output_bb302; assert_in_epsilon(20.431337268691905, worksheet.intermediate_output_bb302, 0.002); end
  def test_intermediate_output_bc302; assert_in_epsilon(24.53076397623631, worksheet.intermediate_output_bc302, 0.002); end
  def test_intermediate_output_bd302; assert_in_epsilon(29.427590808922986, worksheet.intermediate_output_bd302, 0.002); end
  def test_intermediate_output_be302; assert_in_epsilon(34.62201815810872, worksheet.intermediate_output_be302, 0.002); end
  def test_intermediate_output_bf302; assert_in_epsilon(40.74060203569329, worksheet.intermediate_output_bf302, 0.002); end
  def test_intermediate_output_c303; assert_equal("XII.a", worksheet.intermediate_output_c303); end
  def test_intermediate_output_d303; assert_equal("Domestic passenger transport", worksheet.intermediate_output_d303); end
  def test_intermediate_output_ax303; assert_in_delta(0.0, (worksheet.intermediate_output_ax303||0), 0.002); end
  def test_intermediate_output_ay303; assert_in_delta(0.8227104960402019, worksheet.intermediate_output_ay303, 0.002); end
  def test_intermediate_output_az303; assert_in_epsilon(8.491330812712409, worksheet.intermediate_output_az303, 0.002); end
  def test_intermediate_output_ba303; assert_in_epsilon(20.573750811878107, worksheet.intermediate_output_ba303, 0.002); end
  def test_intermediate_output_bb303; assert_in_epsilon(37.15256926092712, worksheet.intermediate_output_bb303, 0.002); end
  def test_intermediate_output_bc303; assert_in_epsilon(58.65890534613918, worksheet.intermediate_output_bc303, 0.002); end
  def test_intermediate_output_bd303; assert_in_epsilon(83.59482547500309, worksheet.intermediate_output_bd303, 0.002); end
  def test_intermediate_output_be303; assert_in_epsilon(113.29303358881124, worksheet.intermediate_output_be303, 0.002); end
  def test_intermediate_output_bf303; assert_in_epsilon(148.08856641224688, worksheet.intermediate_output_bf303, 0.002); end
  def test_intermediate_output_c304; assert_equal("XII.b", worksheet.intermediate_output_c304); end
  def test_intermediate_output_d304; assert_equal("Domestic freight", worksheet.intermediate_output_d304); end
  def test_intermediate_output_ax304; assert_in_epsilon(1.0449356110119832, worksheet.intermediate_output_ax304, 0.002); end
  def test_intermediate_output_ay304; assert_in_epsilon(3.2109678001263453, worksheet.intermediate_output_ay304, 0.002); end
  def test_intermediate_output_az304; assert_in_epsilon(5.376883039249307, worksheet.intermediate_output_az304, 0.002); end
  def test_intermediate_output_ba304; assert_in_epsilon(7.542681328380861, worksheet.intermediate_output_ba304, 0.002); end
  def test_intermediate_output_bb304; assert_in_epsilon(9.708362667521023, worksheet.intermediate_output_bb304, 0.002); end
  def test_intermediate_output_bc304; assert_in_epsilon(11.874219431648278, worksheet.intermediate_output_bc304, 0.002); end
  def test_intermediate_output_bd304; assert_in_epsilon(14.040076195775544, worksheet.intermediate_output_bd304, 0.002); end
  def test_intermediate_output_be304; assert_in_epsilon(16.205932959902796, worksheet.intermediate_output_be304, 0.002); end
  def test_intermediate_output_bf304; assert_in_epsilon(18.37178972403005, worksheet.intermediate_output_bf304, 0.002); end
  def test_intermediate_output_c305; assert_equal("XV.a", worksheet.intermediate_output_c305); end
  def test_intermediate_output_d305; assert_equal("Petroleum refineries", worksheet.intermediate_output_d305); end
  def test_intermediate_output_ax305; assert_in_epsilon(4.622121648788703, worksheet.intermediate_output_ax305, 0.002); end
  def test_intermediate_output_ay305; assert_in_epsilon(4.622121648788703, worksheet.intermediate_output_ay305, 0.002); end
  def test_intermediate_output_az305; assert_in_epsilon(4.371134037538062, worksheet.intermediate_output_az305, 0.002); end
  def test_intermediate_output_ba305; assert_in_epsilon(3.824263033802973, worksheet.intermediate_output_ba305, 0.002); end
  def test_intermediate_output_bb305; assert_in_epsilon(3.3957453870616656, worksheet.intermediate_output_bb305, 0.002); end
  def test_intermediate_output_bc305; assert_in_epsilon(3.3234713448716318, worksheet.intermediate_output_bc305, 0.002); end
  def test_intermediate_output_bd305; assert_in_epsilon(3.3671835925355, worksheet.intermediate_output_bd305, 0.002); end
  def test_intermediate_output_be305; assert_in_epsilon(3.412079373769305, worksheet.intermediate_output_be305, 0.002); end
  def test_intermediate_output_bf305; assert_in_epsilon(3.456975155003112, worksheet.intermediate_output_bf305, 0.002); end
  def test_intermediate_output_c306; assert_equal("XV.b", worksheet.intermediate_output_c306); end
  def test_intermediate_output_d306; assert_equal("Indigenous fossil-fuel production", worksheet.intermediate_output_d306); end
  def test_intermediate_output_ax306; assert_in_delta(0.8865381076816921, worksheet.intermediate_output_ax306, 0.002); end
  def test_intermediate_output_ay306; assert_in_delta(0.8865381076816921, worksheet.intermediate_output_ay306, 0.002); end
  def test_intermediate_output_az306; assert_in_delta(0.9064085802749265, worksheet.intermediate_output_az306, 0.002); end
  def test_intermediate_output_ba306; assert_in_epsilon(2.3170630167210478, worksheet.intermediate_output_ba306, 0.002); end
  def test_intermediate_output_bb306; assert_in_epsilon(3.776492428510295, worksheet.intermediate_output_bb306, 0.002); end
  def test_intermediate_output_bc306; assert_in_epsilon(5.23592184029955, worksheet.intermediate_output_bc306, 0.002); end
  def test_intermediate_output_bd306; assert_in_epsilon(6.695351252088805, worksheet.intermediate_output_bd306, 0.002); end
  def test_intermediate_output_be306; assert_in_epsilon(8.154780663878054, worksheet.intermediate_output_be306, 0.002); end
  def test_intermediate_output_bf306; assert_in_epsilon(9.614210075667307, worksheet.intermediate_output_bf306, 0.002); end
  def test_intermediate_output_d307; assert_equal("Total", worksheet.intermediate_output_d307); end
  def test_intermediate_output_ax307; assert_in_epsilon(115.42640612332143, worksheet.intermediate_output_ax307, 0.002); end
  def test_intermediate_output_ay307; assert_in_epsilon(134.78549342723124, worksheet.intermediate_output_ay307, 0.002); end
  def test_intermediate_output_az307; assert_in_epsilon(179.7619740186366, worksheet.intermediate_output_az307, 0.002); end
  def test_intermediate_output_ba307; assert_in_epsilon(255.05301550319766, worksheet.intermediate_output_ba307, 0.002); end
  def test_intermediate_output_bb307; assert_in_epsilon(331.660506800308, worksheet.intermediate_output_bb307, 0.002); end
  def test_intermediate_output_bc307; assert_in_epsilon(423.8643586571661, worksheet.intermediate_output_bc307, 0.002); end
  def test_intermediate_output_bd307; assert_in_epsilon(517.2428438294311, worksheet.intermediate_output_bd307, 0.002); end
  def test_intermediate_output_be307; assert_in_epsilon(613.8988855524725, worksheet.intermediate_output_be307, 0.002); end
  def test_intermediate_output_bf307; assert_in_epsilon(716.2897690182277, worksheet.intermediate_output_bf307, 0.002); end
  def test_intermediate_output_d309; assert_equal("Transport", worksheet.intermediate_output_d309); end
  def test_intermediate_output_ax309; assert_in_epsilon(1.0449356110119832, worksheet.intermediate_output_ax309, 0.002); end
  def test_intermediate_output_ay309; assert_in_epsilon(4.033678296166547, worksheet.intermediate_output_ay309, 0.002); end
  def test_intermediate_output_az309; assert_in_epsilon(13.868213851961716, worksheet.intermediate_output_az309, 0.002); end
  def test_intermediate_output_ba309; assert_in_epsilon(28.11643214025897, worksheet.intermediate_output_ba309, 0.002); end
  def test_intermediate_output_bb309; assert_in_epsilon(46.860931928448146, worksheet.intermediate_output_bb309, 0.002); end
  def test_intermediate_output_bc309; assert_in_epsilon(70.53312477778746, worksheet.intermediate_output_bc309, 0.002); end
  def test_intermediate_output_bd309; assert_in_epsilon(97.63490167077863, worksheet.intermediate_output_bd309, 0.002); end
  def test_intermediate_output_be309; assert_in_epsilon(129.49896654871404, worksheet.intermediate_output_be309, 0.002); end
  def test_intermediate_output_bf309; assert_in_epsilon(166.4603561362769, worksheet.intermediate_output_bf309, 0.002); end
  def test_intermediate_output_d310; assert_equal("Industry", worksheet.intermediate_output_d310); end
  def test_intermediate_output_ax310; assert_in_epsilon(31.199245539469562, worksheet.intermediate_output_ax310, 0.002); end
  def test_intermediate_output_ay310; assert_in_epsilon(31.75480958313562, worksheet.intermediate_output_ay310, 0.002); end
  def test_intermediate_output_az310; assert_in_epsilon(31.389950197470064, worksheet.intermediate_output_az310, 0.002); end
  def test_intermediate_output_ba310; assert_in_epsilon(31.131839080525193, worksheet.intermediate_output_ba310, 0.002); end
  def test_intermediate_output_bb310; assert_in_epsilon(28.94068340687412, worksheet.intermediate_output_bb310, 0.002); end
  def test_intermediate_output_bc310; assert_in_epsilon(34.454313757564705, worksheet.intermediate_output_bc310, 0.002); end
  def test_intermediate_output_bd310; assert_in_epsilon(40.88271025704022, worksheet.intermediate_output_bd310, 0.002); end
  def test_intermediate_output_be310; assert_in_epsilon(47.61134092066317, worksheet.intermediate_output_be310, 0.002); end
  def test_intermediate_output_bf310; assert_in_epsilon(55.26565219715517, worksheet.intermediate_output_bf310, 0.002); end
  def test_intermediate_output_d311; assert_equal("Heating and cooling", worksheet.intermediate_output_d311); end
  def test_intermediate_output_ax311; assert_in_epsilon(45.23241057567228, worksheet.intermediate_output_ax311, 0.002); end
  def test_intermediate_output_ay311; assert_in_epsilon(51.703504111940035, worksheet.intermediate_output_ay311, 0.002); end
  def test_intermediate_output_az311; assert_in_epsilon(57.87457835156304, worksheet.intermediate_output_az311, 0.002); end
  def test_intermediate_output_ba311; assert_in_epsilon(63.727201941623775, worksheet.intermediate_output_ba311, 0.002); end
  def test_intermediate_output_bb311; assert_in_epsilon(69.24053615847055, worksheet.intermediate_output_bb311, 0.002); end
  def test_intermediate_output_bc311; assert_in_epsilon(74.3911100028562, worksheet.intermediate_output_bc311, 0.002); end
  def test_intermediate_output_bd311; assert_in_epsilon(79.15257722359095, worksheet.intermediate_output_bd311, 0.002); end
  def test_intermediate_output_be311; assert_in_epsilon(83.49545394031607, worksheet.intermediate_output_be311, 0.002); end
  def test_intermediate_output_bf311; assert_in_epsilon(87.38683544379465, worksheet.intermediate_output_bf311, 0.002); end
  def test_intermediate_output_d312; assert_equal("Lighting & appliances", worksheet.intermediate_output_d312); end
  def test_intermediate_output_ax312; assert_in_epsilon(37.949814397167586, worksheet.intermediate_output_ax312, 0.002); end
  def test_intermediate_output_ay312; assert_in_epsilon(47.293501435989036, worksheet.intermediate_output_ay312, 0.002); end
  def test_intermediate_output_az312; assert_in_epsilon(76.62923161764176, worksheet.intermediate_output_az312, 0.002); end
  def test_intermediate_output_ba312; assert_in_epsilon(132.07754234078973, worksheet.intermediate_output_ba312, 0.002); end
  def test_intermediate_output_bb312; assert_in_epsilon(186.61835530651518, worksheet.intermediate_output_bb312, 0.002); end
  def test_intermediate_output_bc312; assert_in_epsilon(244.48581011895777, worksheet.intermediate_output_bc312, 0.002); end
  def test_intermediate_output_bd312; assert_in_epsilon(299.5726546780213, worksheet.intermediate_output_bd312, 0.002); end
  def test_intermediate_output_be312; assert_in_epsilon(353.2931241427792, worksheet.intermediate_output_be312, 0.002); end
  def test_intermediate_output_bf312; assert_in_epsilon(407.176925241001, worksheet.intermediate_output_bf312, 0.002); end
  def test_intermediate_output_d313; assert_equal("Total", worksheet.intermediate_output_d313); end
  def test_intermediate_output_ax313; assert_in_epsilon(115.42640612332141, worksheet.intermediate_output_ax313, 0.002); end
  def test_intermediate_output_ay313; assert_in_epsilon(134.78549342723124, worksheet.intermediate_output_ay313, 0.002); end
  def test_intermediate_output_az313; assert_in_epsilon(179.76197401863658, worksheet.intermediate_output_az313, 0.002); end
  def test_intermediate_output_ba313; assert_in_epsilon(255.05301550319768, worksheet.intermediate_output_ba313, 0.002); end
  def test_intermediate_output_bb313; assert_in_epsilon(331.660506800308, worksheet.intermediate_output_bb313, 0.002); end
  def test_intermediate_output_bc313; assert_in_epsilon(423.8643586571661, worksheet.intermediate_output_bc313, 0.002); end
  def test_intermediate_output_bd313; assert_in_epsilon(517.2428438294311, worksheet.intermediate_output_bd313, 0.002); end
  def test_intermediate_output_be313; assert_in_epsilon(613.8988855524725, worksheet.intermediate_output_be313, 0.002); end
  def test_intermediate_output_bf313; assert_in_epsilon(716.2897690182277, worksheet.intermediate_output_bf313, 0.002); end
end
