def Model.last_modified_date() @last_modified_date ||= Time.utc(*[56, 10, 13, 16, 1, 2015, 5, 16, false, "WAT"]); end
