# Readme for stylesheets

application.css loads all the stylesheets in this folder and combines them into a single worksheet before returning them to the server

body.css contains the principal shape of the page
